---
name: mds-locators
description: Strategies for generating MDS-aware locators
version: 1.0.0
tags:
  - mds
  - locators
  - design-system
---

# MDS Locators Skill

This skill provides strategies for generating locators that work with the MDS (My Design System) component library.

## MDS Component Structure

MDS components follow Web Components standards:
```html
<mds-button label="Click Me" variant="primary" data-testid="submit-btn">
  Click Me
</mds-button>
```

## Locator Strategy Priority

### 1. data-testid (Best)
```javascript
page.locator('mds-button[data-testid="submit-button"]')
```
**Pros**: Explicit, stable, test-specific
**Cons**: Requires frontend developers to add data-testid

### 2. MDS Component + Unique Prop
```javascript
page.locator('mds-button[label="Submit"]')
page.locator('mds-input[name="email"]')
```
**Pros**: Leverages component props, semantic
**Cons**: Can break if label changes

### 3. MDS Component + ARIA
```javascript
page.locator('mds-button[aria-label="Submit form"]')
```
**Pros**: Accessibility-friendly, semantic
**Cons**: May not always be present

### 4. MDS Component + Text
```javascript
page.locator('mds-button:has-text("Submit")')
```
**Pros**: Visual, easy to understand
**Cons**: Breaks with i18n, text changes

### 5. CSS Selector (Last Resort)
```javascript
page.locator('.form-actions mds-button.primary')
```
**Pros**: Can always construct something
**Cons**: Fragile, coupled to styling

## Common MDS Components

### MdsButton
```javascript
page.locator('mds-button[label="Click"]')
page.locator('mds-button[variant="primary"]')
page.locator('mds-button[data-testid="save-btn"]')
```

### MdsInput
```javascript
page.locator('mds-input[name="username"]')
page.locator('mds-input[label="Email Address"]')
page.locator('mds-input[type="email"]')
```

### MdsSelect
```javascript
page.locator('mds-select[name="country"]')
page.locator('mds-select[label="Select Country"]')
```

### MdsCheckbox
```javascript
page.locator('mds-checkbox[name="terms"]')
page.locator('mds-checkbox[label="I agree"]')
```

### MdsTable
```javascript
page.locator('mds-table[data-testid="users-table"]')
page.locator('mds-table tbody tr') // rows
page.locator('mds-table thead th') // headers
```

## Using MDS MCP Server

Query MDS component documentation:
```
Use mcp__mds-mcp__getComponentDocs for MdsButton
```

Extract:
- **Props**: name, type, required, default
- **Events**: event names and payloads
- **Slots**: slot names
- **Best locator**: Recommended selector from docs

## Combining Strategies

### Scoped Locators
```javascript
const form = page.locator('form[data-testid="user-form"]');
const submitBtn = form.locator('mds-button[label="Submit"]');
```

### Multiple Conditions
```javascript
page.locator('mds-button[variant="primary"][label="Save"]')
```

### Dynamic Values
```javascript
page.locator(`mds-button[label="${buttonLabel}"]`)
```

## Handling Shadow DOM

Some MDS components use Shadow DOM:
```javascript
const button = page.locator('mds-button[label="Click"]');
await button.click(); // Playwright handles shadow DOM automatically
```

## Best Practices

1. **Always check MDS documentation first**
2. **Prefer component props over structure**
3. **Use data-testid when available**
4. **Scope locators to parent containers**
5. **Avoid nth-child and positional selectors**
6. **Test locators are unique before using**

## Anti-Patterns to Avoid

❌ Relying on generated IDs:
```javascript
page.locator('#mds-button-1234') // Will change
```

❌ Deep CSS nesting:
```javascript
page.locator('div > div > mds-button:nth-child(3)')
```

❌ Ignoring component semantics:
```javascript
page.locator('[class*="button"]') // Use mds-button instead
```

## Fallback Strategy

If primary locator fails:
1. Try data-testid
2. Try component + prop
3. Try ARIA label
4. Try text content
5. Try CSS selector
6. Report to LocatorHealingAgent
