---
name: traceability-mapping
description: Patterns for creating REQ → AC → TC traceability
version: 1.0.0
tags:
  - traceability
  - requirements
  - test-design
---

# Traceability Mapping Skill

This skill provides patterns for creating point-to-point traceability from requirements to test cases.

## Requirement Format

Requirements must follow this format:

```markdown
## REQ-001: Requirement Title
Brief description of the requirement.

### AC-001: First Acceptance Criterion
Description of what must be accepted.

### AC-002: Second Acceptance Criterion
Description of what must be accepted.
```

## Parsing Requirements

1. **Extract Requirements**
   - Format: `## REQ-###: Title`
   - Capture ID and title
   - Link to acceptance criteria

2. **Extract Acceptance Criteria**
   - Format: `### AC-###: Description`
   - Capture ID and description
   - Link to parent requirement

## Creating Traceability Matrix

### Format
```markdown
| Requirement | Acceptance Criteria | Test Case | Status |
|-------------|---------------------|-----------|--------|
| REQ-001     | AC-001              | TC-001    | ✅      |
| REQ-001     | AC-002              | TC-002    | ✅      |
| REQ-002     | AC-003              | TC-003    | ✅      |
```

### Mapping Rules

1. **One-to-One Mapping**
   - Each AC should have at least one TC
   - Each TC should map to one AC

2. **Status Tracking**
   - ✅ Test case implemented
   - ⏳ Test case planned
   - ❌ Test case failed

## Test Case Naming

Follow this pattern:
```
TC-###: [Action] [Expected Result]
```

Examples:
- `TC-001: Verify Add button is displayed`
- `TC-002: Submit form creates new record`
- `TC-003: Validate email format before save`

## Linking in Code

Add traceability comments in test files:

```javascript
test('TC-001: Verify Add button displayed', async ({ page }) => {
  // REQ-001, AC-001
  // Test implementation
});
```

## Coverage Calculation

```
Coverage = (Test Cases / Acceptance Criteria) × 100%
```

**Goal**: 100% coverage (every AC has at least one TC)

## Traceability Report

Generate a report showing:
1. Requirements with no test coverage (gaps)
2. Test cases with no requirement link (orphans)
3. Coverage percentage by requirement
4. Overall coverage percentage

## Example Workflow

1. Parse requirements → Extract REQ-XXX and AC-XXX
2. For each AC, create TC-XXX
3. Generate traceability matrix
4. Implement tests with traceability comments
5. Validate 100% coverage
6. Generate traceability report
