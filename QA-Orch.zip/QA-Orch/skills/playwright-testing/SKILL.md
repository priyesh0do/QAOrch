---
name: playwright-testing
description: Best practices and patterns for Playwright test generation
version: 1.0.0
tags:
  - playwright
  - testing
  - page-object-model
---

# Playwright Testing Skill

This skill provides best practices and patterns for generating Playwright tests.

## Page Object Model

### Structure
```javascript
class PageName {
  constructor(page) {
    this.page = page;
    // Define locators
  }

  // Action methods
  async action() {}

  // Assertion methods
  async isVisible() {}
}
```

### Best Practices
1. **One page object per page/component**
2. **Locators as properties, not methods**
3. **Action methods for user interactions**
4. **Return values for assertions**

## Locator Strategies (Priority Order)

1. **data-testid** (Best)
   ```javascript
   page.locator('[data-testid="submit-button"]')
   ```

2. **MDS Component with unique prop**
   ```javascript
   page.locator('mds-button[label="Submit"]')
   ```

3. **ARIA labels**
   ```javascript
   page.locator('[aria-label="Submit form"]')
   ```

4. **Text content** (with component context)
   ```javascript
   page.locator('mds-button:has-text("Submit")')
   ```

5. **CSS selectors** (Last resort)
   ```javascript
   page.locator('.form-actions button.primary')
   ```

## Test Structure

```javascript
test.describe('Module - Feature', () => {
  let pageObject;

  test.beforeEach(async ({ page }) => {
    pageObject = new PageObject(page);
    await page.goto('/url');
  });

  test('TC-001: Test description', async ({ page }) => {
    // REQ-XXX, AC-XXX
    await pageObject.action();
    await expect(pageObject.element).toBeVisible();
  });
});
```

## Assertions

Use Playwright's built-in assertions:
```javascript
await expect(element).toBeVisible();
await expect(element).toHaveText('Expected');
await expect(element).toBeEnabled();
await expect(page).toHaveURL(/pattern/);
```

## Waiting Strategies

1. **Auto-waiting** (preferred)
   ```javascript
   await element.click(); // Waits automatically
   ```

2. **Explicit wait**
   ```javascript
   await element.waitFor({ state: 'visible' });
   ```

3. **Wait for network**
   ```javascript
   await page.waitForResponse(resp => resp.url().includes('/api/'));
   ```

## Common Patterns

### Fill and Submit Form
```javascript
async submitForm(data) {
  await this.nameInput.fill(data.name);
  await this.emailInput.fill(data.email);
  await this.submitButton.click();
}
```

### Handle Dialogs
```javascript
page.on('dialog', async dialog => {
  await dialog.accept();
});
```

### Multiple Elements
```javascript
const rows = page.locator('table tbody tr');
const count = await rows.count();
const firstRow = rows.first();
```

## Avoid Anti-Patterns

❌ **Don't use sleeps**
```javascript
await page.waitForTimeout(5000); // Bad
```

✅ **Do use auto-waiting**
```javascript
await expect(element).toBeVisible(); // Good
```

❌ **Don't use brittle selectors**
```javascript
page.locator('div > div > span:nth-child(3)') // Bad
```

✅ **Do use semantic selectors**
```javascript
page.locator('[data-testid="user-name"]') // Good
```
