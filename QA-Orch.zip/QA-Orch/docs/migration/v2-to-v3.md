# Migration Guide: v2.0 → v3.0

**From:** Workflow-Driven Architecture (v2.0)
**To:** Agent-Driven Architecture (v3.0)
**Breaking Changes:** Yes
**Migration Time:** ~1 hour

---

## Overview

Version 3.0 introduces a **pure agent-driven architecture** replacing the workflow-driven approach. This guide helps you migrate from v2.0 to v3.0.

---

## What Changed

### Architecture

| Aspect | v2.0 (Workflow-Driven) | v3.0 (Agent-Driven) |
|--------|------------------------|---------------------|
| **Execution Model** | Linear workflow steps | Autonomous agents with 4-phase execution |
| **Parallelism** | Sequential only | Parallel execution supported |
| **State** | No state management | Persistent state with StateManager |
| **Communication** | None | Inter-agent communication |
| **User Control** | Follow instructions | Low autonomy with approval checkpoints |

### Command Changes

```bash
# v2.0 (Workflow Commands)
"Run the functional testing workflow for module AbsenceCode"
"Execute the API testing workflow"
"Run the healing workflow"

# v3.0 (Agent Commands)
"Start FunctionalTestAutomationAgent for module AbsenceCode"
"Start APITestAgent for module AbsenceCode"
"Start LocatorHealingAgent"

# v3.0 (Parallel Execution)
"Start FunctionalTestAutomationAgent and APITestAgent in parallel for module AbsenceCode"
```

### Configuration Changes

**v2.0 Configuration:**
```json
{
  "version": "2.0.0",
  "architecture": "pure-workflow-driven",
  "workflows": {
    "enabled": true,
    "available": ["functional-testing-workflow.md", "..."]
  },
  "enabledWorkflows": ["functional"]
}
```

**v3.0 Configuration:**
```json
{
  "version": "3.0.0",
  "architecture": "agent-driven",
  "agents": {
    "enabled": true,
    "parallelExecution": true,
    "maxConcurrentAgents": 3,
    "availableAgents": [
      {
        "name": "FunctionalTestAutomationAgent",
        "enabled": true,
        "autonomyLevel": "low",
        "dependencies": [],
        "approvalCheckpoints": ["analysis", "design", "generation", "validation"]
      }
    ]
  },
  "workflows": {
    "enabled": false,
    "description": "Deprecated - kept as reference only"
  }
}
```

---

## Migration Steps

### Step 1: Backup Current Configuration

```bash
# Backup your v2.0 configuration
cp orchestrator-config.json orchestrator-config.v2.0.backup.json
```

### Step 2: Update Configuration File

Replace your `orchestrator-config.json` with the v3.0 structure:

1. Change `version` to `"3.0.0"`
2. Change `architecture` to `"agent-driven"`
3. Add `agents` section (see template below)
4. Set `workflows.enabled` to `false`

**Template:**
```json
{
  "version": "3.0.0",
  "architecture": "agent-driven",
  "agents": {
    "enabled": true,
    "parallelExecution": true,
    "maxConcurrentAgents": 3,
    "availableAgents": [
      {
        "name": "FunctionalTestAutomationAgent",
        "enabled": true,
        "autonomyLevel": "low",
        "parallelizable": true,
        "dependencies": []
      },
      {
        "name": "IntegrationTestAgent",
        "enabled": true,
        "autonomyLevel": "low",
        "parallelizable": true,
        "dependencies": ["FunctionalTestAutomationAgent"]
      },
      {
        "name": "APITestAgent",
        "enabled": true,
        "autonomyLevel": "low",
        "parallelizable": true,
        "dependencies": []
      },
      {
        "name": "LocatorHealingAgent",
        "enabled": true,
        "autonomyLevel": "low",
        "parallelizable": false,
        "dependencies": []
      }
    ]
  }
}
```

### Step 3: Verify Agent Files

Ensure the following agent files exist:

```bash
# Check agents directory
ls agents/

# Expected files:
# agents/
# ├── base/
# │   ├── Agent.js
# │   └── ApprovalUI.js
# ├── specialized/
# │   ├── FunctionalTestAutomationAgent.js
# │   ├── IntegrationTestAgent.js
# │   ├── APITestAgent.js
# │   └── LocatorHealingAgent.js
# ├── AgentOrchestrator.js
# ├── StateManager.js
# ├── index.js
# └── example-usage.js
```

### Step 4: Test Migration

Run the example usage to verify agents work:

```bash
# Test agent system
node agents/example-usage.js
```

### Step 5: Update Your Commands

**Before (v2.0):**
```javascript
// You would tell Claude:
"Run the functional testing workflow for module AbsenceCode"
```

**After (v3.0):**
```javascript
// Now tell Claude:
"Start FunctionalTestAutomationAgent for module AbsenceCode"

// Or for parallel execution:
"Start FunctionalTestAutomationAgent and APITestAgent in parallel for AbsenceCode"
```

---

## Command Mapping

### Single Agent Execution

| v2.0 Workflow Command | v3.0 Agent Command |
|-----------------------|--------------------|
| "Run functional testing workflow" | "Start FunctionalTestAutomationAgent" |
| "Run integration testing workflow" | "Start IntegrationTestAgent" |
| "Run API testing workflow" | "Start APITestAgent" |
| "Run healing workflow" | "Start LocatorHealingAgent" |

### Parallel Execution (New in v3.0)

```bash
# Execute multiple agents concurrently
"Start FunctionalTestAutomationAgent and APITestAgent in parallel"

# Execute with dependency resolution
"Start IntegrationTestAgent" # Automatically runs FunctionalTestAutomationAgent first
```

---

## New Features in v3.0

### 1. Approval Checkpoints

Every agent now has 4 approval checkpoints:

```
1. Analysis Phase → [APPROVAL] → Continue?
2. Design Phase → [APPROVAL] → Continue?
3. Generation Phase → [APPROVAL] → Continue?
4. Validation Phase → [APPROVAL] → Continue?
```

**At each checkpoint, you can:**
- **[A]pprove** - Continue to next phase
- **[M]odify** - Provide changes and retry
- **[R]eject** - Stop execution
- **[V]iew Details** - See full data

### 2. Parallel Execution

Execute multiple agents simultaneously:

```javascript
// Example: Process 3 modules in parallel
orchestrator.executeParallel([
  { name: 'FunctionalTestAutomationAgent', context: { moduleName: 'Module1' } },
  { name: 'FunctionalTestAutomationAgent', context: { moduleName: 'Module2' } },
  { name: 'APITestAgent', context: { moduleName: 'Module3' } }
]);
```

### 3. State Management

Agents now maintain state:

```javascript
// Save state
await stateManager.saveArtifact('FunctionalTestAutomationAgent', 'test-design', data);

// Retrieve state
const artifact = await stateManager.getArtifact('FunctionalTestAutomationAgent', 'test-design');

// State persisted to disk (./.agent-state/)
```

### 4. Inter-Agent Communication

Agents can share artifacts:

```javascript
// IntegrationTestAgent can access FunctionalTestAutomationAgent outputs
const functionalDesign = await stateManager.getArtifact(
  'FunctionalTestAutomationAgent',
  'functional-design'
);
```

---

## Troubleshooting

### Issue 1: "Agent not registered" Error

**Problem:** Trying to execute an agent that hasn't been registered.

**Solution:**
```javascript
// Register agent before execution
orchestrator.registerAgent(FunctionalTestAutomationAgent, config);
```

### Issue 2: "Dependency not satisfied" Error

**Problem:** Trying to execute an agent whose dependencies haven't completed.

**Solution:**
```javascript
// Option 1: Execute dependencies first
await orchestrator.executeSingle('FunctionalTestAutomationAgent', {});
await orchestrator.executeSingle('IntegrationTestAgent', {});

// Option 2: Use automatic dependency resolution
await orchestrator.executeWithDependencies(['IntegrationTestAgent']);
```

### Issue 3: Workflows Not Working

**Problem:** Old workflow commands not executing.

**Solution:**
Workflows are deprecated in v3.0. Update to agent commands:
```bash
# Old: "Run functional testing workflow"
# New: "Start FunctionalTestAutomationAgent"
```

### Issue 4: Approval Checkpoint Stuck

**Problem:** Agent waiting at checkpoint indefinitely.

**Solution:**
Respond to the approval prompt:
- Press `A` to approve
- Press `M` to modify
- Press `R` to reject
- Press `V` to view details

---

## Backward Compatibility

### Workflows (Deprecated)

Workflows are **deprecated** but kept as reference documentation:

```bash
# Workflow files remain in workflows/ directory
# They serve as reference for agent implementation
# They are NOT executed in v3.0
```

### Existing Test Artifacts

Generated test artifacts (page objects, test specs) remain **fully compatible**:
- Page objects still use same naming convention
- Test specs follow same patterns
- Directory structure unchanged
- Only execution model changed

---

## Rollback to v2.0

If you need to rollback to v2.0:

```bash
# 1. Restore backup configuration
cp orchestrator-config.v2.0.backup.json orchestrator-config.json

# 2. Use workflow commands
"Run the functional testing workflow for module AbsenceCode"
```

---

## FAQ

### Q: Do I need to regenerate existing tests?

**A:** No. Existing tests remain compatible. Only the generation process changed.

### Q: Can I still use workflows?

**A:** No. Workflows are deprecated in v3.0. Use agent commands instead.

### Q: How do I run multiple agents?

**A:** Use parallel execution:
```javascript
orchestrator.executeParallel([
  { name: 'Agent1', context: {...} },
  { name: 'Agent2', context: {...} }
]);
```

### Q: What happens if an agent fails?

**A:** Other agents continue running (configurable via `failureHandling`).

### Q: Can I skip approval checkpoints?

**A:** No. Low autonomy requires user approval at all checkpoints for control.

### Q: How do I monitor agent status?

**A:** Use `orchestrator.getStatus()` or check individual agents:
```javascript
const status = orchestrator.getStatus();
console.log(`Running: ${status.running}, Completed: ${status.completed}`);
```

---

## Support

If you encounter issues during migration:

1. **Review Documentation**
   - `AGENT_ARCHITECTURE.md` - Full architecture details
   - `agents/example-usage.js` - Working examples

2. **Check Configuration**
   - Verify `orchestrator-config.json` has correct v3.0 structure
   - Ensure `agents.enabled = true`

3. **Test Agents**
   - Run `node agents/example-usage.js`
   - Verify agent files exist

4. **Report Issues**
   - GitHub: [anthropics/claude-code/issues](https://github.com/anthropics/claude-code/issues)

---

**Migration Version:** v2.0 → v3.0
**Breaking Changes:** Yes
**Backward Compatible:** No (workflows deprecated)
**Rollback Supported:** Yes (restore v2.0 config)
