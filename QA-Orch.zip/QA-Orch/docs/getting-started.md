# Quick Start Guide - Agent-Driven Architecture

**Version:** 3.0.0
**Time:** 10 minutes
**Prerequisites:** Test Orchestrator v3.0 installed

---

## What You'll Learn

- How to execute a single agent
- How to run agents in parallel
- How to handle approval checkpoints
- How to monitor agent status

---

## 1. Basic Agent Execution (2 minutes)

### Execute FunctionalTestAutomationAgent

Tell Claude:
```
Start FunctionalTestAutomationAgent for module AbsenceCode
```

Claude will:
1. Register the agent
2. Execute through 4 phases
3. Request approval at each checkpoint

### Your Interaction

At each checkpoint, you'll see:

```
═══════════════════════════════════════════════════════════
  FunctionalTestAutomationAgent - Checkpoint: Analysis
═══════════════════════════════════════════════════════════
  Phase: Analysis

  Analysis complete: Found 5 requirements, 15 acceptance
  criteria, 8 MDS components. Locator confidence: 98%

  [A]pprove  [M]odify  [R]eject  [V]iew Details  [H]elp
═══════════════════════════════════════════════════════════
```

**Actions:**
- Press `A` to approve and continue
- Press `M` to modify and retry phase
- Press `R` to reject and stop
- Press `V` to view full details
- Press `H` for help

### Expected Output

After 4 approvals:
```
✓ FunctionalTestAutomationAgent COMPLETED SUCCESSFULLY
  Execution time: 45000ms
  Artifacts generated: 12

Generated:
  - test-designs/AbsenceCode/functional-design.md
  - test-designs/AbsenceCode/traceability-matrix.md
  - pages/AbsenceCode/absenceCode.page.js
  - tests/functional/AbsenceCode/absenceCode.spec.js
```

---

## 2. Parallel Execution (3 minutes)

### Run Multiple Agents Simultaneously

Tell Claude:
```
Start FunctionalTestAutomationAgent and APITestAgent in parallel for module AbsenceCode
```

### What Happens

1. **Both agents start concurrently**
   ```
   [Orchestrator] Starting parallel execution of 2 agents
   [FunctionalTestAutomationAgent] Analysis phase started
   [APITestAgent] Analysis phase started
   ```

2. **Each agent reaches its own checkpoints independently**
   ```
   [FunctionalTestAutomationAgent] Checkpoint 1: Analysis → Waiting for approval
   [APITestAgent] Checkpoint 1: Analysis → Waiting for approval
   ```

3. **You approve each agent separately**
   - Approve FunctionalTestAutomationAgent
   - Approve APITestAgent
   - They continue independently

4. **Completion**
   ```
   Parallel execution completed: 2 successful, 0 failed
   Total time: 50000ms (40% faster than sequential)
   ```

---

## 3. Dependency-Aware Execution (2 minutes)

### Execute Agent with Dependencies

Tell Claude:
```
Start IntegrationTestAgent for module AbsenceCode
```

### What Happens

Since IntegrationTestAgent depends on FunctionalTestAutomationAgent:

1. **Automatic dependency resolution**
   ```
   [Orchestrator] Resolving dependencies for IntegrationTestAgent
   [Orchestrator] Execution order: FunctionalTestAutomationAgent -> IntegrationTestAgent
   ```

2. **Sequential execution with dependencies**
   ```
   [Orchestrator] Executing level: FunctionalTestAutomationAgent
   [FunctionalTestAutomationAgent] Starting...
   [FunctionalTestAutomationAgent] Completed ✓

   [Orchestrator] Executing level: IntegrationTestAgent
   [IntegrationTestAgent] Loading functional design from FunctionalTestAutomationAgent
   [IntegrationTestAgent] Starting...
   ```

---

## 4. Monitor Agent Status (1 minute)

### Check Running Agents

Tell Claude:
```
Show me the status of all agents
```

### Response

```
═══════════════════════════════════════════════════════════
  Agent Orchestrator Status
═══════════════════════════════════════════════════════════
  Running agents: 2
  Completed agents: 1
  Max concurrent: 3

  Running:
    ▶ FunctionalTestAutomationAgent
       State: waiting_approval
       Checkpoint: design

    ▶ APITestAgent
       State: running
       Checkpoint: generation

  Completed:
    ✓ LocatorHealingAgent
       Completed: 2026-02-03 14:32:10
       Execution time: 30000ms
═══════════════════════════════════════════════════════════
```

---

## 5. Common Scenarios

### Scenario 1: Generate Tests for New Module

```
Start FunctionalTestAutomationAgent for module NewModule with:
- Requirement path: ./requirements/NewModule.md
- Frontend path: ./frontend/modules/new-module
```

**Result:** Complete functional tests with traceability

---

### Scenario 2: Run Full Test Suite

```
Start FunctionalTestAutomationAgent, IntegrationTestAgent, and APITestAgent
in parallel for module CompleteModule
```

**Result:** All 3 test types generated concurrently

---

### Scenario 3: Heal Broken Locators

```
Start LocatorHealingAgent to fix failed tests in module AbsenceCode
```

**Result:** Up to 5 alternative locators per failure, page objects updated

---

### Scenario 4: Multi-Module Testing

```
Start FunctionalTestAutomationAgent for modules: Module1, Module2, Module3 in parallel
```

**Result:** All 3 modules processed concurrently

---

## 6. Configuration Quick Reference

### Enable All Agents

`orchestrator-config.json`:
```json
{
  "version": "3.0.0",
  "architecture": "agent-driven",
  "agents": {
    "enabled": true,
    "parallelExecution": true,
    "maxConcurrentAgents": 3,
    "availableAgents": [
      { "name": "FunctionalTestAutomationAgent", "enabled": true },
      { "name": "IntegrationTestAgent", "enabled": true },
      { "name": "APITestAgent", "enabled": true },
      { "name": "LocatorHealingAgent", "enabled": true }
    ]
  }
}
```

### Adjust Concurrent Limit

```json
{
  "agents": {
    "maxConcurrentAgents": 5  // Increase for more parallelism
  }
}
```

---

## 7. Approval Best Practices

### At Analysis Checkpoint

**Review:**
- Number of requirements found
- Number of acceptance criteria
- MDS components identified
- Locator confidence percentage

**Questions to Ask:**
- Are all requirements captured?
- Is the confidence level acceptable?
- Are the right components identified?

---

### At Design Checkpoint

**Review:**
- Number of test scenarios generated
- Traceability coverage percentage
- Page object design
- Requirement mappings

**Questions to Ask:**
- Do test scenarios cover all acceptance criteria?
- Is traceability complete (100%)?
- Are page objects well-structured?

---

### At Generation Checkpoint

**Review:**
- Number of page objects generated
- Number of test specs generated
- File paths and naming
- Code structure preview

**Questions to Ask:**
- Are all expected files generated?
- Do file names follow conventions?
- Is the code structure correct?

---

### At Validation Checkpoint

**Review:**
- Syntax errors (should be 0)
- Locator validation results
- Traceability check (should be complete)
- Code quality score

**Questions to Ask:**
- Are there any syntax errors?
- Did all locators pass validation?
- Is traceability 100% complete?

---

## 8. Troubleshooting

### Agent Not Starting

**Symptom:** "Agent not registered" error

**Solution:**
```
Make sure orchestrator-config.json has:
{
  "agents": {
    "enabled": true,
    "availableAgents": [
      { "name": "FunctionalTestAutomationAgent", "enabled": true }
    ]
  }
}
```

---

### Checkpoint Stuck

**Symptom:** Agent waiting at checkpoint indefinitely

**Solution:**
- Press `A` to approve
- Press `M` to modify (provide JSON modifications)
- Press `R` to reject and stop
- Press `H` for help

---

### Dependency Error

**Symptom:** "Dependency not satisfied" error

**Solution:**
Execute the dependency first:
```
Start FunctionalTestAutomationAgent for module X
# Wait for completion
Start IntegrationTestAgent for module X
```

Or use automatic resolution:
```
Start IntegrationTestAgent for module X
# Automatically runs FunctionalTestAutomationAgent first
```

---

### Parallel Execution Limit

**Symptom:** "Exceeds max concurrent limit" warning

**Solution:**
Increase limit in config:
```json
{
  "agents": {
    "maxConcurrentAgents": 5
  }
}
```

---

## 9. Next Steps

After completing this quick start:

1. **Read Full Documentation**
   - `AGENT_ARCHITECTURE.md` - Complete architecture details
   - `MIGRATION_GUIDE.md` - Migration from v2.0

2. **Explore Examples**
   - `agents/example-usage.js` - Working code examples
   - Try modifying examples for your use case

3. **Customize Configuration**
   - Adjust `orchestrator-config.json` for your project
   - Enable/disable specific agents
   - Configure parallel limits

4. **Advanced Usage**
   - State management with StateManager
   - Custom agent development
   - Agent monitoring and analytics

---

## 10. Command Cheat Sheet

```bash
# Single agent execution
"Start FunctionalTestAutomationAgent for module X"
"Start APITestAgent for module X"
"Start LocatorHealingAgent"

# Parallel execution
"Start FunctionalTestAutomationAgent and APITestAgent in parallel for module X"

# Dependency-aware execution
"Start IntegrationTestAgent for module X"  # Auto-runs dependencies

# Multi-module parallel execution
"Start FunctionalTestAutomationAgent for modules X, Y, Z in parallel"

# Check status
"Show agent status"
"Is FunctionalTestAutomationAgent running?"
"Show state manager statistics"

# Stop agents
"Stop FunctionalTestAutomationAgent"
"Stop all running agents"
```

---

## Support

- **Documentation:** See `AGENT_ARCHITECTURE.md`
- **Examples:** Run `node agents/example-usage.js`
- **Issues:** Report at [GitHub Issues](https://github.com/anthropics/claude-code/issues)

---

**Quick Start Guide Version:** 3.0.0
**Last Updated:** 2026-02-03
**Estimated Time:** 10 minutes
