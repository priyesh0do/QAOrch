# FunctionalTestAutomationAgent

## Overview

The **FunctionalTestAutomationAgent** is a specialized agent that generates comprehensive functional tests with point-to-point traceability from requirements to test cases.

## Purpose

Generate functional tests that verify UI functionality against acceptance criteria with full traceability and MDS-aware locators.

## Key Features

- ✅ **Requirement Parsing** - Extracts REQ-XXX and AC-XXX from requirements
- ✅ **Traceability Matrix** - Maps REQ → AC → TC with full lineage
- ✅ **MDS Integration** - Generates locators using MDS component documentation
- ✅ **Page Object Model** - Creates maintainable page objects
- ✅ **Test Specifications** - Generates Playwright test files
- ✅ **Design Documents** - Creates test design documentation

## Configuration

### orchestrator-config.json

```json
{
  "name": "FunctionalTestAutomationAgent",
  "enabled": true,
  "autonomyLevel": "low",
  "parallelizable": true,
  "dependencies": []
}
```

### Agent-Specific Options

```javascript
{
  moduleName: 'ModuleName',
  requirementPath: './requirements/ModuleName.md',
  frontendPath: './frontend/modules/module-name',
  projectPath: './test-project',
  referenceProjectPath: './reference-project',
  framework: 'Playwright',
  language: 'JavaScript'
}
```

## Execution Flow

### Phase 1: Analysis

**Purpose**: Parse requirements and extract testable elements

**Actions**:
1. Read requirement document
2. Extract REQ-XXX identifiers
3. Extract acceptance criteria (AC-XXX)
4. Identify UI components

**Approval Checkpoint**: User reviews extracted requirements and acceptance criteria

**Outputs**:
- Parsed requirements list
- Acceptance criteria list
- Component inventory

### Phase 2: Design

**Purpose**: Create test design and traceability

**Actions**:
1. Map requirements to acceptance criteria
2. Map acceptance criteria to test cases
3. Design test scenarios
4. Create traceability matrix

**Approval Checkpoint**: User reviews test design and traceability

**Outputs**:
- `test-designs/{module}/functional-design.md`
- `test-designs/{module}/traceability-matrix.md`

### Phase 3: Generation

**Purpose**: Generate page objects and test files

**Actions**:
1. Query MDS MCP server for component documentation
2. Generate MDS-aware locators
3. Create page object classes
4. Generate test specifications

**Approval Checkpoint**: User reviews generated artifacts

**Outputs**:
- `pages/{module}/*.page.js` - Page object files
- `tests/functional/{module}/*.spec.js` - Test files

### Phase 4: Validation

**Purpose**: Verify generated artifacts

**Actions**:
1. Validate page objects have all required locators
2. Validate tests cover all acceptance criteria
3. Check traceability completeness
4. Verify file structure

**Approval Checkpoint**: User reviews validation results

**Outputs**:
- Validation report
- Coverage metrics

## Generated Artifacts

### 1. Test Design Document

**Location**: `test-designs/{module}/functional-design.md`

**Contents**:
- Requirement overview
- Acceptance criteria breakdown
- Test scenario descriptions
- Expected behaviors
- Data requirements

### 2. Traceability Matrix

**Location**: `test-designs/{module}/traceability-matrix.md`

**Format**:
```markdown
| Requirement | Acceptance Criteria | Test Case | Status |
|-------------|---------------------|-----------|--------|
| REQ-001     | AC-001              | TC-001    | ✅      |
| REQ-001     | AC-002              | TC-002    | ✅      |
```

### 3. Page Objects

**Location**: `pages/{module}/*.page.js`

**Example**:
```javascript
class AbsenceCodePage {
  constructor(page) {
    this.page = page;

    // MDS-aware locators
    this.addButton = page.locator('[data-testid="add-button"]');
    this.nameInput = page.locator('mds-input[name="code-name"]');
    this.saveButton = page.locator('mds-button[type="submit"]');
  }

  async addAbsenceCode(name, description) {
    await this.addButton.click();
    await this.nameInput.fill(name);
    await this.saveButton.click();
  }
}

module.exports = AbsenceCodePage;
```

### 4. Test Specifications

**Location**: `tests/functional/{module}/*.spec.js`

**Example**:
```javascript
const { test, expect } = require('@playwright/test');
const AbsenceCodePage = require('../../pages/AbsenceCode/AbsenceCode.page');

test.describe('AbsenceCode - Functional Tests', () => {
  test('TC-001: Add new absence code', async ({ page }) => {
    const absenceCodePage = new AbsenceCodePage(page);

    await page.goto('/absence-codes');
    await absenceCodePage.addAbsenceCode('SICK', 'Sick Leave');

    await expect(page.locator('.success-message')).toBeVisible();
  });
});
```

## Dependencies

### Required MCP Servers

- **mds-mcp**: For MDS component documentation and locator guidance

### Agent Dependencies

None - This agent can run independently

## Parallel Execution

**Supported**: Yes

The FunctionalTestAutomationAgent can run in parallel with:
- APITestAgent (different output directories)
- Multiple instances for different modules

**Cannot run in parallel with**:
- LocatorHealingAgent (modifies same page objects)

## Usage Examples

### Basic Usage

```javascript
const { AgentOrchestrator, FunctionalTestAutomationAgent } = require('./agents');

const orchestrator = new AgentOrchestrator();

orchestrator.registerAgent(FunctionalTestAutomationAgent, {
  moduleName: 'AbsenceCode',
  requirementPath: './requirements/AbsenceCode.md',
  frontendPath: './frontend/modules/absence-code',
  projectPath: './test-project'
});

await orchestrator.executeSingle('FunctionalTestAutomationAgent');
```

### With Claude Code

```
Start FunctionalTestAutomationAgent for module AbsenceCode
```

### Parallel Execution

```
Start FunctionalTestAutomationAgent for modules: AbsenceCode, TimeOff, Calendar in parallel
```

## Approval Checkpoints

### Checkpoint 1: Analysis Phase

**User Reviews**:
- Parsed requirements
- Extracted acceptance criteria
- Identified components

**User Actions**:
- **[A]pprove**: Continue to design phase
- **[M]odify**: Provide corrections and re-analyze
- **[R]eject**: Stop execution
- **[V]iew**: See full extracted data

### Checkpoint 2: Design Phase

**User Reviews**:
- Test design document
- Traceability matrix
- Test scenarios

**User Actions**: Same as Checkpoint 1

### Checkpoint 3: Generation Phase

**User Reviews**:
- Generated page objects
- Generated test files
- Locator strategies

**User Actions**: Same as Checkpoint 1

### Checkpoint 4: Validation Phase

**User Reviews**:
- Validation results
- Coverage metrics
- Missing elements (if any)

**User Actions**: Same as Checkpoint 1

## Troubleshooting

### Issue: Requirements not parsed correctly

**Symptom**: Missing REQ-XXX or AC-XXX in analysis output

**Solution**:
- Ensure requirements follow format: `REQ-XXX: Description`
- Ensure acceptance criteria follow format: `AC-XXX: Criteria`
- Use [M]odify at checkpoint to provide corrections

### Issue: MDS locators not generated

**Symptom**: Page objects have generic locators instead of MDS-aware ones

**Solution**:
- Verify MDS MCP server is connected
- Check `orchestrator-config.json` has `mcpServers.mds.enabled: true`
- Run `node verify-implementation.js` to check MCP status

### Issue: Traceability gaps

**Symptom**: Validation phase reports incomplete traceability

**Solution**:
- Review test design at Checkpoint 2
- Ensure all AC-XXX have corresponding test cases
- Use [M]odify to add missing mappings

## Performance

### Typical Execution Time

- **Small module** (5-10 requirements): 3-5 minutes
- **Medium module** (10-20 requirements): 5-10 minutes
- **Large module** (20+ requirements): 10-20 minutes

*Times include user approval time at checkpoints*

### Artifact Sizes

- Test design: 2-5 KB per requirement
- Page objects: 1-3 KB per page
- Test files: 2-5 KB per test

## Best Practices

1. **Clear Requirements**: Ensure requirements have clear REQ-XXX and AC-XXX identifiers
2. **MDS Components**: Identify MDS components in requirements for better locators
3. **Modular Testing**: Keep modules focused (5-15 requirements per module)
4. **Review Checkpoints**: Carefully review traceability at Checkpoint 2
5. **Reference Project**: Provide a reference project for consistent patterns

## Related Documentation

- [Getting Started Guide](../getting-started.md)
- [Agent Architecture](../architecture.md)
- [MCP Integration Guide](../guides/mcp-integration.md)
- [Parallel Execution Guide](../guides/parallel-execution.md)
