# Engineering Manager's Guide to Measuring QA Scope

**Version**: 1.0.0  
**Date**: April 2026  
**Audience**: Engineering Managers, Team Leads, Scrum Masters  
**Purpose**: Objective measurement and validation of QA scope and performance

---

## Table of Contents

1. [Manager's Quick Reference](#managers-quick-reference)
2. [Observable Metrics (Don't Rely on Self-Reporting)](#observable-metrics)
3. [Sprint Planning Validation](#sprint-planning-validation)
4. [Team-Level Metrics](#team-level-metrics)
5. [Cross-Team Comparison](#cross-team-comparison)
6. [Red Flags and Intervention Points](#red-flags-and-intervention-points)
7. [Decision-Making Framework](#decision-making-framework)
8. [Manager Dashboard](#manager-dashboard)

---

## Manager's Quick Reference

### TL;DR - How to Measure QA Scope as a Manager

**Before Sprint** (Sprint Planning):
- ✅ Validate scope: 45-60 tests per QA in 10-day sprint
- ✅ Check story points: 13-21 points (mid-level QA)
- ✅ Verify dependencies: <3 dependencies per sprint
- ✅ Assess risk: High complexity + Junior QA = Reduce scope

**During Sprint** (Daily/Weekly):
- ✅ Monitor pass rate: Should improve daily (50% → 100% by Day 9)
- ✅ Track blockers: QA blocked >1 day = RED FLAG
- ✅ Watch bug count: 8-12 bugs = healthy, >15 bugs = CODE QUALITY ISSUE
- ✅ Check overtime: Working weekends = OVERSCOPED

**After Sprint** (Retrospective):
- ✅ Review velocity: Compare committed vs completed story points
- ✅ Check quality: Defect escape rate <10%
- ✅ Assess efficiency: Tests per hour vs baseline
- ✅ Adjust next sprint: Use actual velocity for planning

---

## Observable Metrics (Don't Rely on Self-Reporting)

### Why Observable Metrics Matter

**Problem**: QA engineers may:
- Over-report capacity to seem productive
- Under-report blockers to avoid escalation
- Not recognize overwork until burnout

**Solution**: Track **objective, system-generated metrics** that can't be gamed.

---

### 1. Test Artifact Metrics (Git-Based)

**What to Measure**: Count actual files committed to Git

#### Test Files Generated
```bash
# Count test specs generated
find tests/ -name "*.spec.js" -type f | wc -l

# Count by test type
find tests/functional/ -name "*.spec.js" | wc -l
find tests/api/ -name "*.spec.js" | wc -l
find tests/integration/ -name "*.spec.js" | wc -l
find tests/e2e/ -name "*.spec.js" | wc -l
```

**Benchmarks**:
- 10-day sprint: 45-60 test files
- 15-day sprint: 60-90 test files

**RED FLAGS**:
- ❌ <30 files in 10-day sprint = Underperforming or blocked
- ❌ >80 files in 10-day sprint = Overscoped or quality concerns

#### Page Objects Generated
```bash
# Count page objects
find pages/ -name "*.page.js" -type f | wc -l
```

**Benchmarks**:
- 10-day sprint: 10-15 page objects
- 15-day sprint: 15-25 page objects

#### Git Commit Activity
```bash
# QA engineer's commits in sprint
git log --author="QA_EMAIL" --since="2026-04-01" --until="2026-04-12" --oneline | wc -l

# Lines of code added/changed
git log --author="QA_EMAIL" --since="2026-04-01" --until="2026-04-12" --numstat --pretty="%H" | awk 'NF==3 {added+=$1; deleted+=$2} END {print "Added:", added, "Deleted:", deleted}'
```

**Benchmarks**:
- 15-30 commits per sprint (healthy activity)
- 2000-4000 lines added (test code + page objects)

**RED FLAGS**:
- ❌ <10 commits in 10-day sprint = Blocked or disengaged
- ❌ >50 commits in 10-day sprint = Thrashing, unclear scope

---

### 2. Test Execution Metrics (CI/CD-Based)

**What to Measure**: Playwright test results from CI/CD pipeline

#### Pass Rate Progression

**Track daily** (automated from test reports):

```bash
# Parse Playwright JSON report
cat test-results/report.json | jq '{
  total: .stats.expected,
  passed: .stats.passes,
  failed: .stats.failures,
  pass_rate: (.stats.passes / .stats.expected * 100)
}'
```

**Expected Progression** (10-day sprint):
| Day | Expected Pass Rate | Status |
|-----|-------------------|--------|
| 5   | 40-60% | ✅ On track |
| 6   | 75-80% | ✅ On track |
| 7   | 88-92% | ✅ On track |
| 8   | 93-95% | ✅ On track |
| 9   | 100% | ✅ Complete |

**RED FLAGS**:
- ❌ Day 7 pass rate <70% = Code quality issues or testing gaps
- ❌ Day 9 pass rate <95% = Scope too large or critical bugs remain
- ❌ No improvement Day 5 → Day 7 = Dev team not fixing bugs

#### Test Execution Time

```bash
# Track test execution duration
cat test-results/report.json | jq '.stats.duration'
```

**Benchmarks**:
- 45-60 tests: 8-12 minutes
- Target: <10 minutes

**RED FLAGS**:
- ❌ >15 minutes = Slow tests, needs optimization
- ❌ Execution time increasing daily = Flaky tests, poor test design

#### Flaky Test Rate

```bash
# Count tests that are flaky (pass sometimes, fail sometimes)
# Tracked over multiple runs
```

**Benchmarks**:
- <2% flaky tests = Excellent
- 2-5% flaky tests = Acceptable
- >5% flaky tests = Poor quality

**RED FLAGS**:
- ❌ >5% flaky tests = Code instability or poor test design
- ❌ Increasing flakiness = Environment issues

---

### 3. Bug Tracking Metrics (JIRA-Based)

**What to Measure**: Bug creation and resolution in JIRA

#### Bugs Logged by QA

**JIRA Query**:
```
project = "PROJECT_NAME" 
AND type = Bug 
AND reporter = "QA_EMAIL" 
AND created >= startOfSprint() 
AND created <= endOfSprint()
```

**Benchmarks**:
- 8-12 bugs per sprint = Healthy detection
- P1: 15-25%, P2: 30-40%, P3: 25-35%, P4: 10-15%

**RED FLAGS**:
- ❌ <5 bugs found = Not testing thoroughly OR code is perfect (unlikely)
- ❌ >20 bugs found = Code quality issues, rushed development
- ❌ >50% P1/P2 bugs = Critical code quality problems

#### Bug Fix Turnaround Time

**JIRA Query**:
```
project = "PROJECT_NAME" 
AND type = Bug 
AND status changed to "Resolved" 
AND priority = P1
```

**Calculate**: Time from "Open" → "Resolved"

**Benchmarks**:
- P1 bugs: <1 day
- P2 bugs: <2 days
- P3 bugs: <3 days

**RED FLAGS**:
- ❌ P1 bugs taking >2 days = Dev team capacity issues
- ❌ Bugs reopened multiple times = Poor bug understanding or fixes

#### Defect Escape Rate

**Formula**:
```
Defect Escape Rate = (Bugs found in UAT or Production / Total bugs) × 100
```

**Track in JIRA**:
```
# Bugs found by QA in sprint
Bugs_QA = COUNT(bugs WHERE found_in = "Testing")

# Bugs found in UAT/Production
Bugs_UAT = COUNT(bugs WHERE found_in = "UAT" OR found_in = "Production")

Escape_Rate = (Bugs_UAT / (Bugs_QA + Bugs_UAT)) × 100
```

**Benchmarks**:
- <10% escape rate = Excellent
- 10-15% escape rate = Acceptable
- >15% escape rate = Poor test coverage

**RED FLAGS**:
- ❌ >20% escape rate = Major gaps in testing
- ❌ Increasing escape rate over sprints = Quality degradation

---

### 4. Time Tracking Metrics (Optional)

**What to Measure**: Time spent on tasks (if using time tracking tools)

#### Time Distribution

**Healthy Distribution** (10-day sprint):
| Activity | Expected Time | % of Sprint |
|----------|---------------|-------------|
| Test Generation | 10-12 hours | 20-25% |
| Test Execution | 30-40 hours | 50-60% |
| Bug Reporting | 4-6 hours | 8-10% |
| Meetings | 8-10 hours | 12-15% |
| Documentation | 4-5 hours | 6-8% |

**RED FLAGS**:
- ❌ >40% time in meetings = Too many meetings, reduce overhead
- ❌ >70% time in test execution = No time for automation
- ❌ <15% time in test generation = Not automating, manual testing

#### Overtime Tracking

**Track**:
- Hours worked per day
- Weekend work
- After-hours work

**RED FLAGS**:
- ❌ Consistent >8 hours/day = Overscoped
- ❌ Weekend work = Burnout risk, scope too large
- ❌ After-hours work = Timezone issues or overcommitment

---

## Sprint Planning Validation

### Manager's Sprint Planning Checklist

**Use this during sprint planning to validate QA scope BEFORE sprint starts**

---

#### Step 1: Requirement-Based Validation

**Count Requirements**:

```markdown
## User Stories: _____ stories
## Acceptance Criteria: _____ ACs
```

**Apply Formula**:
```
Estimated Tests = ACs × 2.5

Example:
- 16 ACs × 2.5 = 40 tests ✅ (within 45-60 range)
- 30 ACs × 2.5 = 75 tests ❌ (exceeds 60 limit)
```

**Validation Rules**:
| Metric | Junior QA | Mid-Level QA | Senior QA |
|--------|-----------|--------------|-----------|
| User Stories | 3-5 | 5-8 | 8-12 |
| Acceptance Criteria | 8-12 | 12-20 | 20-30 |
| Estimated Tests | 20-30 | 45-60 | 60-90 |

**Manager Action**:
- ✅ Within range → Approve
- ⚠️ At upper limit → Add buffer, monitor closely
- ❌ Exceeds range → **REJECT SCOPE**, split stories

---

#### Step 2: Complexity Assessment

**Rate Module Complexity**:

```markdown
## Complexity Factors:
- [ ] Custom business logic (not standard CRUD)?
- [ ] External API integrations?
- [ ] Real-time features (WebSockets, polling)?
- [ ] Complex data transformations?
- [ ] Custom UI components (non-MDS)?
- [ ] Multiple third-party services?
- [ ] Performance requirements?
- [ ] Security/compliance requirements?

Score: _____ / 8
```

**Complexity Rating**:
- 0-2 factors: **Simple** (1.0x multiplier)
- 3-5 factors: **Medium** (1.3x multiplier)
- 6-8 factors: **Complex** (1.7x multiplier)

**Adjust Capacity**:
```
Adjusted Capacity = Base Capacity / Complexity Multiplier

Example:
- Base capacity (mid-level): 60 tests
- Medium complexity: 60 / 1.3 = 46 tests
- Complex module: 60 / 1.7 = 35 tests
```

**Manager Action**:
- Simple: Approve full capacity
- Medium: Reduce capacity by 25-30%
- Complex: Reduce capacity by 40-50% OR add senior QA

---

#### Step 3: Dependency Risk Assessment

**Count Dependencies**:

```markdown
## External Dependencies:
1. _____ (e.g., Third-party API)
2. _____ (e.g., Database migration by DBA team)
3. _____ (e.g., Environment setup by DevOps)
4. _____ 

Total Dependencies: _____
```

**Risk Matrix**:
| Dependencies | Risk Level | Recommended Action |
|--------------|------------|-------------------|
| 0-1 | LOW ✅ | Approve as planned |
| 2-3 | MEDIUM ⚠️ | Add 20% buffer, daily dependency check |
| 4-5 | HIGH 🔴 | Reduce scope by 30% OR defer dependent stories |
| 6+ | CRITICAL 🚨 | **REJECT SPRINT PLAN**, too risky |

**Manager Action**:
- LOW risk: Approve
- MEDIUM risk: Add buffer days, assign dependency owner
- HIGH risk: Descope or add resources
- CRITICAL risk: **Reject and replan**

---

#### Step 4: QA Experience vs Scope Matching

**Match QA experience to scope complexity**:

| QA Experience | Best Matched To | Max Story Points (10-day) |
|---------------|-----------------|---------------------------|
| **Junior** (0-2 years) | Simple modules, well-documented features | 8-13 points |
| **Mid-Level** (2-5 years) | Medium complexity, some unknowns | 13-21 points |
| **Senior** (5+ years) | Complex modules, high unknowns, new tech | 21-34 points |

**Mismatch Scenarios**:

❌ **Junior QA + Complex Module** = Recipe for failure
- **Problem**: Junior lacks experience for complexity
- **Manager Action**: Pair with senior QA OR simplify scope

❌ **Senior QA + Simple Module** = Underutilization
- **Problem**: Senior QA bored, not challenged
- **Manager Action**: Add tech debt work OR assign to mid-level QA

✅ **Mid-Level QA + Medium Module** = Perfect match
- **Manager Action**: Approve

---

#### Step 5: Historical Velocity Check

**Review Last 3 Sprints**:

```markdown
## QA: [Name]
## Sprint N-2: Committed ___ pts, Completed ___ pts (___% completion)
## Sprint N-1: Committed ___ pts, Completed ___ pts (___% completion)
## Sprint N  : Committed ___ pts, Completed ___ pts (___% completion)

## Average Velocity: _____ pts
## Average Completion: _____% 
```

**Velocity Trend Analysis**:

**Improving Velocity** (N-2: 10 pts → N-1: 13 pts → N: 16 pts):
- ✅ Healthy, QA is improving
- **Manager Action**: Approve higher commitment

**Stable Velocity** (N-2: 15 pts → N-1: 16 pts → N: 15 pts):
- ✅ Consistent, predictable
- **Manager Action**: Commit to average velocity

**Declining Velocity** (N-2: 20 pts → N-1: 15 pts → N: 12 pts):
- 🔴 **RED FLAG**: Investigate immediately
- **Possible causes**: Burnout, blockers, unclear requirements, personal issues
- **Manager Action**: 1-on-1 discussion, identify root cause

**Volatile Velocity** (N-2: 10 pts → N-1: 25 pts → N: 8 pts):
- 🔴 **RED FLAG**: Inconsistent scope or estimation issues
- **Manager Action**: Review estimation process, check for external blockers

---

#### Step 6: Team Balance Check

**Compare QA workload across team**:

| QA Engineer | Level | Story Points | Stories | ACs | Tests | Status |
|-------------|-------|--------------|---------|-----|-------|--------|
| Alice | Senior | 25 | 8 | 22 | 60 | ✅ Balanced |
| Bob | Mid | 16 | 6 | 16 | 45 | ✅ Balanced |
| Carol | Junior | 10 | 4 | 10 | 28 | ✅ Balanced |
| Dave | Mid | 8 | 3 | 8 | 22 | ⚠️ Underutilized |
| Eve | Mid | 28 | 12 | 35 | 90 | 🔴 **OVERLOADED** |

**RED FLAGS**:
- ❌ One QA has 2x+ story points vs peers = Unbalanced
- ❌ Junior QA has more than Mid-level = Incorrect assignment
- ❌ One QA consistently underutilized = Performance issue or mismatch

**Manager Action**:
- Rebalance workload across team
- Reassign stories from overloaded to underutilized QA
- Investigate why someone is consistently underutilized

---

### Sprint Planning Approval Decision Tree

```
START: QA proposes scope for sprint
  │
  ├─> Count stories/ACs/tests
  │   ├─> Within capacity range?
  │   │   ├─> YES → Continue to Step 2
  │   │   └─> NO → REJECT, reduce scope
  │
  ├─> Assess complexity
  │   ├─> Simple/Medium?
  │   │   ├─> YES → Continue to Step 3
  │   │   └─> NO (Complex) → Reduce capacity by 40% OR assign senior QA
  │
  ├─> Count dependencies
  │   ├─> <3 dependencies?
  │   │   ├─> YES → Continue to Step 4
  │   │   └─> NO (≥3) → Add buffer OR reduce scope
  │
  ├─> Match QA experience to complexity
  │   ├─> Appropriate match?
  │   │   ├─> YES → Continue to Step 5
  │   │   └─> NO → Reassign or pair with senior
  │
  ├─> Check historical velocity
  │   ├─> Committing ≤ average velocity?
  │   │   ├─> YES → Continue to Step 6
  │   │   └─> NO → Reduce commitment to average
  │
  └─> Team balance check
      ├─> Workload balanced across team?
      │   ├─> YES → ✅ APPROVE SPRINT
      │   └─> NO → Rebalance and re-review

```

---

## Team-Level Metrics

### Sprint Burndown (QA-Specific)

**Track story points remaining per day**:

```
Day 0: 16 points (sprint start)
Day 1: 16 points (test generation)
Day 2: 16 points (test generation)
Day 3: 16 points (test generation complete, testing starts)
Day 4: 13 points (3 points completed)
Day 5: 10 points (6 points completed)
Day 6: 8 points (8 points completed)
Day 7: 5 points (11 points completed)
Day 8: 3 points (13 points completed)
Day 9: 0 points (16 points completed) ✅
```

**Healthy Burndown**:
- Week 1: Flat or slow burn (test generation phase)
- Week 2: Steady burn (testing and bug fixes)
- Day 9-10: Zero remaining

**RED FLAGS**:
- ❌ Day 5 and still 16 points = Not started testing
- ❌ Day 8 and >50% points remaining = Won't finish on time
- ❌ Burndown going UP = Scope creep, stories added mid-sprint

---

### QA-to-Dev Handoff Metrics

**Measure handoff efficiency**:

#### Code Complete to QA Start Time
```
Time from "Code Complete" (Day 6) to "QA Testing Started"
```

**Benchmarks**:
- <4 hours: Excellent
- 4-8 hours: Good
- >8 hours: Handoff issues

**RED FLAGS**:
- ❌ >1 day delay = Communication breakdown

#### Stories in "In Testing" Status
```
JIRA Query: status = "In Testing" AND sprint = CURRENT_SPRINT
```

**Benchmarks**:
- Days 1-5: 0-2 stories (dev still coding)
- Days 6-8: 4-6 stories (active testing)
- Days 9-10: 0-1 stories (mostly complete)

**RED FLAGS**:
- ❌ Day 8 and >5 stories in testing = Too much WIP, bottleneck

#### Bug Reopen Rate
```
Bugs reopened after marked "Resolved"
```

**Benchmarks**:
- <10% bugs reopened: Excellent
- 10-20% bugs reopened: Acceptable
- >20% bugs reopened: Poor

**RED FLAGS**:
- ❌ >30% bugs reopened = Dev not understanding bugs OR QA not verifying properly

---

### Cross-Functional Metrics

#### QA Blocker Time

**Track time QA is blocked** (cannot proceed due to external dependency):

```
Blocker Time = Sum of hours QA is blocked per sprint
```

**Examples of blockers**:
- Environment down
- Waiting for API from another team
- Waiting for database migration
- Waiting for dev to complete feature

**Benchmarks**:
- <4 hours per sprint: Excellent
- 4-8 hours per sprint: Acceptable
- >8 hours per sprint: Too many blockers

**RED FLAGS**:
- ❌ >1 day blocked = Process issue, dependency management problem
- ❌ Recurrent blockers = Systemic issue, needs escalation

**Manager Action**:
- Track blocker reasons
- Address recurrent blocker sources
- Adjust sprint planning to avoid known blockers

---

### Test Automation Coverage

**Track automation vs manual testing**:

```
Automation Coverage = (Automated Tests / Total Tests) × 100
```

**Benchmarks**:
- >90% automation: Excellent
- 80-90% automation: Good
- <80% automation: Too much manual work

**Track trend over time**:
- Sprint 1: 70% automation
- Sprint 2: 80% automation ✅ Improving
- Sprint 3: 85% automation ✅ Improving
- Sprint 4: 83% automation ⚠️ Declining

**RED FLAGS**:
- ❌ Automation coverage declining = Technical debt increasing
- ❌ <60% automation = Not sustainable, hire more QA or invest in tools

---

## Cross-Team Comparison

### Normalizing Metrics Across Teams

**Challenge**: Different teams, different technologies, different complexities

**Solution**: Use **normalized metrics** (ratios, percentages, per-story metrics)

---

### 1. Tests per Story Point

**Formula**:
```
Tests per Story Point = Total Tests Generated / Story Points Completed
```

**Example**:
- Team A: 50 tests / 15 points = **3.3 tests/point**
- Team B: 45 tests / 18 points = **2.5 tests/point**

**Benchmarks**:
- 2-4 tests per story point: Normal
- <2 tests per story point: Under-testing OR stories too small
- >5 tests per story point: Over-testing OR stories too large

**Use Case**: Compare QA productivity across teams

---

### 2. Defect Density

**Formula**:
```
Defect Density = Bugs Found / Story Points
```

**Example**:
- Team A: 12 bugs / 15 points = **0.8 bugs/point**
- Team B: 20 bugs / 18 points = **1.1 bugs/point**

**Interpretation**:
- Team A: Lower defect density = Better code quality
- Team B: Higher defect density = Code quality issues OR more thorough testing

**RED FLAGS**:
- ❌ >1.5 bugs per story point = Code quality problem
- ❌ <0.3 bugs per story point = Not testing thoroughly

---

### 3. Test Execution Efficiency

**Formula**:
```
Efficiency = Tests Executed / Execution Time (minutes)
```

**Example**:
- Team A: 50 tests / 10 min = **5 tests/minute**
- Team B: 45 tests / 15 min = **3 tests/minute**

**Interpretation**:
- Team A: More efficient test suite (faster tests, better parallelization)
- Team B: Slower test suite (optimization needed)

**Benchmarks**:
- >4 tests/minute: Excellent
- 2-4 tests/minute: Good
- <2 tests/minute: Slow, needs optimization

---

### 4. Velocity Consistency

**Formula**:
```
Consistency = Standard Deviation of Story Points (last 3 sprints)
```

**Example**:
- Team A velocities: 15, 16, 15 pts → StdDev = **0.58** (very consistent)
- Team B velocities: 10, 20, 12 pts → StdDev = **5.29** (volatile)

**Interpretation**:
- Team A: Predictable, good sprint planning
- Team B: Unpredictable, scope issues or external blockers

**Benchmarks**:
- StdDev <2: Excellent consistency
- StdDev 2-4: Acceptable
- StdDev >5: Poor planning or unstable environment

---

## Red Flags and Intervention Points

### When to Intervene (Manager Actions)

---

### 🚨 **CRITICAL - Immediate Intervention**

#### 1. Zero Test Execution by Day 5

**Signal**: Day 5 (end of Week 1), no tests executed yet

**Root Causes**:
- Code not delivered by dev team
- QA blocked on environment setup
- QA spending all time on test generation (should be done by Day 3)

**Manager Action** (within 4 hours):
1. Emergency standup with dev lead and QA
2. Identify blocker (code delay, environment, scope)
3. If code delay: Escalate to dev manager
4. If environment: Escalate to DevOps
5. If scope too large: Descope immediately
6. **Outcome**: Testing starts within 1 business day

---

#### 2. Pass Rate <70% on Day 7

**Signal**: Day 7, after P1/P2 bugs should be fixed, pass rate still <70%

**Root Causes**:
- Dev team not fixing bugs fast enough
- Too many bugs (code quality issue)
- Bugs are complex (architecture issues)

**Manager Action** (same day):
1. Review bug backlog with dev lead
2. Triage: Which bugs MUST be fixed for sprint?
3. Pair program: Assign senior dev to help fix bugs
4. Descope: Move non-critical stories out of sprint
5. **Outcome**: Pass rate >85% by Day 8

---

#### 3. QA Working Weekends/Late Nights

**Signal**: QA responding to messages at 10 PM, working on weekends

**Root Causes**:
- Sprint overscoped
- Underestimated complexity
- QA doesn't know how to say no

**Manager Action** (next business day):
1. 1-on-1 with QA immediately
2. Review actual workload vs committed
3. Descope sprint (move stories to next sprint)
4. Communicate to stakeholders: "We overcommitted, adjusting scope"
5. **Outcome**: QA works normal hours

---

#### 4. UAT Failure Rate >20%

**Signal**: Day 10, UAT testing, >20% of scenarios fail

**Root Causes**:
- QA missed critical scenarios
- Requirements misunderstood
- Code pushed without proper testing

**Manager Action** (same day):
1. Hold retrospective: Why did we miss these scenarios?
2. Review test coverage vs UAT scenarios
3. Add missing test cases
4. Extend sprint OR defer deployment
5. **Outcome**: 100% UAT pass before deployment

---

### ⚠️ **WARNING - Monitor Closely**

#### 1. Velocity Declining 3 Sprints in a Row

**Signal**: Sprint N-2: 18 pts → Sprint N-1: 15 pts → Sprint N: 12 pts

**Root Causes**:
- QA burnout
- Increasing technical debt
- Tool/environment issues
- Personal issues

**Manager Action** (within 1 week):
1. 1-on-1 discussion with QA
2. Identify root cause (burnout, tech debt, personal)
3. Action based on cause:
   - Burnout: Reduce workload, add support
   - Tech debt: Allocate tech debt sprint
   - Personal: Offer flexibility, support
4. **Outcome**: Velocity stabilizes or improves

---

#### 2. Defect Escape Rate >15% for 2 Sprints

**Signal**: Bugs found in UAT/Production consistently >15%

**Root Causes**:
- Test coverage gaps
- QA rushing through testing
- Requirements changing late
- Complex features without adequate testing time

**Manager Action** (within 2 weeks):
1. Review test coverage vs features
2. Identify gap patterns (e.g., always missing edge cases)
3. Training: Test design, scenario thinking
4. Process change: More time for testing OR reduce scope
5. **Outcome**: Escape rate <10% in 2 sprints

---

#### 3. Flaky Test Rate >5%

**Signal**: Test suite has >5% flaky tests (pass sometimes, fail sometimes)

**Root Causes**:
- Poor test design (race conditions, waits)
- Environment instability
- Test data issues

**Manager Action** (within 1 sprint):
1. Allocate 20% of next sprint to fix flaky tests
2. Identify top 5 flaky tests
3. Root cause analysis for each
4. Fix or remove flaky tests
5. **Outcome**: Flaky rate <2%

---

#### 4. QA Blocked >1 Day per Sprint

**Signal**: QA reports blocked status for >8 hours in a sprint

**Root Causes**:
- Dependency on external teams
- Environment issues
- Waiting for dev to complete features

**Manager Action** (within sprint):
1. Track blocker reasons over 3 sprints
2. Identify recurrent blockers
3. Address root causes:
   - External team: Set up SLA or buffer time
   - Environment: Invest in stability
   - Dev delays: Adjust sprint planning
4. **Outcome**: Blocker time <4 hours per sprint

---

## Decision-Making Framework

### 1. Scope Adjustment Decision Matrix

**Use this when QA scope seems off**:

| Situation | Observed Metric | Decision | Action |
|-----------|----------------|----------|---------|
| **Underutilized QA** | <60% velocity, <30 tests/sprint | Increase scope | Add 3-5 story points OR assign tech debt |
| **Perfectly Loaded** | 80-95% velocity, 45-60 tests | Maintain | Approve current scope |
| **Slightly Overloaded** | 95-105% velocity, 60-70 tests | Monitor closely | Continue but watch daily, add buffer |
| **Overloaded** | >105% velocity, >70 tests | Reduce scope | Remove 5-10 story points immediately |
| **Critically Overloaded** | Working overtime, <70% pass rate Day 7 | Emergency descope | Cut 30-50% of scope, extend sprint |

---

### 2. Resource Allocation Decision Matrix

**Use this when deciding how to allocate QA resources**:

| Scenario | Current State | Recommended Action |
|----------|--------------|-------------------|
| **1 Complex Module** | 1 Mid-level QA assigned | ❌ Mismatch → Assign Senior QA OR Pair Mid+Senior |
| **2 Simple Modules** | 1 Senior QA assigned | ⚠️ Underutilization → Reassign to mid-level, give senior complex work |
| **8+ User Stories** | 1 QA assigned | ❌ Too much → Add 2nd QA OR Split across 2 sprints |
| **New Tech Stack** | Junior QA assigned | ❌ High risk → Assign Senior OR Pair Junior+Senior |
| **High Regulatory Requirements** | Any QA without compliance training | ❌ Compliance risk → Assign QA with compliance experience |

---

### 3. Quality vs Speed Trade-off Matrix

**Use this when stakeholders push for faster delivery**:

| Quality Level | Test Coverage | Defect Escape Risk | When to Use |
|---------------|---------------|-------------------|-------------|
| **Minimum Viable** | Functional tests only (~20 tests) | 20-30% escape rate | ⚠️ Prototype, throwaway code |
| **Standard** | Functional + API (~40 tests) | 10-15% escape rate | ✅ Most features, normal sprint |
| **High** | Functional + API + Integration (~55 tests) | 5-10% escape rate | ✅ Production features, default |
| **Critical** | All tests + Manual exploratory (~70+ tests) | <5% escape rate | 🔒 Security, payment, compliance features |

**Manager Decision**:
- Stakeholder: "Can we ship faster? Skip integration tests?"
- **NO** if: Security, compliance, payment, or core feature
- **MAYBE** if: Non-critical feature, can fix in production
- **YES** if: Prototype, demo, throwaway code

**Always communicate risk**: "If we skip integration tests, expect 15% defect escape rate (vs 5% with full testing). Are you comfortable with that risk?"

---

## Manager Dashboard

### Daily QA Dashboard (Auto-Generated)

**Purpose**: 5-minute daily check on QA health

**Metrics** (update daily at EOD):

```markdown
# QA Daily Dashboard - Sprint [Number] - Day [X]

## Team Overview
- Total QA Engineers: 3
- Total Story Points Committed: 50
- Story Points Completed: 28 (56%)
- Sprint Progress: 70% (Day 7 of 10)

## Individual Status
| QA | Points | Progress | Pass Rate | Blockers | Status |
|----|--------|----------|-----------|----------|--------|
| Alice | 21 | 15/21 (71%) | 90% | None | ✅ On Track |
| Bob | 16 | 8/16 (50%) | 75% | Environment | ⚠️ At Risk |
| Carol | 13 | 5/13 (38%) | 65% | None | 🔴 Behind |

## Quality Metrics
- Tests Generated: 52 / 60 (87%)
- Tests Passed: 42 / 52 (81%)
- Bugs Found: 9 (P1: 2, P2: 3, P3: 3, P4: 1)
- Defect Escape Rate: 0% (no UAT yet)

## Red Flags 🚩
- ⚠️ Bob blocked on environment (8 hours)
- 🔴 Carol behind schedule (38% vs 70% expected)

## Manager Actions Required
1. [ ] Check in with Bob on environment blocker
2. [ ] 1-on-1 with Carol to understand why behind
```

---

### Sprint-End QA Report (Auto-Generated)

**Purpose**: Retrospective data for continuous improvement

```markdown
# Sprint [Number] QA Report Card

## Commitment vs Delivery
- Committed: 50 story points
- Completed: 48 story points
- Completion Rate: 96% ✅

## Quality Metrics
| Metric | Target | Actual | Status |
|--------|--------|--------|--------|
| Test Coverage | 100% ACs | 100% | ✅ |
| Pass Rate (Final) | 100% | 100% | ✅ |
| Defect Escape Rate | <10% | 7% | ✅ |
| Bugs Found | 8-12 | 10 | ✅ |
| Flaky Test Rate | <2% | 1.2% | ✅ |

## Efficiency Metrics
| Metric | Target | Actual | Status |
|--------|--------|--------|--------|
| Tests per Hour | 4-5 | 4.8 | ✅ |
| Test Execution Time | <10 min | 9 min | ✅ |
| Blocker Time | <4 hours | 6 hours | ⚠️ |

## Velocity Trend (Last 3 Sprints)
- Sprint N-2: 45 points
- Sprint N-1: 48 points
- Sprint N: 48 points
- **Trend**: Stable ✅

## Red Flags This Sprint
- ⚠️ Blocker time 6 hours (environment instability)
- Action: Escalated to DevOps, monitoring next sprint

## Recommendations for Next Sprint
1. ✅ Velocity is stable at 48 points, commit same next sprint
2. ⚠️ Watch environment stability (caused 6-hour blocker)
3. ✅ Continue current scope balance (worked well)

## Sign-off
- Engineering Manager: ___________
- QA Lead: ___________
```

---

## Quick Decision Flowcharts

### Flowchart 1: Is QA Scope Right?

```
Sprint Planning: QA proposes scope
       ↓
  Count Tests/Story Points
       ↓
  45-60 tests? 13-21 points (mid-level)?
     / \
   YES  NO → Adjust scope → Re-review
    ↓
  Check Complexity
    ↓
  Simple/Medium?
     / \
   YES  NO → Reduce scope 30-50% → Re-review
    ↓
  Check Dependencies
    ↓
  <3 dependencies?
     / \
   YES  NO → Add buffer OR reduce scope → Re-review
    ↓
  Check Historical Velocity
    ↓
  Within last 3 sprint average?
     / \
   YES  NO → Reduce to average → Re-review
    ↓
  ✅ APPROVE SCOPE
```

---

### Flowchart 2: Should I Intervene?

```
Daily Check: Review QA metrics
       ↓
  Pass rate progressing as expected?
     / \
    NO  YES → Continue monitoring
    ↓
  What day of sprint?
    ↓
  Day 7 and <70% pass rate?
     / \
   YES  NO → Continue monitoring
    ↓
  🚨 CRITICAL: Intervene immediately
       ↓
  Emergency standup with dev+QA
       ↓
  Triage bugs, descope if needed
       ↓
  Track resolution daily
```

---

### Flowchart 3: Add More QA?

```
Current Sprint Status Review
       ↓
  Sprint velocity last 3 sprints?
       ↓
  Declining trend?
     / \
   YES  NO → Continue current staffing
    ↓
  Defect escape rate >15%?
     / \
   YES  NO → Fix test coverage first
    ↓
  QA working overtime regularly?
     / \
   YES  NO → Process issue, not staffing
    ↓
  Backlog growing (scope > capacity)?
     / \
   YES  NO → Prioritization issue
    ↓
  ✅ YES: Add QA resource
       ↓
  Decision: Hire OR Contractor OR Redistribute
```

---

## Summary for Engineering Managers

### The 3 Most Important Metrics

**Track these daily** (5-minute check):

1. **Pass Rate Progression**
   - Day 5: 40-60%
   - Day 7: 88-92%
   - Day 9: 100%
   - **RED FLAG**: Day 7 <70%

2. **Story Points Completion Rate**
   - Track: Committed vs Completed
   - Target: >90% completion
   - **RED FLAG**: <80% completion 2 sprints in row

3. **Blocker Time**
   - Track: Hours QA is blocked per sprint
   - Target: <4 hours
   - **RED FLAG**: >1 day blocked

---

### Weekly Manager 1-on-1 Questions

**Ask QA engineers in weekly 1-on-1**:

1. "What's your current pass rate?" (should improve weekly)
2. "Any blockers this week?" (should be <4 hours)
3. "Do you feel the sprint scope is right?" (check workload perception)
4. "What's one thing slowing you down?" (identify process issues)
5. "Do you have time for learning/tech debt?" (check if overworked)

---

### When to Escalate

**Escalate to Director/VP if**:
- 3 sprints in a row: Velocity declining OR escape rate >15%
- Consistent overtime across multiple QA engineers
- Systemic blockers (environment, tools, process) not resolved in 2 sprints
- Stakeholders pressuring to skip testing (quality vs speed conflict)

---

**Document Owner**: Engineering Management  
**Review Frequency**: Quarterly  
**Last Updated**: April 2026
