# 10-Day Sprint Quick Reference Card

**Sprint Duration**: 10 working days (Mon-Fri, 2 weeks)
**Weekends**: Excluded (Sat-Sun no work)

---

## Weekly Schedule

```
Week 1: Mon (Day 1) → Tue (Day 2) → Wed (Day 3) → Thu (Day 4) → Fri (Day 5)
        Planning    Tests Gen     E2E Tests    Testing     Week 1 QG

[WEEKEND]

Week 2: Mon (Day 6) → Tue (Day 7) → Wed (Day 8) → Thu (Day 9) → Fri (Day 10)
        Code Done   Bug Fixes    Regression   Healing     UAT Done
```

---

## Day-by-Day Commands & Gates

### Day 1 (Monday) - Sprint Planning + Functional Tests
**Activities**: Sprint planning, architecture, functional test generation
**Freeze**: Story Freeze (5:00 PM) ⚠️

```bash
# First sprint only
/setup-project

# After story freeze (5:00 PM)
/start-functional-tests {ModuleName}
```

**Time**: 3-5 hours (QA)
**Outputs**: Requirements, Functional tests (15-20 specs), Traceability matrix

---

### Day 2 (Tuesday) - API + Integration Tests
**Activities**: Schema finalization, API/Integration test generation
**Freeze**: API + DB Schema Freeze (5:00 PM) ⚠️
**Quality Gate 1**: End of Day

```bash
# After API/DB freeze (5:00 PM)
Start APITestAgent and IntegrationTestAgent for module {ModuleName}
```

**Time**: 4-5 hours (QA)
**Outputs**: API tests (10-15 specs), Integration tests (12-15 specs)

**Quality Gate 1 Exit**:
- ✓ All tests generated (37-50 specs)
- ✓ Traceability 100%
- ✓ Schemas frozen
- **Sign-off**: QA Lead + Dev Lead

---

### Day 3 (Wednesday) - E2E Tests + Backend Starts
**Activities**: E2E test generation, backend development begins

```bash
/start-e2e-tests {ModuleName}
```

**Time**: 6-7 hours (QA)
**Outputs**: E2E tests (8-10 specs), Test environment ready
**Total Tests**: 45-60 specs

---

### Day 4 (Thursday) - Backend Development + Initial Testing
**Activities**: Backend coding, initial test execution

```bash
# Run functional tests
npx playwright test tests/functional/{module}

# Run API tests
npx playwright test tests/api/{module}
```

**Time**: 6-7 hours (QA)
**Expected**: 40-50% pass rate (code not complete)

---

### Day 5 (Friday) - Full Testing - END OF WEEK 1
**Activities**: Backend 70-80% complete, full test execution
**Quality Gate 2**: End of Week 1

```bash
# Run all tests
npx playwright test

# Generate report
npx playwright show-report
```

**Time**: 6-8 hours (QA)
**Expected**: ~60% pass rate

**Quality Gate 2 Exit**:
- ✓ All tests generated (45-60 specs)
- ✓ Backend 70-80% complete
- ✓ Pass rate ~60%
- **Sign-off**: QA Lead + Dev Lead

---

## [WEEKEND - Saturday & Sunday]
**No work activities**

---

### Day 6 (Monday) - Code Complete + Bug Reporting
**Activities**: Backend 100% complete, full testing, bug logging

```bash
# Run complete test suite
npx playwright test
```

**Time**: 6-8 hours (QA)
**Expected**: 75-80% pass rate, 8-12 bugs logged

**Bugs Expected**:
- P1 (Critical): 2-3
- P2 (High): 3-4
- P3 (Medium): 2-3
- P4 (Low): 1-2

---

### Day 7 (Tuesday) - P1/P2 Bug Fixes
**Activities**: Fix P1/P2 bugs, regression testing
**Quality Gate 3**: End of Day

```bash
# Retest fixed bugs
npx playwright test --last-failed

# Full regression
npx playwright test
```

**Time**: 6-8 hours (QA)
**Expected**: 88-92% pass rate, P1/P2 fixed

**Quality Gate 3 Exit**:
- ✓ Code 100% complete
- ✓ P1/P2 bugs fixed
- ✓ Pass rate >85%
- **Sign-off**: Dev Lead + QA Lead

---

### Day 8 (Wednesday) - P3 Bug Fixes + Final Regression
**Activities**: Fix P3 bugs, final regression

```bash
# Final regression
npx playwright test
```

**Time**: 6-8 hours (QA)
**Expected**: 93-95% pass rate, only locator issues remain

---

### Day 9 (Thursday) - Locator Healing + 100% Pass
**Activities**: Heal locators, achieve 100% pass rate
**Quality Gate 4**: End of Day

```bash
# Heal locators
/heal-locators {ModuleName}

# Final regression
npx playwright test
```

**Time**: 6-7 hours (QA)
**Expected**: 100% pass rate ✓

**Quality Gate 4 Exit**:
- ✓ All bugs fixed (P1/P2/P3)
- ✓ Locators healed
- ✓ Pass rate 100%
- ✓ Coverage 100%
- **Sign-off**: QA Lead + PO

---

### Day 10 (Friday) - UAT + Final Sign-off - SPRINT COMPLETE
**Activities**: UAT testing, final reports, sign-off
**Quality Gate 5**: Sprint Complete

```bash
# UAT sanity tests
npx playwright test --grep "@smoke"

# Final regression (if needed)
npx playwright test
```

**Time**: 6-8 hours (QA)
**Expected**: UAT 100%, Production ready

**Quality Gate 5 Exit**:
- ✓ UAT complete (100%)
- ✓ PO sign-off
- ✓ All reports complete
- ✓ **READY FOR PRODUCTION** ✓
- **Sign-off**: PO + Dev Lead + QA Lead

---

## 5 Quality Gates Summary

| Gate | Day | Criteria | Sign-off |
|------|-----|----------|----------|
| **QG1** | Day 2 | Tests generated, Schemas frozen | QA + Dev |
| **QG2** | Day 5 | Week 1 complete, ~60% pass | QA + Dev |
| **QG3** | Day 7 | P1/P2 fixed, >85% pass | Dev + QA |
| **QG4** | Day 9 | 100% pass, All bugs fixed | QA + PO |
| **QG5** | Day 10 | UAT pass, Production ready | PO + Dev + QA |

---

## Freeze Points

- [ ] **Day 1 (5:00 PM)**: Story Freeze → START Functional Tests
- [ ] **Day 2 (5:00 PM)**: API + DB Freeze → START API + Integration Tests
- [ ] **Day 6**: Code Complete → Full Testing
- [ ] **Day 9**: Testing Complete → UAT Ready

---

## Test Pass Rate Progression

```
Day 4:  [████░░░░░░] 40-50% - Initial execution
Day 5:  [██████░░░░] ~60%   - Week 1 complete
Day 6:  [███████░░░] 75-80% - Code complete
Day 7:  [████████░░] 88-92% - P1/P2 fixed
Day 8:  [█████████░] 93-95% - P3 fixed
Day 9:  [██████████] 100%   - Healed! ✓
Day 10: [██████████] 100%   - UAT Done ✓
```

---

## Bug Resolution Timeline

```
Day 6:  📝 Found 8-12 bugs (P1: 2-3, P2: 3-4, P3: 2-3, P4: 1-2)
Day 7:  ✅ Fixed P1 + P2
Day 8:  ✅ Fixed P3, Deferred P4
Day 9:  ✅ All critical bugs resolved
```

---

## Test Artifacts Generated

| Type | Count | When |
|------|-------|------|
| Functional Tests | 15-20 | Day 1 |
| API Tests | 10-15 | Day 2 |
| Integration Tests | 12-15 | Day 2 |
| E2E Tests | 8-10 | Day 3 |
| **Total** | **45-60** | **Day 3** |

---

## Daily Time Investment (QA Team)

| Day | Hours | Intensity | Focus |
|-----|-------|-----------|-------|
| 1 | 3-5 | Medium | Functional generation |
| 2 | 4-5 | Medium | API + Integration |
| 3 | 6-7 | Medium-High | E2E + Environment |
| 4 | 6-7 | High | Initial testing |
| 5 | 6-8 | High | Full testing |
| **Weekend** | **0** | **Rest** | **No work** |
| 6 | 6-8 | High | Bug reporting |
| 7 | 6-8 | High | Bug retesting |
| 8 | 6-8 | High | Regression |
| 9 | 6-7 | Medium-High | Healing |
| 10 | 6-8 | Medium | UAT + Reports |

**Total**: 62-73 hours over 10 days
**Average**: 6-7 hours/day

---

## Approval Checkpoints

Each agent requires 4 approvals:
- Analysis Phase (5-10 min)
- Design Phase (5-10 min)
- Generation Phase (5-10 min)
- Validation Phase (5-10 min)

**Total per agent**: 20-40 minutes active approval time

**Total for sprint**:
- Day 1: Functional (4 approvals)
- Day 2: API + Integration (8 approvals)
- Day 3: E2E (4 approvals)
- Day 9: Healing (4 approvals)
- **Total**: 20 approvals across sprint

---

## Troubleshooting

### Tests failing with locator errors
**Day 9**: Run `/heal-locators {ModuleName}`

### Story freeze delayed
**Impact**: Shift Day 1 activities to Day 2
**Action**: Communicate timeline change

### Code not complete by Day 6
**Impact**: Week 2 timeline shifts
**Action**: Escalate to management

### High bug count (>15 bugs)
**Impact**: May not fix all by Day 8
**Action**: Triage, parallel fixing, extend 1 day if critical

---

## Success Metrics Checklist

- [ ] Day 1: 100% Requirements documented
- [ ] Day 2: 100% Tests generated (45-60 specs)
- [ ] Day 5: Week 1 complete, ~60% pass rate
- [ ] Day 7: P1/P2 bugs fixed, >85% pass rate
- [ ] Day 9: 100% pass rate, All bugs fixed
- [ ] Day 10: 100% UAT pass, PO sign-off

---

## Emergency Contacts

**Issue**: Agent stuck or error
**Action**: Check CLAUDE.md Troubleshooting section

**Issue**: MCP servers not working
**Action**: Tests still work (uses frontend code analysis)

**Issue**: Deadline pressure
**Action**: Prioritize P1/P2 bugs, defer P4, extend 1 day if needed

---

## Sprint Success Formula

```
Week 1 (Days 1-5):
✓ Generate ALL tests (45-60 specs)
✓ Execute tests (~60% pass)
✓ Backend 70-80% complete

[Weekend: Rest]

Week 2 (Days 6-10):
✓ Code complete (Day 6)
✓ Fix bugs (Days 6-8)
✓ Heal locators (Day 9)
✓ UAT + Sign-off (Day 10)

Result: 100% pass rate, Production ready! 🚀
```

---

**PRINT THIS PAGE AND KEEP AT YOUR DESK FOR THE 10-DAY SPRINT!**
