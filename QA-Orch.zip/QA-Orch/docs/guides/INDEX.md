# QA Scope & Sprint Planning - Complete Guide Index

**Version**: 1.0.0  
**Last Updated**: April 2026  
**Purpose**: Navigation guide for all QA scope and sprint planning documentation

---

## 📚 Document Overview

This index organizes all documentation related to **QA scope definition**, **sprint planning**, **performance measurement**, and **management**.

---

## 👥 By User Role

### 🧪 For QA Engineers

**Primary Documents**:
1. **[QA Scope and Performance Metrics](qa-scope-and-metrics.md)** ⭐ START HERE
   - Right scope for one person in a sprint
   - How to define QA scope
   - Performance measurement KPIs
   - Efficiency benchmarks
   - Red flags and bottlenecks

2. **[QA Story Points Guide](qa-story-points-guide.md)**
   - How many story points to pick up
   - Story point estimation by task complexity
   - Velocity calculation methods
   - Hybrid approach (shared + QA-specific stories)

3. **[10-Day Sprint Planning](10-day-sprint-planning.md)**
   - Day-by-day activities
   - Quality gates (5 gates)
   - Artifacts by day
   - Time budget

4. **[Sprint Quick Reference](sprint-quick-reference.md)** 📋 QUICK REFERENCE
   - Commands by day
   - Freeze points checklist
   - Time estimates
   - Troubleshooting

**When to Use Each**:
- **Sprint Planning**: Read "QA Scope and Metrics" + "Story Points Guide"
- **During Sprint**: Keep "Sprint Quick Reference" handy
- **First Time User**: Read "10-Day Sprint Planning" for full context
- **Daily Work**: Reference "Sprint Quick Reference" for commands

---

### 👔 For Engineering Managers

**Primary Documents**:
1. **[Manager's QA Scope Measurement Guide](manager-qa-scope-measurement.md)** ⭐ START HERE
   - Observable metrics (don't rely on self-reporting)
   - Sprint planning validation checklist
   - Team-level metrics
   - Cross-team comparison
   - Red flags and intervention points
   - Decision-making framework
   - Manager dashboard templates

2. **[Manager's Quick Reference Card](manager-quick-reference.md)** 📋 PRINT THIS
   - 1-page quick reference
   - Daily 5-minute check metrics
   - Sprint approval decision tree
   - Red flags checklist
   - Weekly 1-on-1 questions

**When to Use Each**:
- **Sprint Planning**: Use "Manager's Guide" validation checklist
- **Daily Checks**: Use "Quick Reference Card" (5-min review)
- **Intervention Needed**: Reference "Manager's Guide" decision frameworks
- **Quarterly Review**: Full "Manager's Guide" analysis

---

### 🎯 For Product Owners / Scrum Masters

**Primary Documents**:
1. **[10-Day Sprint Planning](10-day-sprint-planning.md)**
   - Quality gates and sign-offs
   - UAT preparation (Day 10)
   - Freeze points (story, API, DB, code complete)

2. **[QA Scope and Metrics](qa-scope-and-metrics.md)**
   - Understanding QA capacity
   - Scope boundaries (what's in/out)
   - Defect escape rate targets

**When to Use**:
- **Sprint Planning**: Understand QA capacity constraints
- **Mid-Sprint**: Monitor quality gate status
- **UAT Day**: Review UAT preparation checklist

---

## 📖 By Topic

### Topic 1: QA Capacity and Scope

**Documents**:
- [QA Scope and Performance Metrics](qa-scope-and-metrics.md) - Section: "Right Scope for One QA Person"
- [QA Story Points Guide](qa-story-points-guide.md) - Section: "QA Velocity by Sprint Type"
- [Manager's Guide](manager-qa-scope-measurement.md) - Section: "Sprint Planning Validation"

**Key Questions Answered**:
- ❓ How many user stories can one QA handle? → **5-8 stories (mid-level, 10-day sprint)**
- ❓ How many tests should be generated? → **45-60 automated tests**
- ❓ How many story points? → **13-21 points (mid-level, 10-day sprint)**
- ❓ How to calculate capacity? → **Use formula in scope guide**

---

### Topic 2: Story Point Estimation

**Documents**:
- [QA Story Points Guide](qa-story-points-guide.md) - Complete guide
- [Manager's Quick Reference](manager-quick-reference.md) - Section: "Story Point Estimation Quick Reference"

**Key Questions Answered**:
- ❓ How to estimate story points for QA work? → **Use Fibonacci scale: 1, 2, 3, 5, 8, 13**
- ❓ Story points = hours? → **1 point ≈ 3-4 hours**
- ❓ Story points = tests? → **1 point ≈ 3-4 tests**
- ❓ Should QA have separate story points? → **Use hybrid approach (80% shared, 20% QA-specific)**

---

### Topic 3: Performance Measurement

**Documents**:
- [QA Scope and Performance Metrics](qa-scope-and-metrics.md) - Section: "How to Measure QA Performance"
- [Manager's Guide](manager-qa-scope-measurement.md) - Section: "Observable Metrics"

**Key Metrics**:
- **Test Coverage**: 100% of acceptance criteria
- **Pass Rate Progression**: 50% → 100% (Days 5-9)
- **Defect Detection**: 8-12 bugs per sprint
- **Defect Escape Rate**: <10%
- **Test Generation Velocity**: 4-5 tests/hour (with QA Orchestrator)
- **Efficiency**: 5-8x faster than manual testing

---

### Topic 4: Sprint Planning

**Documents**:
- [10-Day Sprint Planning](10-day-sprint-planning.md) - Complete day-by-day plan
- [15-Day Sprint Planning](sprint-planning.md) - Extended timeline
- [Sprint Quick Reference](sprint-quick-reference.md) - Commands and timings

**Key Topics**:
- **Quality Gates**: 5 gates in 10-day sprint
- **Freeze Points**: Day 1 (story), Day 2 (API/DB), Day 6 (code complete)
- **Agent Execution**: When to run which agent
- **Time Budget**: 10-12 hours test generation, 30-40 hours execution

---

### Topic 5: Red Flags and Issues

**Documents**:
- [QA Scope and Metrics](qa-scope-and-metrics.md) - Section: "Red Flags and Bottlenecks"
- [Manager's Guide](manager-qa-scope-measurement.md) - Section: "Red Flags and Intervention Points"
- [Manager's Quick Reference](manager-quick-reference.md) - Section: "Red Flags Checklist"

**Critical Red Flags** 🚨:
- Pass rate <70% on Day 7
- QA working weekends/nights
- Velocity declining 3 sprints in a row
- Defect escape rate >15%
- >70 tests in 10-day sprint (overscoped)
- QA blocked >1 day per sprint

---

### Topic 6: Cross-Team Comparison

**Documents**:
- [Manager's Guide](manager-qa-scope-measurement.md) - Section: "Cross-Team Comparison"

**Normalized Metrics**:
- **Tests per Story Point**: 2-4 tests/point
- **Defect Density**: 0.5-1.0 bugs/point
- **Velocity Consistency**: Standard deviation <2
- **Test Execution Efficiency**: >4 tests/minute

---

## 🚀 Quick Start Paths

### Path 1: First-Time QA Engineer (Never Used QA Orchestrator)

**Read in this order**:
1. ✅ [10-Day Sprint Planning](10-day-sprint-planning.md) - Full context (30 min read)
2. ✅ [QA Story Points Guide](qa-story-points-guide.md) - Story point estimation (15 min)
3. ✅ [Sprint Quick Reference](sprint-quick-reference.md) - Keep handy for daily use (5 min review)
4. ✅ [QA Scope and Metrics](qa-scope-and-metrics.md) - Deep dive when needed (20 min)

**Total reading time**: ~1 hour

---

### Path 2: Experienced QA Engineer (Used Similar Tools)

**Read in this order**:
1. ✅ [Sprint Quick Reference](sprint-quick-reference.md) - Commands and timings (5 min)
2. ✅ [QA Scope and Metrics](qa-scope-and-metrics.md) - Capacity and metrics (20 min)
3. ✅ [QA Story Points Guide](qa-story-points-guide.md) - Skim for differences (10 min)

**Total reading time**: ~30 minutes

---

### Path 3: Engineering Manager (First Time Managing QA)

**Read in this order**:
1. ✅ [Manager's Quick Reference](manager-quick-reference.md) - 1-page overview (5 min)
2. ✅ [Manager's QA Scope Measurement Guide](manager-qa-scope-measurement.md) - Full guide (30 min)
3. ✅ [10-Day Sprint Planning](10-day-sprint-planning.md) - Understand QA workflow (20 min)

**Total reading time**: ~1 hour

**Keep at desk**: Manager's Quick Reference Card (print it!)

---

### Path 4: Senior Engineering Manager (Managing Multiple Teams)

**Read in this order**:
1. ✅ [Manager's Quick Reference](manager-quick-reference.md) - Metrics to track (5 min)
2. ✅ [Manager's Guide](manager-qa-scope-measurement.md) - Section: "Cross-Team Comparison" (10 min)
3. ✅ [Manager's Guide](manager-qa-scope-measurement.md) - Section: "Red Flags and Intervention" (10 min)

**Total reading time**: ~25 minutes

**Delegate**: Team leads read full guides, you review dashboards

---

## 📊 Cheat Sheets

### QA Capacity Cheat Sheet

| QA Level | 10-Day Sprint | 15-Day Sprint | Tests | Story Points |
|----------|---------------|---------------|-------|--------------|
| Junior | 3-5 stories, 8-12 ACs | 5-8 stories, 12-18 ACs | 25-35 | 8-13 pts |
| Mid-Level | 5-8 stories, 12-20 ACs | 8-12 stories, 20-30 ACs | 45-60 | 13-21 pts |
| Senior | 8-12 stories, 20-30 ACs | 12-18 stories, 30-45 ACs | 60-90 | 21-34 pts |

---

### Pass Rate Progression Cheat Sheet

| Day | Expected Pass Rate | Status |
|-----|-------------------|--------|
| Day 5 (Week 1 end) | 40-60% | ✅ On track |
| Day 6 (Code complete) | 75-80% | ✅ On track |
| Day 7 (P1/P2 fixed) | 88-92% | ✅ On track |
| Day 8 (P3 fixed) | 93-95% | ✅ On track |
| Day 9 (After healing) | 100% | ✅ Complete |

**Red Flag**: Day 7 <70% = Intervene immediately 🚨

---

### Story Point = Effort Cheat Sheet

| Points | Time | Tests | Example |
|--------|------|-------|---------|
| 1 pt | 4h | 3-5 | Field change |
| 2 pts | 6-8h | 6-10 | Add field |
| 3 pts | 10-12h | 10-15 | CRUD + validation |
| 5 pts | 16-20h | 15-25 | Integration |
| 8 pts | 24-32h | 25-40 | Complex workflow |
| 13 pts | 40-50h | 40-60 | Full module (SPLIT!) |

---

### Red Flags Cheat Sheet

**Intervene Immediately** 🚨:
- ❌ Day 5: No tests executed yet
- ❌ Day 7: Pass rate <70%
- ❌ Anytime: QA working weekends
- ❌ Day 10: UAT failure rate >20%

**Monitor Closely** ⚠️:
- ⚠️ Velocity declining 3 sprints in a row
- ⚠️ Defect escape rate >15% for 2 sprints
- ⚠️ Flaky test rate >5%
- ⚠️ QA blocked >1 day per sprint

---

## 🔄 Document Update History

| Date | Document | Change |
|------|----------|--------|
| 2026-04-01 | All documents | Initial creation |
| 2026-04-01 | INDEX.md | Created navigation index |

---

## 💡 Tips for Using These Documents

### For Sprint Planning
1. **Before sprint**: QA reads "Scope and Metrics" + "Story Points Guide"
2. **During sprint planning**: Manager uses validation checklist from "Manager's Guide"
3. **Sign-off**: Use templates from "10-Day Sprint Planning"

### For Daily Work
1. **Print**: Manager's Quick Reference Card
2. **Bookmark**: Sprint Quick Reference (QA engineers)
3. **Weekly review**: Manager dashboard in "Manager's Guide"

### For Retrospectives
1. **Review metrics**: From "Scope and Metrics" document
2. **Compare velocity**: Last 3 sprints from "Story Points Guide"
3. **Identify patterns**: Red flags section in "Manager's Guide"

---

## 📞 Support

**Questions about**:
- **Scope definition**: Read [QA Scope and Metrics](qa-scope-and-metrics.md)
- **Story points**: Read [Story Points Guide](qa-story-points-guide.md)
- **Sprint planning**: Read [10-Day Sprint Planning](10-day-sprint-planning.md)
- **Management**: Read [Manager's Guide](manager-qa-scope-measurement.md)

**Still have questions?**:
- Review CLAUDE.md - Troubleshooting section
- Check examples/ directory for working examples
- Review sprint retrospective notes

---

## 🎯 Success Metrics

**After reading and applying these guides, you should achieve**:

✅ **Predictable velocity**: ±2 story points variance per sprint  
✅ **High quality**: <10% defect escape rate  
✅ **Efficiency**: 5-8x faster test generation with QA Orchestrator  
✅ **Coverage**: 100% of acceptance criteria tested  
✅ **No overtime**: QA working normal hours  
✅ **Team confidence**: Clear expectations, measurable outcomes  

---

**Document Owner**: QA CoE  
**Maintained By**: QA Lead + Engineering Management  
**Review Frequency**: Quarterly  
**Last Updated**: April 2026

---

## 📁 File Locations

All guides are in: `docs/guides/`

```
docs/guides/
├── INDEX.md (this file)
├── qa-scope-and-metrics.md
├── qa-story-points-guide.md
├── manager-qa-scope-measurement.md
├── manager-quick-reference.md
├── 10-day-sprint-planning.md
├── sprint-planning.md (15-day)
└── sprint-quick-reference.md
```

---

**Navigation**: [↑ Back to Top](#qa-scope--sprint-planning---complete-guide-index)
