# Engineering Manager's QA Scope Quick Reference Card

**Version**: 1.0.0  
**Last Updated**: April 2026  
**Purpose**: 1-page quick reference for managers

---

## 🎯 The 3 Critical Metrics (Daily 5-Min Check)

| Metric | Day 5 | Day 7 | Day 9 | Red Flag |
|--------|-------|-------|-------|----------|
| **Pass Rate** | 40-60% | 88-92% | 100% | Day 7 <70% 🚨 |
| **Story Points Progress** | 20-30% | 60-70% | 95-100% | Day 7 <50% 🚨 |
| **Blocker Time** | <2 hours | <4 hours | <4 hours | >8 hours total 🚨 |

---

## 📊 Scope Validation Checklist (Sprint Planning)

**Use this to validate BEFORE sprint starts**:

```
□ Story count: 5-8 stories (mid-level QA) ✅
□ AC count: 12-20 ACs ✅
□ Estimated tests: 45-60 tests ✅
□ Story points: 13-21 points (mid-level) ✅
□ Complexity: Simple or Medium ✅
□ Dependencies: <3 external dependencies ✅
□ Historical velocity: Within last 3-sprint average ✅
□ Team balance: Similar workload across QA engineers ✅
```

**If 7-8 checkmarks**: ✅ **APPROVE**  
**If 5-6 checkmarks**: ⚠️ **APPROVE with monitoring**  
**If <5 checkmarks**: ❌ **REJECT - Adjust scope**

---

## 🚨 When to Intervene (Immediate Action Required)

| Signal | When | Root Cause | Action |
|--------|------|------------|--------|
| **No tests executed** | Day 5 | Code delay, blockers | Emergency standup, descope if needed |
| **Pass rate <70%** | Day 7 | Too many bugs, code quality | Triage bugs, pair program, descope |
| **QA working weekends** | Anytime | Overscoped sprint | 1-on-1, descope, communicate to stakeholders |
| **UAT failures >20%** | Day 10 | Missed scenarios, requirements unclear | Hold retrospective, extend sprint |

---

## 📈 Healthy vs Unhealthy Trends

### Healthy QA Team ✅

- **Velocity**: Stable or slowly improving (±2 points per sprint)
- **Pass rate**: Progresses 50% → 100% (Days 5-9)
- **Bug count**: 8-12 bugs per sprint
- **Defect escape rate**: <10%
- **Overtime**: Rare or none
- **Flaky tests**: <2%
- **Blocker time**: <4 hours per sprint

### Unhealthy QA Team 🚨

- **Velocity**: Declining 3 sprints in a row
- **Pass rate**: Flat or declining, <70% on Day 7
- **Bug count**: <5 (not testing) OR >20 (code quality issue)
- **Defect escape rate**: >15%
- **Overtime**: Regular weekends/late nights
- **Flaky tests**: >5%
- **Blocker time**: >1 day per sprint

---

## 🎓 QA Capacity by Experience Level

| Level | 10-Day Sprint | Tests | Story Points | Best For |
|-------|---------------|-------|--------------|----------|
| **Junior** | 3-5 stories, 8-12 ACs | 25-35 tests | 8-13 points | Simple modules, well-documented |
| **Mid-Level** | 5-8 stories, 12-20 ACs | 40-50 tests | 13-21 points | Medium complexity, some unknowns |
| **Senior** | 8-12 stories, 20-30 ACs | 55-65 tests | 21-34 points | Complex modules, new tech |

---

## ⚖️ Scope Adjustment Decision Matrix

| Observed Velocity | Observed Tests | Decision |
|-------------------|---------------|----------|
| <60% | <30 tests | **Increase scope** +5 points |
| 80-95% | 45-60 tests | **Perfect - Maintain** ✅ |
| 95-105% | 60-70 tests | **Monitor closely** ⚠️ |
| >105% | >70 tests | **Reduce scope** -10 points 🚨 |

---

## 🔍 Observable Metrics (Don't Rely on Self-Reporting)

**Use system-generated data**:

```bash
# Count test files generated
find tests/ -name "*.spec.js" | wc -l
# Target: 45-60 files

# Check Git commits
git log --author="QA_EMAIL" --since="sprint_start" --oneline | wc -l
# Target: 15-30 commits

# Parse test results
cat test-results/report.json | jq '.stats.passes / .stats.expected * 100'
# Target: 100% by Day 9

# Count bugs logged in JIRA
JIRA query: reporter = QA_EMAIL AND created >= startOfSprint()
# Target: 8-12 bugs
```

---

## 🧮 Complexity Adjustment Formula

```
Adjusted Capacity = Base Capacity / Complexity Multiplier

Complexity Multipliers:
- Simple module: 1.0x (CRUD, standard features)
- Medium module: 1.3x (some custom logic, 1-2 integrations)
- Complex module: 1.7x (heavy logic, multiple integrations)

Example:
- Base: 60 tests (mid-level QA)
- Medium module: 60 / 1.3 = 46 tests ✅
- Complex module: 60 / 1.7 = 35 tests ✅
```

---

## 💬 Weekly 1-on-1 Questions for QA

**Ask these 5 questions** (5 minutes):

1. "What's your current pass rate?" → Should improve weekly
2. "Any blockers this week?" → Should be <4 hours
3. "Does the sprint scope feel right?" → Check workload perception
4. "What's slowing you down?" → Identify process issues
5. "Time for learning/tech debt?" → Check if overworked

**Red flags in answers**:
- ❌ "I'm working nights/weekends" → Overscoped
- ❌ "Same blockers as last week" → Systemic issue
- ❌ "No time for anything except testing" → Overworked

---

## 🔄 Cross-Team Comparison Metrics

**Normalize metrics to compare teams**:

| Metric | Formula | Benchmark |
|--------|---------|-----------|
| **Tests per Story Point** | Tests / Story Points | 2-4 tests/point |
| **Defect Density** | Bugs / Story Points | 0.5-1.0 bugs/point |
| **Velocity Consistency** | StdDev of last 3 sprints | <2 is excellent |
| **Test Efficiency** | Tests / Execution Time | >4 tests/min |

---

## 🚦 Sprint Approval Decision Tree

```
1. Count stories/ACs/tests
   └─> Within range? → Continue | Too many? → REJECT

2. Assess complexity
   └─> Simple/Medium? → Continue | Complex? → Reduce 40%

3. Count dependencies
   └─> <3 deps? → Continue | ≥3 deps? → Add buffer

4. Check experience match
   └─> Appropriate? → Continue | Mismatch? → Reassign

5. Historical velocity
   └─> ≤ average? → Continue | > average? → Reduce

6. Team balance
   └─> Balanced? → APPROVE ✅ | Unbalanced? → Rebalance
```

---

## 📋 Red Flags Checklist

**Check daily - if ANY checked, investigate immediately**:

```
□ Pass rate <70% on Day 7
□ QA working weekends/nights
□ >1 day blocked per sprint
□ Velocity declining 3 sprints in a row
□ Defect escape rate >15%
□ >70 tests in 10-day sprint
□ UAT failure rate >20%
□ >5% flaky tests
□ Bugs found <5 (not testing) OR >20 (code quality)
□ Same blocker recurring multiple sprints
```

---

## 🎯 Quality vs Speed Trade-off Matrix

**When stakeholders push for faster delivery**:

| Test Coverage Level | Escape Risk | Use When |
|---------------------|-------------|----------|
| **Minimum** (Functional only, ~20 tests) | 20-30% | ⚠️ Prototype only |
| **Standard** (Functional + API, ~40 tests) | 10-15% | Non-critical features |
| **High** (Func + API + Integration, ~55 tests) | 5-10% | ✅ Default for production |
| **Critical** (All + Manual, ~70+ tests) | <5% | 🔒 Security, payments |

**Always communicate risk**: "Skipping integration tests = 15% escape rate (vs 5%). Acceptable?"

---

## 🔢 Story Point Estimation Quick Reference

| Story Points | QA Time | Tests | Example |
|--------------|---------|-------|---------|
| **1 point** | 4 hours | 3-5 | Simple field change |
| **2 points** | 6-8 hours | 6-10 | Add new field |
| **3 points** | 10-12 hours | 10-15 | CRUD + validation |
| **5 points** | 16-20 hours | 15-25 | Feature with integration |
| **8 points** | 24-32 hours | 25-40 | Complex workflow |
| **13 points** | 40-50 hours | 40-60 | Full module (TOO LARGE) |

---

## 🎯 Manager Actions by Sprint Phase

### Sprint Planning (Day 0)
- [ ] Validate scope using checklist
- [ ] Check team balance
- [ ] Approve or reject scope

### Week 1 (Days 1-5)
- [ ] Check test generation progress (should hit 45-60 tests by Day 3)
- [ ] Monitor blockers (<4 hours total)
- [ ] Check pass rate on Day 5 (should be 40-60%)

### Week 2 (Days 6-9)
- [ ] Monitor pass rate daily (should improve to 100% by Day 9)
- [ ] Track bug count (target 8-12 bugs)
- [ ] Watch for overtime (red flag)

### Sprint End (Day 10)
- [ ] Review velocity (committed vs completed)
- [ ] Check defect escape rate (<10%)
- [ ] Update capacity for next sprint

---

## 📞 When to Escalate

**Escalate to Director/VP if**:

- 🚨 3 sprints declining velocity OR escape rate >15%
- 🚨 Consistent overtime across multiple QA engineers
- 🚨 Systemic blockers not resolved in 2 sprints
- 🚨 Stakeholders pressuring to skip testing

---

## 📚 Related Documents

- **Full Guide**: `docs/guides/manager-qa-scope-measurement.md`
- **QA Scope & Metrics**: `docs/guides/qa-scope-and-metrics.md`
- **Story Points Guide**: `docs/guides/qa-story-points-guide.md`
- **Sprint Plans**: `docs/guides/10-day-sprint-planning.md`

---

**Print this card and keep at your desk for quick reference during sprint planning and daily checks.**

---

**Document Owner**: Engineering Management  
**Review**: Before every sprint planning  
**Last Updated**: April 2026
