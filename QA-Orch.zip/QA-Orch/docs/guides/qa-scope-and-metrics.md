# QA Scope Definition and Performance Metrics

**Version**: 1.0.0  
**Date**: April 2026  
**Purpose**: Define realistic QA scope for one person per sprint and establish performance measurement criteria

---

## Table of Contents

1. [Right Scope for One QA Person](#right-scope-for-one-qa-person)
2. [How to Define QA Scope in Sprint](#how-to-define-qa-scope-in-sprint)
3. [How to Measure QA Performance](#how-to-measure-qa-performance)
4. [Scope Calculation Formula](#scope-calculation-formula)
5. [Performance Benchmarks](#performance-benchmarks)
6. [Red Flags and Bottlenecks](#red-flags-and-bottlenecks)

---

## Right Scope for One QA Person

### TL;DR - Quick Answer

**For a 10-day sprint, one QA person can handle:**
- ✅ **1 module** with **5-8 user stories** and **12-20 acceptance criteria**
- ✅ Generates **45-60 automated test cases** (Functional + API + Integration + E2E)
- ✅ Executes **6-8 hours of testing per day** in Week 2
- ✅ Finds and tracks **8-12 bugs**
- ✅ Achieves **100% pass rate** by Day 10

**For a 15-day sprint, one QA person can handle:**
- ✅ **1-2 modules** with **8-12 user stories** and **20-30 acceptance criteria**
- ✅ Generates **60-90 automated test cases**
- ✅ More buffer time for complex integrations and E2E scenarios

---

## Detailed Breakdown by Sprint Type

### 10-Day Sprint (Recommended for One QA Person)

#### Week 1: Test Generation Phase

**Day 1: Functional Test Generation** (3-5 hours)
- Parse requirements: 1 module, 5-8 stories, 12-20 ACs
- Generate functional tests: 15-20 test specs
- Create page objects: 10-15 files
- Create traceability matrix
- **Realistic scope**: 1 module ONLY

**Day 2: API + Integration Test Generation** (4-5 hours)
- Generate API tests: 10-15 test specs
- Generate integration tests: 12-15 test specs
- Create API client utilities
- **Realistic scope**: Same module as Day 1

**Day 3: E2E Test Generation** (3-4 hours)
- Generate E2E tests: 8-10 test specs
- Set up test environment
- **Total tests generated**: 45-60 specs

**Day 4-5: Initial Test Execution** (12-14 hours total)
- Execute tests against incomplete code
- Document failures
- Track metrics
- **Expected pass rate**: 40-60%

#### Week 2: Testing & Bug Management Phase

**Day 6: Full Suite Execution** (6-8 hours)
- Execute complete test suite (45-60 tests)
- Log bugs: 8-12 bugs expected
- Create bug reports in JIRA
- **Expected pass rate**: 75-80%

**Day 7-8: Regression Testing** (12-16 hours total)
- Retest fixed bugs (P1/P2/P3)
- Run regression suite multiple times
- Update test data
- **Expected pass rate**: 93-95%

**Day 9: Locator Healing + Final Validation** (6-7 hours)
- Run locator healing agent (2 hours)
- Final regression test
- Generate reports
- **Expected pass rate**: 100%

**Day 10: UAT Support** (6-8 hours)
- Support UAT testing
- Generate final reports
- Sprint retrospective

---

### 15-Day Sprint (For 1-2 Modules)

#### Week 1: Same as 10-day sprint
- Days 1-5: Test generation + initial execution
- Generates 45-60 tests for Module 1

#### Week 2: Extends timeline
- Days 6-10: Can add Module 2 (if Module 1 is simple)
- Generate additional 20-30 tests for Module 2
- More buffer time for bug fixes

#### Week 3: Stabilization
- Days 11-15: More regression cycles
- UAT support
- Documentation

**Total Capacity**:
- **1 complex module** OR
- **2 simple modules** OR
- **1 module with extensive E2E scenarios**

---

## Scope Boundaries

### ✅ WITHIN SCOPE (One QA Person, 10-Day Sprint)

**Requirements**:
- 5-8 user stories
- 12-20 acceptance criteria
- 1 module (cohesive feature set)

**Test Generation**:
- 15-20 functional tests
- 10-15 API tests
- 12-15 integration tests
- 8-10 E2E tests
- **Total**: 45-60 automated tests

**Test Execution**:
- 3-4 full regression cycles (Days 6, 7, 8, 9)
- Bug tracking: 8-12 bugs
- Locator healing: 3-5 locators

**Documentation**:
- Test design documents (4 types)
- Traceability matrix
- Test execution reports
- UAT test scenarios
- Coverage report

**Time Budget**:
- Test generation: 10-12 hours (spread across Days 1-3)
- Test execution: 30-40 hours (Days 4-10)
- Approvals: 2-3 hours (agent checkpoints)
- Documentation: 4-5 hours (Days 9-10)
- **Total**: 46-60 hours (fits in 10-day sprint)

---

### ❌ OUT OF SCOPE (Too Much for One Person)

**Requirements**:
- More than 8 user stories in 10-day sprint
- More than 20 acceptance criteria
- 2+ complex modules simultaneously
- Cross-module integration scenarios

**Test Generation**:
- More than 70 automated tests
- Manual test case creation
- Performance testing
- Security testing
- Accessibility testing
- Load testing

**Test Execution**:
- Testing multiple modules in parallel
- Manual exploratory testing beyond UAT
- Testing against unstable environments
- Testing with incomplete requirements

**Additional Activities**:
- Test framework development
- Creating custom utilities beyond QA Orchestrator
- Training other team members
- Managing test environments
- DevOps/CI-CD pipeline setup

---

## How to Define QA Scope in Sprint

### Step-by-Step Scoping Process

#### Step 1: Requirements Analysis (Sprint Planning Day)

**Input**: JIRA Epic with user stories

**QA Analysis**:
1. Count user stories: _____ stories
2. Count acceptance criteria: _____ ACs
3. Identify test types needed:
   - [ ] Functional (always)
   - [ ] API (if backend changes)
   - [ ] Integration (if database changes)
   - [ ] E2E (if complete workflows)
4. Estimate test count:
   - Functional: ~2-3 tests per AC = _____ tests
   - API: ~1 test per endpoint = _____ tests
   - Integration: ~1-2 tests per AC = _____ tests
   - E2E: ~1 test per user journey = _____ tests
   - **Total estimate**: _____ tests

**Capacity Check**:
```
If Total Tests > 70: TOO MUCH SCOPE ❌
If Total Tests 45-60: PERFECT SCOPE ✅
If Total Tests < 40: ROOM FOR MORE ✅
```

#### Step 2: Complexity Assessment

**Simple Module** (1.0x multiplier):
- Standard CRUD operations
- MDS components only
- No external integrations
- Well-defined APIs
- Clear requirements

**Medium Module** (1.3x multiplier):
- Some custom logic
- Mix of MDS + custom components
- 1-2 external integrations
- Complex validation rules

**Complex Module** (1.7x multiplier):
- Heavy business logic
- Custom UI components
- Multiple external integrations
- Real-time features
- Complex data transformations
- Unclear requirements

**Adjusted Capacity**:
```
Simple module: Can handle 60 tests
Medium module: Can handle 45 tests (60 / 1.3)
Complex module: Can handle 35 tests (60 / 1.7)
```

#### Step 3: Dependency Mapping

**Map dependencies**:
- [ ] Depends on another team's API?
- [ ] Depends on external service?
- [ ] Depends on database setup?
- [ ] Depends on environment configuration?

**Risk Assessment**:
```
0-1 dependencies: LOW RISK ✅
2-3 dependencies: MEDIUM RISK ⚠️
4+ dependencies: HIGH RISK ❌ (reduce scope)
```

#### Step 4: Buffer Calculation

**Standard Buffer**: 20% for unknowns

**Adjusted Buffer**:
- First sprint of project: +30% buffer
- New QA engineer: +40% buffer
- Unstable environment: +25% buffer
- Unclear requirements: +35% buffer

**Example**:
```
Base capacity: 60 tests
Complex module (1.7x): 60 / 1.7 = 35 tests
First sprint (+30%): 35 * 0.7 = 25 tests

Final scope: 25 automated tests for complex module in first sprint
```

#### Step 5: Finalize Scope with Team

**Scope Document** (create during sprint planning):

```markdown
# QA Scope - Sprint [Number] - Module [Name]

## In Scope
- User Stories: [Story IDs]
- Acceptance Criteria: X ACs
- Test Types:
  - Functional: X tests
  - API: X tests
  - Integration: X tests
  - E2E: X tests
- Total: X automated tests

## Out of Scope
- [List what won't be tested]
- [Defer to next sprint]

## Dependencies
- [List dependencies and owners]

## Risks
- [List risks and mitigations]

## Acceptance Criteria
- [ ] X automated tests generated
- [ ] 100% pass rate by Day 10
- [ ] All P1/P2 bugs fixed
- [ ] UAT sign-off obtained
```

**Get sign-off from**:
- Dev Lead
- QA Lead
- Product Owner

---

## How to Measure QA Performance

### Key Performance Indicators (KPIs)

#### 1. Test Coverage Metrics

**Test Case Coverage**
```
Formula: (Test Cases Generated / Acceptance Criteria) × 100

Target: 100%
Excellent: 100%
Good: 90-99%
Needs Improvement: <90%

Measurement: Daily during test generation phase (Days 1-3)
```

**Traceability**
```
Formula: (ACs with Test Cases / Total ACs) × 100

Target: 100%
Excellent: 100%
Good: 95-99%
Needs Improvement: <95%

Measurement: End of Day 3
```

**Code Coverage** (if measured)
```
Target: >80% statement coverage
Excellent: >85%
Good: 80-85%
Acceptable: 75-80%
Needs Improvement: <75%

Measurement: End of sprint
```

---

#### 2. Test Execution Metrics

**Pass Rate Progression**
```
Day 5 (Week 1 end): 40-60% pass rate
Day 6 (Code complete): 75-80% pass rate
Day 7 (P1/P2 fixed): 88-92% pass rate
Day 8 (P3 fixed): 93-95% pass rate
Day 9 (After healing): 100% pass rate
Day 10 (UAT): 100% pass rate

Target: Achieve 100% by Day 9
Excellent: 100% by Day 9
Good: 100% by Day 10
Needs Improvement: <100% at sprint end
```

**Test Execution Speed**
```
Formula: Total Tests / Execution Time

Target: Complete 45-60 tests in <10 minutes
Excellent: <8 minutes
Good: 8-10 minutes
Needs Improvement: >10 minutes

Measurement: Days 6-10 (track daily)
```

**Regression Stability**
```
Formula: (Tests Passed Consistently / Total Tests) × 100

Target: >95% stability (same tests pass across runs)
Excellent: >98%
Good: 95-98%
Needs Improvement: <95%

Measurement: Days 7-10
```

---

#### 3. Defect Detection Metrics

**Defect Detection Rate**
```
Formula: Total Bugs Found / Test Execution Hours

Industry Average: 1-2 bugs per day
Target: 8-12 bugs in sprint
Excellent: 10-15 bugs found
Good: 8-10 bugs found
Acceptable: 5-7 bugs found
Concerning: <5 bugs (not testing thoroughly)

Measurement: Days 6-9
```

**Defect Severity Distribution**
```
Healthy Distribution:
- P1 (Critical): 15-25%
- P2 (High): 30-40%
- P3 (Medium): 25-35%
- P4 (Low): 10-15%

Example (10 bugs):
- P1: 2 bugs (20%)
- P2: 4 bugs (40%)
- P3: 3 bugs (30%)
- P4: 1 bug (10%)

Red Flag: >50% P1/P2 bugs (code quality issues)
```

**Defect Escape Rate** (bugs found in UAT)
```
Formula: (Bugs Found in UAT / Total Bugs) × 100

Target: <10% escape rate
Excellent: 0-5%
Good: 5-10%
Needs Improvement: >10%

Measurement: Day 10 (after UAT)
```

---

#### 4. Efficiency Metrics

**Test Generation Velocity**
```
Formula: Tests Generated / Generation Hours

Target: 4-5 tests per hour (with QA Orchestrator)
Excellent: >6 tests/hour
Good: 4-5 tests/hour
Acceptable: 3-4 tests/hour
Needs Improvement: <3 tests/hour

Measurement: Days 1-3

Note: Manual test writing = 0.5-1 test/hour
QA Orchestrator = 4-5 tests/hour (8-10x faster)
```

**Approval Response Time**
```
Formula: Time between agent checkpoint and approval

Target: <10 minutes per checkpoint
Excellent: <5 minutes
Good: 5-10 minutes
Needs Improvement: >10 minutes

Measurement: Days 1-3 (during agent execution)
```

**Locator Healing Effectiveness**
```
Formula: (Healed Locators / Total Broken Locators) × 100

Target: >95% heal rate
Excellent: 100%
Good: 95-99%
Needs Improvement: <95%

Measurement: Day 9 (after healing)
```

---

#### 5. Quality Metrics

**Requirements Clarity Score**
```
Based on:
- How many clarifications needed?
- How many requirement defects found?
- How many ACs changed mid-sprint?

Excellent: 0-1 requirement issues
Good: 2-3 issues
Needs Improvement: >3 issues

Measurement: Throughout sprint, report in retrospective
```

**Test Flakiness Rate**
```
Formula: (Flaky Test Runs / Total Test Runs) × 100

Flaky = test passes sometimes, fails sometimes (same code)

Target: <2% flaky tests
Excellent: 0-1%
Good: 1-2%
Needs Improvement: >2%

Measurement: Days 7-10
```

**UAT Success Rate**
```
Formula: (UAT Scenarios Passed / Total UAT Scenarios) × 100

Target: 100%
Excellent: 100%
Good: 95-100%
Needs Improvement: <95%

Measurement: Day 10
```

---

#### 6. Collaboration Metrics

**Freeze Point Adherence**
```
Tracked:
- Day 1 EOD: Story freeze on time? (Yes/No)
- Day 2 EOD: API/DB freeze on time? (Yes/No)
- Day 6: Code complete on time? (Yes/No)

Target: 100% adherence (3/3 on time)
Excellent: 3/3
Good: 2/3
Needs Improvement: <2/3

Measurement: Days 1, 2, 6
```

**Bug Fix Turnaround Time**
```
Formula: Time from bug logged to bug fixed

Target:
- P1 bugs: <1 day
- P2 bugs: <2 days
- P3 bugs: <3 days

Excellent: All bugs fixed within target
Good: 80% within target
Needs Improvement: <80% within target

Measurement: Days 7-9
```

---

### Performance Dashboards

#### Daily QA Dashboard

**Update Daily** (15 minutes EOD):

```markdown
# QA Daily Status - Day X

## Test Execution
- Tests Passed: X / Y (Z%)
- New Failures: X
- Fixed Failures: X
- Flaky Tests: X

## Bugs
- Bugs Logged Today: X
- P1: X, P2: X, P3: X, P4: X
- Bugs Fixed Today: X
- Bugs Retested: X

## Progress
- [ ] Day X tasks complete
- [ ] Blocking issues: [None / List]
- [ ] Risk items: [None / List]

## Tomorrow's Plan
- [List activities]
```

#### Sprint-End QA Report

**Generate on Day 10**:

```markdown
# QA Sprint Report - Sprint [Number]

## Summary
- **Module**: [Name]
- **User Stories**: X
- **Acceptance Criteria**: X
- **Test Cases Generated**: X
- **Pass Rate**: 100%
- **Bugs Found**: X (P1: X, P2: X, P3: X, P4: X)
- **Defect Escape Rate**: X%
- **UAT Success Rate**: 100%

## Metrics

### Test Coverage
- Requirement Coverage: 100%
- AC Coverage: 100%
- Traceability: 100%
- Code Coverage: X%

### Test Execution
| Day | Pass Rate | Tests Run | Execution Time |
|-----|-----------|-----------|----------------|
| 5   | 50%       | 45        | 8 min          |
| 6   | 78%       | 45        | 8 min          |
| 7   | 90%       | 45        | 8 min          |
| 8   | 95%       | 45        | 8 min          |
| 9   | 100%      | 45        | 8 min          |
| 10  | 100%      | 45        | 8 min          |

### Defects
- Total Bugs: X
- Fixed: X
- Deferred: X (all P4)
- Escape Rate: X%

### Efficiency
- Test Generation Velocity: X tests/hour
- Tests Generated: X in Y hours
- Orchestrator Usage: 100%
- Time Saved: ~XX hours (vs manual)

### Quality
- Freeze Point Adherence: 3/3 (100%)
- Flaky Test Rate: X%
- Locator Heal Rate: 100%

## Achievements
- ✅ [List achievements]

## Challenges
- ⚠️ [List challenges]

## Improvements for Next Sprint
- 📝 [List improvements]

## Sign-off
- QA Engineer: ___________
- Dev Lead: ___________
- PO: ___________
```

---

## Scope Calculation Formula

### Formula for Maximum Scope

```python
# Base capacity for one QA person in 10-day sprint
BASE_CAPACITY = 60  # automated tests

# Complexity multiplier
def get_complexity_multiplier(module_type):
    if module_type == "simple":
        return 1.0
    elif module_type == "medium":
        return 1.3
    elif module_type == "complex":
        return 1.7
    else:
        return 1.5  # default

# Experience multiplier
def get_experience_multiplier(experience_level):
    if experience_level == "senior":
        return 1.0
    elif experience_level == "mid":
        return 1.2
    elif experience_level == "junior":
        return 1.5
    else:
        return 1.2  # default

# Environment stability multiplier
def get_environment_multiplier(stability):
    if stability == "stable":
        return 1.0
    elif stability == "moderate":
        return 1.1
    elif stability == "unstable":
        return 1.3
    else:
        return 1.1  # default

# Sprint type multiplier
def get_sprint_multiplier(sprint_type):
    if sprint_type == "first":
        return 1.3  # First sprint, more unknowns
    elif sprint_type == "ongoing":
        return 1.0
    else:
        return 1.0

# Calculate maximum tests
def calculate_max_tests(module_type, experience_level, environment_stability, sprint_type):
    complexity = get_complexity_multiplier(module_type)
    experience = get_experience_multiplier(experience_level)
    environment = get_environment_multiplier(environment_stability)
    sprint = get_sprint_multiplier(sprint_type)
    
    total_multiplier = complexity * experience * environment * sprint
    max_tests = BASE_CAPACITY / total_multiplier
    
    return int(max_tests)

# Example usage
max_tests = calculate_max_tests(
    module_type="medium",
    experience_level="mid",
    environment_stability="stable",
    sprint_type="ongoing"
)

print(f"Maximum tests: {max_tests}")
# Output: Maximum tests: 38 tests
```

### Example Calculations

**Scenario 1: Ideal Conditions**
- Simple module (1.0x)
- Senior QA (1.0x)
- Stable environment (1.0x)
- Ongoing sprint (1.0x)
- **Max tests**: 60 tests ✅

**Scenario 2: Typical Conditions**
- Medium module (1.3x)
- Mid-level QA (1.2x)
- Stable environment (1.0x)
- Ongoing sprint (1.0x)
- **Max tests**: 60 / (1.3 × 1.2) = 38 tests ✅

**Scenario 3: Challenging Conditions**
- Complex module (1.7x)
- Junior QA (1.5x)
- Unstable environment (1.3x)
- First sprint (1.3x)
- **Max tests**: 60 / (1.7 × 1.5 × 1.3 × 1.3) = 14 tests ⚠️
- **Recommendation**: Reduce scope or extend sprint

---

## Performance Benchmarks

### Industry Standard vs QA Orchestrator

| Metric | Manual Testing | With QA Orchestrator | Improvement |
|--------|----------------|----------------------|-------------|
| **Test Generation** | 0.5-1 test/hour | 4-5 tests/hour | 8-10x faster |
| **Time to Generate 50 Tests** | 50-100 hours | 10-12 hours | 5-8x faster |
| **Page Object Creation** | 30-60 min/page | 5-10 min/page | 5x faster |
| **Traceability Matrix** | 4-6 hours | 30 min (auto) | 8-12x faster |
| **Locator Healing** | 2-4 hours | 1-2 hours | 2x faster |
| **Documentation** | 8-10 hours | 2-3 hours | 4x faster |
| **Total Time for 1 Module** | 120-150 hours | 46-60 hours | 2.5x faster |

### Sprint Velocity Benchmarks

**10-Day Sprint**:
- Junior QA: 25-35 tests
- Mid-level QA: 40-50 tests
- Senior QA: 55-65 tests

**15-Day Sprint**:
- Junior QA: 40-50 tests
- Mid-level QA: 60-75 tests
- Senior QA: 80-100 tests

---

## Red Flags and Bottlenecks

### 🚩 Red Flags (Immediate Action Required)

**Scope Red Flags**:
- ❌ More than 70 tests assigned to one QA in 10-day sprint
- ❌ More than 10 user stories in one sprint
- ❌ Requirements still changing after Day 2
- ❌ Code complete delayed beyond Day 7
- ❌ More than 15 bugs found by Day 9

**Performance Red Flags**:
- ❌ Pass rate <70% on Day 7 (after P1/P2 fixes)
- ❌ More than 5% flaky tests
- ❌ UAT pass rate <95%
- ❌ Defect escape rate >10%
- ❌ Test execution time >15 minutes

**Process Red Flags**:
- ❌ Freeze points not met (story, API, DB, code complete)
- ❌ QA blocked for >1 day
- ❌ Bug fix turnaround >2 days for P1 bugs
- ❌ No time for locator healing
- ❌ Working overtime regularly

### ⚠️ Bottlenecks (Needs Attention)

**Common Bottlenecks**:
1. **Unclear Requirements**
   - Impact: 30-50% time waste
   - Solution: Requirements review session on Day 0

2. **Environment Instability**
   - Impact: 20-30% time waste
   - Solution: Dedicated DevOps support

3. **Late Code Complete**
   - Impact: Compression of testing window
   - Solution: Strict enforcement of Day 6 code complete

4. **Too Many Locator Failures**
   - Impact: 4-8 hours of healing time
   - Solution: Frontend code quality review, enforce data-testid

5. **High Bug Count**
   - Impact: Multiple regression cycles
   - Solution: Dev code reviews before QA handoff

### Resolution Strategies

**If Scope Too Large (>70 tests)**:
1. Split into 2 sprints
2. Add another QA engineer
3. Defer E2E tests to next sprint
4. Reduce AC count (de-scope features)

**If Behind Schedule**:
1. Prioritize Functional + API tests
2. Defer Integration tests
3. Skip E2E test generation
4. Request code freeze extension

**If Quality Issues**:
1. Stop new feature testing
2. Focus on regression testing
3. Create critical path test suite
4. Request dev team support

---

## Practical Examples

### Example 1: Well-Scoped Sprint ✅

**Module**: User Management  
**User Stories**: 6  
**Acceptance Criteria**: 15  
**Complexity**: Medium

**Estimated Tests**:
- Functional: 18 tests (15 ACs × 1.2)
- API: 8 tests (8 endpoints)
- Integration: 12 tests (15 ACs × 0.8)
- E2E: 6 tests (3 user journeys × 2)
- **Total**: 44 tests ✅

**Capacity Check**:
- QA Level: Mid-level
- Module Complexity: Medium (1.3x)
- Environment: Stable (1.0x)
- Sprint Type: Ongoing (1.0x)
- **Max capacity**: 60 / 1.3 = 46 tests
- **Actual tests**: 44 tests
- **Verdict**: ✅ WITHIN SCOPE

**Outcome**: Sprint completed successfully, 100% pass rate by Day 9.

---

### Example 2: Over-Scoped Sprint ❌

**Module**: Payroll Calculation  
**User Stories**: 12  
**Acceptance Criteria**: 30  
**Complexity**: Complex

**Estimated Tests**:
- Functional: 36 tests (30 ACs × 1.2)
- API: 15 tests (15 endpoints)
- Integration: 24 tests (30 ACs × 0.8)
- E2E: 10 tests (5 user journeys × 2)
- **Total**: 85 tests ❌

**Capacity Check**:
- QA Level: Mid-level
- Module Complexity: Complex (1.7x)
- Environment: Stable (1.0x)
- Sprint Type: First (1.3x)
- **Max capacity**: 60 / (1.7 × 1.3) = 27 tests
- **Actual tests**: 85 tests
- **Verdict**: ❌ SEVERELY OVER-SCOPED (3x over capacity)

**Recommendations**:
1. Split into 3 sprints
2. Add 2 more QA engineers
3. OR reduce scope to critical features only

**What Happened**: Sprint failed, only 40% tests completed, carried over to next sprint.

---

### Example 3: Right-Sized Complex Module ✅

**Module**: Real-time Dashboard  
**User Stories**: 4  
**Acceptance Criteria**: 12  
**Complexity**: Complex

**Estimated Tests**:
- Functional: 14 tests (12 ACs × 1.2)
- API: 6 tests (6 WebSocket endpoints)
- Integration: 10 tests (12 ACs × 0.8)
- E2E: 6 tests (3 real-time scenarios × 2)
- **Total**: 36 tests ✅

**Capacity Check**:
- QA Level: Senior
- Module Complexity: Complex (1.7x)
- Environment: Moderate (1.1x)
- Sprint Type: Ongoing (1.0x)
- **Max capacity**: 60 / (1.7 × 1.1) = 32 tests
- **Actual tests**: 36 tests
- **Verdict**: ⚠️ SLIGHTLY OVER (manageable for senior QA)

**Adjustments Made**:
- Used 15-day sprint instead of 10-day
- Added 3 buffer days
- Senior QA handled complexity well

**Outcome**: Sprint completed successfully with 2-day buffer remaining.

---

## Summary

### Golden Rules for QA Scoping

1. **One QA person in 10-day sprint**: 45-60 automated tests (1 simple-medium module)
2. **One QA person in 15-day sprint**: 60-90 automated tests (1 complex OR 2 simple modules)
3. **Always apply complexity multiplier**: Simple 1.0x, Medium 1.3x, Complex 1.7x
4. **Respect freeze points**: Story (Day 1), API/DB (Day 2), Code (Day 6)
5. **Buffer 20-30%**: For unknowns, first sprints, or unclear requirements

### Performance Measurement Essentials

**Must Track**:
- Test coverage: 100%
- Pass rate progression: 50% → 100% (Days 5-9)
- Defect detection: 8-12 bugs per sprint
- Defect escape rate: <10%
- UAT success rate: 100%

**Nice to Have**:
- Test generation velocity: 4-5 tests/hour
- Regression stability: >95%
- Flaky test rate: <2%
- Bug fix turnaround: P1 <1 day, P2 <2 days

### Red Flags Checklist

- [ ] More than 70 tests in 10-day sprint?
- [ ] More than 10 user stories?
- [ ] Pass rate <70% on Day 7?
- [ ] Defect escape rate >10%?
- [ ] Freeze points not met?
- [ ] Working overtime regularly?

**If any checked**: Reduce scope or add resources IMMEDIATELY.

---

## Next Steps

1. **Calculate your capacity**: Use the formula with your team's parameters
2. **Define scope**: Use the scoping process during sprint planning
3. **Track metrics**: Use the daily dashboard and sprint report templates
4. **Review quarterly**: Adjust multipliers based on actual performance
5. **Improve continuously**: Use retrospectives to refine estimates

---

**Document Owner**: QA Lead  
**Review Frequency**: Quarterly  
**Last Updated**: April 2026
