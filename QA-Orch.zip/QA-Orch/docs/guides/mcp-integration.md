# MCP Server Setup and Configuration

**Version**: 3.0.0
**Purpose**: Configure required MCP servers for the Test Orchestrator’s v3.0 agent-driven setup

---

## Overview

The Test Orchestrator requires **THREE MCP servers** to function optimally:

1. **MDS MCP Server** - Design System component documentation
2. **Platform UI Shell Helpers MCP Server** - Shell helper documentation
3. **Chrome DevTools MCP Server** - DOM inspection and locator extraction

---

## MCP Servers Configuration

### 1. MDS MCP Server

**Purpose**: Get exact MDS components, props, events, slots that developers use in frontend

**When Required**:
- ✅ BEFORE generating functional tests
- ✅ BEFORE generating integration tests
- ✅ BEFORE generating E2E tests

**Why Critical**:
- Provides **exact component specifications** from design system
- Ensures generated page objects use **correct props and events**
- Increases locator confidence from **90% → 98%**
- Prevents mismatches between test code and frontend implementation

**Tools Provided**:
- `mcp__mds-mcp__listAllComponents` - List all MDS components
- `mcp__mds-mcp__getComponentDocs` - Get component documentation (props, events, slots)
- `mcp__mds-mcp__getComponentExamples` - Get usage examples
- `mcp__mds-mcp__getUtilityClasses` - Get utility CSS classes
- `mcp__mds-mcp__getDesignTokens` - Get design tokens

**Configuration** (in orchestrator-config.json):
```json
{
  "mcpServers": {
    "mds": {
      "enabled": true,
      "required": true,
      "name": "mds-mcp"
    }
  }
}
```

---

### 2. Platform UI Shell Helpers MCP Server

**Purpose**: Get documentation for @platform-ui/shell-helpers used in frontend

**When Required**:
- ✅ BEFORE generating functional tests
- ✅ BEFORE generating integration tests
- ✅ BEFORE generating E2E tests

**Why Critical**:
- Provides **shell helper documentation** (logger, http, storage, etc.)
- Ensures test code uses **correct helper APIs**
- Documents **best practices** for helper usage
- Prevents API mismatches and runtime errors

**Tools Provided**:
- `mcp__platform-ui__list_shell_helpers` - List all available helpers
- `mcp__platform-ui__get_shell_helper_docs` - Get helper documentation
- `mcp__platform-ui__get_shell_helper_examples` - Get usage examples

**Configuration** (in orchestrator-config.json):
```json
{
  "mcpServers": {
    "platformUI": {
      "enabled": true,
      "required": true,
      "name": "platform-ui"
    }
  }
}
```

---

### 3. Chrome DevTools MCP Server

**Purpose**: Inspect live DOM and extract locators when tests fail

**When Required**:
- ✅ BEFORE running locator healing workflow
- ⚠️ Only when tests fail due to locator issues

**Why Critical**:
- Provides **live DOM inspection** of running application
- Extracts **current locators** from actual DOM elements
- Calculates **similarity scores** for healing candidates
- Enables **automated locator healing** without manual inspection

**Tools Provided**:
- `chrome-devtools__inspect_element` - Inspect specific element
- `chrome-devtools__get_dom_snapshot` - Get full DOM snapshot
- `chrome-devtools__extract_locators` - Extract all locators for element

**Configuration** (in orchestrator-config.json):
```json
{
  "mcpServers": {
    "chromeDevTools": {
      "enabled": true,
      "required": false,
      "name": "chrome-devtools",
      "config": {
        "browserPath": "chrome",
        "headless": false,
        "timeout": 30000
      }
    }
  }
}
```

---

## MCP Server Usage by Workflow

| Workflow | MDS MCP | Platform UI MCP | Chrome DevTools MCP |
|----------|---------|-----------------|---------------------|
| **Project Setup** | ❌ Not needed | ❌ Not needed | ❌ Not needed |
| **Functional Testing** | ✅ **REQUIRED** | ✅ **REQUIRED** | ❌ Not needed |
| **API Testing** | ❌ Not needed | ❌ Not needed | ❌ Not needed |
| **Integration Testing** | ✅ **REQUIRED** | ✅ **REQUIRED** | ❌ Not needed |
| **E2E Testing** | ✅ **REQUIRED** | ✅ **REQUIRED** | ❌ Not needed |
| **Locator Healing** | ❌ Not needed | ❌ Not needed | ✅ **REQUIRED** |

---

## Pre-Flight MCP Server Validation

**Before starting any test generation workflow**, Claude Code will validate MCP servers:

### Step 0: Validate MCP Servers (Added to All Workflows)

```markdown
### Step 0: Validate Required MCP Servers

**Purpose**: Ensure required MCP servers are enabled and accessible

**Instructions for Claude**:
```
1. CHECK MCP SERVER CONFIGURATION:
   - Read orchestrator-config.json
   - Parse mcpServers section
   - Identify required servers for this workflow

2. VALIDATE MDS MCP SERVER (if required):
   - Use: mcp__mds-mcp__listAllComponents
   - If fails: Display warning, proceed with frontend-extracted locators
   - If succeeds: Display ✅ MDS MCP Server connected

3. VALIDATE PLATFORM UI MCP SERVER (if required):
   - Use: mcp__platform-ui__list_shell_helpers
   - If fails: Display warning, proceed without helper docs
   - If succeeds: Display ✅ Platform UI MCP Server connected

4. VALIDATE CHROME DEVTOOLS MCP SERVER (if required):
   - Check if Chrome is installed
   - Check if DevTools MCP server is running
   - If fails: EXIT with error (required for healing)
   - If succeeds: Display ✅ Chrome DevTools MCP Server connected

5. DISPLAY VALIDATION SUMMARY:
   ✅ MCP Server Validation Complete
   - MDS MCP: Connected/Not Required/Failed
   - Platform UI MCP: Connected/Not Required/Failed
   - Chrome DevTools MCP: Connected/Not Required/Failed
```

**Output**: validation_status{}, connected_servers[]
```

---

## Setup Instructions

### How to Enable MCP Servers in Claude Code

**MCP servers are configured in Claude Code's settings:**

1. **Open Claude Code Settings**:
   ```
   Windows/Linux: Ctrl+Shift+P → "Claude Code: Open Settings"
   Mac: Cmd+Shift+P → "Claude Code: Open Settings"
   ```

2. **Add MCP Server Configurations**:
   ```json
   {
     "mcpServers": {
       "mds-mcp": {
         "command": "node",
         "args": ["path/to/mds-mcp-server/index.js"]
       },
       "platform-ui": {
         "command": "node",
         "args": ["path/to/platform-ui-mcp-server/index.js"]
       },
       "chrome-devtools": {
         "command": "node",
         "args": ["path/to/chrome-devtools-mcp-server/index.js"]
       }
     }
   }
   ```

3. **Restart Claude Code** to load MCP servers

4. **Verify MCP Servers**:
   - Check Claude Code status bar
   - Should show: "3 MCP servers connected"

---

## Validation Before Test Generation

### Pre-Flight Checklist

Before running any test workflow, Claude will:

✅ **Check orchestrator-config.json** for MCP server configuration

✅ **Validate MDS MCP Server** (for functional/integration/E2E):
   - Run: `mcp__mds-mcp__listAllComponents`
   - Expected: List of MDS components returned
   - Fallback: Continue with frontend-extracted locators (90% confidence)

✅ **Validate Platform UI MCP Server** (for all workflows):
   - Run: `mcp__platform-ui__list_shell_helpers`
   - Expected: List of shell helpers returned
   - Fallback: Continue without helper documentation

✅ **Validate Chrome DevTools MCP Server** (for healing only):
   - Run: `chrome-devtools__get_dom_snapshot` on test page
   - Expected: DOM snapshot returned
   - Error: EXIT if not available (REQUIRED for healing)

---

## Impact of Missing MCP Servers

### If MDS MCP Server is Missing

**Impact**:
- ⚠️ Uses frontend-extracted locators only (90% confidence vs 98%)
- ⚠️ May miss exact MDS component props and events
- ⚠️ Generated page objects might not align perfectly with design system
- ✅ Tests will still be generated and work

**Recommendation**: Enable MDS MCP server for production test generation

---

### If Platform UI MCP Server is Missing

**Impact**:
- ⚠️ No shell helper documentation in generated code
- ⚠️ May use helper APIs incorrectly
- ⚠️ Missing best practices and usage patterns
- ✅ Tests will still be generated

**Recommendation**: Enable Platform UI MCP server for helper-heavy applications

---

### If Chrome DevTools MCP Server is Missing

**Impact**:
- ❌ **CANNOT run locator healing workflow**
- ❌ Manual DOM inspection required for broken locators
- ❌ No automated similarity matching
- ❌ Healing workflow will EXIT with error

**Recommendation**: Enable Chrome DevTools MCP server if you plan to use auto-healing

---

## Example: Functional Testing with MCP Validation

```
User: "Run the functional testing workflow for module WD_Testing"

Claude:
  Step 0: Validate MCP Servers
    ✅ MDS MCP Server connected (24 components found)
    ✅ Platform UI MCP Server connected (26 helpers found)
    ℹ️  Chrome DevTools MCP not required for this workflow

  Step 1: Validate Requirement Files
    ✅ Found 4 requirement files

  Step 2: Analyze Frontend Code
    ✅ Found 12 Vue components
    ✅ Extracted 45 locators (90% confidence)

  Step 3: Query MDS Components (using MDS MCP)
    ✅ MdsButton: 15 props, 8 events, 2 slots
    ✅ MdsInput: 12 props, 6 events, 0 slots
    ✅ Locator confidence upgraded to 98%

  Step 4: Generate Test Design
    ...
```

---

## Example: Healing Workflow with Chrome DevTools MCP

```
User: "Run the healing workflow for failed tests in WD_Testing"

Claude:
  Step 0: Validate MCP Servers
    ℹ️  MDS MCP not required for this workflow
    ℹ️  Platform UI MCP not required for this workflow
    ✅ Chrome DevTools MCP Server connected

  Step 0: Analyze Test Failures
    ✅ Found 3 locator failures

  Step 1: Inspect DOM State (using Chrome DevTools MCP)
    ✅ Launched browser: http://localhost:5173/app
    ✅ Captured DOM snapshot
    ✅ Extracted current locators for failed elements

  Step 2: Calculate Similarity Scores
    Original: [data-test-id="add-button"]
    Candidates:
      98% - [data-test-id="add-rule-button"]  ← Best match
      85% - [aria-label="Add"]
      75% - [role="button"]

  Step 3: Update Page Objects
    ✅ Updated AbsenceRulesPage.js with healed locators
    ...
```

---

## Troubleshooting

### "MDS MCP Server not responding"

**Solution**:
1. Check MCP server is running: `ps aux | grep mds-mcp`
2. Check Claude Code settings for correct path
3. Restart MCP server: `node path/to/mds-mcp-server/index.js`
4. Restart Claude Code

### "Platform UI MCP Server not found"

**Solution**:
1. Verify server installation
2. Check Claude Code settings
3. Ensure server is in PATH or use absolute path

### "Chrome DevTools MCP Server cannot connect to browser"

**Solution**:
1. Ensure Chrome is installed and in PATH
2. Check browser is not already running with debugging enabled
3. Close all Chrome instances and retry
4. Check firewall settings (port 9222)

---

## Benefits of MCP Server Integration

### With MCP Servers Enabled

✅ **98% locator confidence** (MDS MCP)
✅ **Exact component specifications** from design system
✅ **Shell helper documentation** in generated code
✅ **Automated locator healing** without manual inspection
✅ **Faster debugging** with live DOM inspection
✅ **Production-ready tests** that align with frontend implementation

### Without MCP Servers

⚠️ **90% locator confidence** (frontend-extracted only)
⚠️ **Guessed component props** based on code analysis
⚠️ **No helper documentation** in generated code
⚠️ **Manual locator healing** required
⚠️ **Slower debugging** with manual DOM inspection
⚠️ **Tests may need adjustments** after generation

---

## Summary

**MUST HAVE**:
- ✅ MDS MCP Server (for functional/integration/E2E test generation)
- ✅ Platform UI MCP Server (for all test generation)

**OPTIONAL BUT RECOMMENDED**:
- ✅ Chrome DevTools MCP Server (for locator healing)

**Configuration**: Update `orchestrator-config.json` with MCP server settings

**Validation**: Claude Code validates MCP servers automatically before workflow execution

---

**END**
