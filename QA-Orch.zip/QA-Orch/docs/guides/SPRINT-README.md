# Sprint Planning Guides - README

**Complete guide package for integrating QA Test Orchestrator with your 15-day sprint workflow**

---

## Documents in This Package

### 1. **sprint-planning.md** - Comprehensive Sprint Plan
**Use for**: Detailed day-by-day planning, understanding the full workflow

**Contents**:
- Complete 15-day sprint breakdown
- Two scenarios (first sprint vs. ongoing)
- Critical freeze points
- Agent execution timelines
- Handoff checklists
- Parallel execution strategies
- Example walkthroughs

**When to read**: During sprint planning (Day 0), when onboarding new QA team members

---

### 2. **sprint-quick-reference.md** - Quick Reference Card
**Use for**: Daily operations, command lookup

**Contents**:
- Day-by-day commands
- Freeze points checklist
- Approval response guide
- Test execution commands
- Troubleshooting quick fixes
- Time budget per agent

**When to read**: Daily during sprint, keep at your desk

---

### 3. **sprint-timeline-visual.md** - Visual Timeline
**Use for**: Understanding parallel workflows, team coordination

**Contents**:
- Visual ASCII timeline (Dev vs QA)
- Gantt chart of agent execution
- Critical path analysis
- Parallel execution opportunities
- Example sprint schedule with times
- Print-friendly summary card

**When to read**: Sprint kickoff meetings, when explaining to stakeholders

---

### 4. **sprint-config-template.json** - Configuration Template
**Use for**: Setting up orchestrator-config.json for your sprint

**Contents**:
- Annotated JSON configuration
- Sprint-specific settings
- Freeze point references
- Command quick reference
- Sprint checklist embedded
- Tips for success

**When to read**: Day 0 setup, when configuring new modules

---

## Quick Start - First Time Setup

### Step 1: Read Overview (10 minutes)
```bash
# Read the comprehensive plan
cat docs/guides/sprint-planning.md | head -100
```

### Step 2: Configure Project (15 minutes)
```bash
# Copy template to project root
cp docs/guides/sprint-config-template.json ./orchestrator-config.json

# Edit paths and settings
# Update: projectPath, requirementPath, frontendProjectPath, baseUrl, moduleName
```

### Step 3: Verify Setup (5 minutes)
```bash
# In Claude Code
/verify
```

### Step 4: Print Quick Reference (5 minutes)
```bash
# Print this and keep at your desk
cat docs/guides/sprint-quick-reference.md
```

**Total setup time**: 35 minutes

---

## Daily Workflow

### Day 0 - Sprint Planning
1. Review epic and stories with dev team
2. Create requirements document: `requirements/{ModuleName}.md`
   - Use REQ-XXX format for requirements
   - Use AC-XXX format for acceptance criteria
3. **First sprint only**: Run `/setup-project`
4. Run `/verify` to check configuration

**Documents to reference**:
- sprint-planning.md (Day 0 section)
- sprint-config-template.json (check paths)

---

### Day 1 - After Story Freeze (EOD)
1. Verify stories are frozen (no more changes)
2. Run: `/start-functional-tests {ModuleName}`
3. Approve 4 checkpoints (30 min spread over 3 hours)

**Documents to reference**:
- sprint-quick-reference.md (Day 1 commands)
- sprint-timeline-visual.md (see what's next)

---

### Day 3 - After API/DB Freeze
1. Verify API spec is frozen (OpenAPI/Swagger)
2. Verify DB schema is frozen (migration scripts)
3. Run: `Start APITestAgent and IntegrationTestAgent for module {ModuleName}`
4. Approve 8 checkpoints total (1 hour spread over 2.5 hours)

**Documents to reference**:
- sprint-quick-reference.md (Parallel execution section)
- sprint-planning.md (Day 3 details)

---

### Day 8 - After Code Complete
1. Verify code is complete and deployed to test environment
2. Run: `/start-e2e-tests {ModuleName}`
3. Approve 4 checkpoints (30 min spread over 3 hours)
4. Begin full test suite execution

**Documents to reference**:
- sprint-quick-reference.md (Test execution commands)

---

### Day 12 - Locator Healing (if needed)
1. Review test failures from Days 9-11
2. Identify locator-related failures
3. Run: `/heal-locators {ModuleName}`
4. Approve 4 checkpoints (30 min spread over 1-2 hours)
5. Final regression test

**Documents to reference**:
- sprint-quick-reference.md (Troubleshooting section)

---

## Common Scenarios

### Scenario 1: First Sprint with Brand New Module
**Situation**: Starting a new project or module for the first time

**Steps**:
1. Day 0: Run `/setup-project` (1 hour, 4 approvals)
2. Day 0: Create `requirements/{ModuleName}.md`
3. Day 1 EOD: Run `/start-functional-tests {ModuleName}`
4. Follow standard timeline

**Configuration**:
```json
{
  "scenario": "fresh",
  "agents": {
    "availableAgents": [
      {
        "name": "ProjectSetupAgent",
        "enabled": true
      }
    ]
  }
}
```

**Documents**: sprint-planning.md → "Scenario 1: First Sprint"

---

### Scenario 2: Ongoing Sprint (Existing Project)
**Situation**: Second sprint onwards, project already set up

**Steps**:
1. Day 0: Update `requirements/{ModuleName}.md` for new module
2. Day 1 EOD: Run `/start-functional-tests {ModuleName}`
3. Follow standard timeline (skip ProjectSetupAgent)

**Configuration**:
```json
{
  "scenario": "existing",
  "agents": {
    "availableAgents": [
      {
        "name": "ProjectSetupAgent",
        "enabled": false
      }
    ]
  }
}
```

**Documents**: sprint-planning.md → "Scenario 2: Ongoing Sprints"

---

### Scenario 3: Dev Team Delayed (Story Freeze Missed)
**Situation**: Stories not ready on Day 1 EOD, freeze delayed to Day 2

**Impact**: Timeline shifts by 1 day

**Adjusted Timeline**:
- Day 2 EOD: Start functional tests (was Day 1)
- Day 4: Start API + Integration tests (was Day 3)
- Day 9: Start E2E tests (was Day 8)
- Day 13: Locator healing (was Day 12)

**Action**:
1. Communicate delay to team
2. Update sprint timeline document
3. Adjust expectations with stakeholders

**Documents**: sprint-planning.md → "Troubleshooting" section

---

### Scenario 4: API Spec Changes After Freeze
**Situation**: API definition changes on Day 3 (after Day 2 freeze)

**Impact**: Need to regenerate API tests

**Action**:
1. Communicate to dev team (enforce freeze)
2. If change is critical:
   ```bash
   /start-api-tests {ModuleName}
   # Re-approve 4 checkpoints (2 hours)
   ```
3. Update freeze point process for next sprint

**Documents**: sprint-planning.md → "Handoff Checklist"

---

### Scenario 5: High Locator Failure Rate (Day 12)
**Situation**: More than 50% of tests failing due to locator issues

**Root Causes**:
- Frontend code quality issues
- Frequent UI changes
- Missing data-testid attributes

**Action**:
1. **Short term**: Run `/heal-locators {ModuleName}` (1-2 hours)
2. **Long term**:
   - Request dev team to add data-testid attributes
   - Establish UI freeze earlier in sprint
   - Review frontend code standards

**Documents**: sprint-planning.md → "Tips for Success"

---

## Team Roles and Responsibilities

### Product Owner / Business Analyst
**Responsibilities**:
- Day 0: Create epic and stories with detailed acceptance criteria
- Day 0: Review and approve requirements document
- Day 1 EOD: Sign off on story freeze
- Day 2 EOD: Sign off on API/DB freeze

**Required Format**:
```markdown
## REQ-001: Requirement Title
Description

### AC-001: Acceptance Criteria
Detailed description
```

---

### Dev Team (Using OneBot)
**Responsibilities**:
- Day 0: Break down epic into stories
- Day 1: Complete architecture and system design
- Day 1 EOD: Freeze stories (no more changes)
- Day 2: Complete API spec (OpenAPI/Swagger)
- Day 2: Complete DB schema scripts
- Day 2 EOD: Freeze API and DB
- Day 8: Code complete, handoff to QA
- Day 9-12: Fix bugs reported by QA

**Deliverables for QA**:
- Requirements in REQ-XXX/AC-XXX format
- Frozen API specification
- Frozen DB schema
- Working application at baseUrl

---

### QA Team (Using Orchestrator)
**Responsibilities**:
- Day 0: Review and create requirements document
- Day 0 (first sprint): Run ProjectSetupAgent
- Day 1 EOD: Start FunctionalTestAutomationAgent
- Day 3: Start APITestAgent + IntegrationTestAgent
- Day 4-11: Execute tests, report bugs
- Day 8: Start EndToEndTestAgent
- Day 12: Run LocatorHealingAgent if needed
- Day 15: Deliver coverage report

**Required Presence**:
- Day 0: 2-3 hours (setup + requirements)
- Day 1: 30 min (approvals spread over 3 hours)
- Day 3: 1 hour (approvals spread over 2.5 hours)
- Day 8: 30 min (approvals spread over 3 hours)
- Day 12: 30 min (approvals spread over 1-2 hours)

**Total approval time**: ~3 hours across sprint

---

## Integration with Dev Team's OneBot

Your dev team uses **OneBot (powered by Claude Code)** for development. Here's how QA Orchestrator integrates:

### Parallel Workflows
```
Dev Team (OneBot)              QA Team (Orchestrator)
─────────────────              ──────────────────────

Day 0: Create stories     →    Day 0: Create requirements
Day 1: Design system      →    Day 1: Generate functional tests
Day 2-7: Code             ║    Day 3-7: Generate all tests + execute
Day 8: Code complete      →    Day 8: Start E2E tests
Day 9-11: Fix bugs        ←    Day 9-11: Report bugs
Day 12: Final fixes       →    Day 12: Heal locators
```

### Handoff Points
1. **Day 1 EOD**: Dev → QA (frozen stories)
2. **Day 2 EOD**: Dev → QA (frozen API/DB)
3. **Day 8**: Dev → QA (code complete)
4. **Day 9-11**: QA → Dev (bug reports)
5. **Day 12**: Dev → QA (final fixes)

### Communication Protocol
- Use JIRA for bug tracking
- Use Slack/Teams for urgent issues
- Daily standup to sync progress
- Freeze points are HARD stops

---

## Metrics and Reporting

### Daily Metrics to Track

| Day | Metric | Target | How to Measure |
|-----|--------|--------|----------------|
| 0 | Requirements documented | 100% | Count REQ-XXX tags |
| 1 | Story freeze on-time | Yes/No | Story freeze at EOD |
| 1 | Functional tests generated | 100% ACs | Traceability matrix |
| 3 | API/DB freeze on-time | Yes/No | Freeze at EOD |
| 3 | API + Integration tests | 100% | Test spec count |
| 8 | Code complete on-time | Yes/No | Handoff at start of day |
| 8 | E2E tests generated | 100% journeys | Test spec count |
| 11 | Test pass rate | >90% | Playwright report |
| 12 | Locator healing success | >95% | Re-run pass rate |
| 15 | Traceability coverage | 100% | REQ→AC→TC matrix |

### Sprint End Report Template

```markdown
# Sprint {Number} - QA Test Orchestrator Report

## Summary
- Sprint: Sprint {Number}
- Duration: {Start Date} to {End Date}
- Modules: {List}
- Scenario: {fresh/existing}

## Agent Execution
- ProjectSetupAgent: {run/skipped} - {duration}
- FunctionalTestAutomationAgent: {duration}
- APITestAgent: {duration}
- IntegrationTestAgent: {duration}
- EndToEndTestAgent: {duration}
- LocatorHealingAgent: {run/skipped} - {duration}

## Test Coverage
- Total Requirements: {count}
- Total Acceptance Criteria: {count}
- Total Test Cases: {count}
- Traceability: {percentage}%

## Test Execution
- Total Tests: {count}
- Passed: {count} ({percentage}%)
- Failed: {count} ({percentage}%)
- Skipped: {count} ({percentage}%)

## Defects
- Critical: {count}
- High: {count}
- Medium: {count}
- Low: {count}

## Timeline Adherence
- Story Freeze (Day 1): {on-time/delayed}
- API/DB Freeze (Day 2): {on-time/delayed}
- Code Complete (Day 8): {on-time/delayed}
- Test Complete (Day 12): {on-time/delayed}

## Lessons Learned
- What went well
- What can be improved
- Process changes for next sprint
```

---

## Troubleshooting Guide

### Issue: "/verify" fails with path errors
**Cause**: Paths in orchestrator-config.json don't exist

**Solution**:
1. Check all paths exist:
   ```bash
   ls {projectPath}
   ls {requirementPath}
   ls {frontendProjectPath}
   ```
2. Create missing directories:
   ```bash
   mkdir -p {projectPath}/{tests,pages,test-designs}
   ```
3. Run `/verify` again

---

### Issue: Agent won't start
**Cause**: Requirements file missing or malformed

**Solution**:
1. Check file exists: `requirements/{ModuleName}.md`
2. Verify format:
   ```markdown
   ## REQ-001: Title
   ### AC-001: Criteria
   ```
3. Check for syntax errors (missing ##, ###)

---

### Issue: MCP servers not connected
**Cause**: MCP servers not configured in Claude Code

**Impact**: Can still work! Orchestrator falls back to frontend code analysis

**Solution** (optional):
1. Open Claude Code settings
2. Navigate to MCP Servers
3. Add mds-mcp and platform-ui servers
4. Restart Claude Code

**Or just continue**: Tests will be generated using frontend code instead

---

### Issue: Parallel execution not working
**Cause**: parallelExecution set to false

**Solution**:
```json
{
  "agents": {
    "parallelExecution": true,
    "maxConcurrentAgents": 3
  }
}
```

---

### Issue: Tests failing after locator healing
**Cause**: Healed locators still incorrect

**Solution**:
1. Review frontend code for correct selectors
2. Add data-testid attributes to components
3. Regenerate tests from scratch:
   ```bash
   /start-functional-tests {ModuleName}
   ```

---

## FAQ

### Q: Can I run agents out of order?
**A**: No. Agents have dependencies:
- IntegrationTestAgent requires FunctionalTestAutomationAgent
- EndToEndTestAgent requires Functional + Integration
- APITestAgent is independent

### Q: What if requirements change mid-sprint?
**A**: Depends on freeze point:
- Before Day 1 freeze: Update and continue
- After Day 1 freeze: Regenerate functional tests
- After Day 2 freeze: Regenerate API/Integration tests

### Q: Can I skip certain agents?
**A**: Yes, but impacts coverage:
- Minimum: FunctionalTestAutomationAgent only
- Recommended: Functional + API + Integration
- Complete: All agents including E2E

### Q: How long does each agent take?
**A**:
- ProjectSetup: 1 hour
- Functional: 3 hours
- API: 2 hours
- Integration: 2.5 hours
- E2E: 3 hours
- Healing: 1-2 hours

### Q: Do I need to stay at my desk during agent execution?
**A**: No, only for approvals (20-40 min per agent). You'll get prompts at checkpoints.

### Q: What if I reject at a checkpoint?
**A**: Agent stops. You can:
- Fix the issue
- Re-run the agent from start

### Q: Can I run multiple modules in parallel?
**A**: Yes! Run agents for Module1, then immediately for Module2. They'll queue.

### Q: What if dev team is using Selenium, not Playwright?
**A**: Orchestrator generates Playwright tests. Keep Selenium tests separate. No migration needed.

---

## Next Steps

1. **Week 1**: Pilot with one module
   - Follow sprint-planning.md day-by-day
   - Keep sprint-quick-reference.md at desk
   - Track metrics

2. **Week 2**: Team review
   - Gather feedback
   - Adjust timeline if needed
   - Update documentation

3. **Week 3**: Full rollout
   - Train all QA team members
   - Integrate with JIRA workflow
   - Automate reporting

4. **Week 4**: Optimize
   - Measure time savings
   - Identify bottlenecks
   - Refine process

---

## Document Update History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2026-03-23 | Initial release |

---

## Support

**Questions?** Check:
1. sprint-planning.md → Comprehensive details
2. sprint-quick-reference.md → Quick commands
3. CLAUDE.md → Orchestrator documentation
4. GitHub Issues → Report problems

**Success Tip**: Print sprint-quick-reference.md and keep it at your desk!

---

## Summary

You now have **4 comprehensive documents** to integrate QA Test Orchestrator with your 15-day sprint:

1. ✅ **sprint-planning.md** - Detailed day-by-day plan
2. ✅ **sprint-quick-reference.md** - Daily command reference
3. ✅ **sprint-timeline-visual.md** - Visual timelines and schedules
4. ✅ **sprint-config-template.json** - Annotated configuration

**Total setup time**: 35 minutes
**Total orchestrator time per sprint**: 12.5 hours (first) / 11.5 hours (ongoing)
**Total approval time**: 2-3 hours spread across sprint
**Test coverage**: 100% with REQ→AC→TC traceability

**Start with Day 0 and follow the plan!**
