# Sprint Quick Reference Card

**15-Day Sprint - QA Orchestrator Commands**

---

## Complete 15-Day Schedule

### Day 0 - Sprint Planning
**Activities**: Epic creation, requirements documentation, project setup
```bash
# FIRST SPRINT ONLY (run once per project)
/setup-project

# Always run (verify configuration)
/verify
```
**Deliverable**: Requirements document at `requirements/{ModuleName}.md`
**Time**: 2-3 hours (setup) + requirements prep

---

### Day 1 - Design & Functional Test Generation
**Activities**: Architecture design, story freeze, start functional tests
**Freeze Point**: EOD - Story Freeze (UI + Backend)
```bash
# After story freeze (EOD)
/start-functional-tests {ModuleName}
```
**Duration**: 3 hours | **Approvals**: 4 | **Dependencies**: None
**Outputs**: Functional tests, page objects, traceability matrix

---

### Day 2 - DB/API Schema Freeze
**Activities**: DB schema finalized, API spec frozen, complete functional tests
**Freeze Point**: EOD - API + DB Schema Freeze
```bash
# Continue functional test generation if not complete
# Review API spec and DB schema
```
**Time**: 1-2 hours (complete functional tests)

---

### Day 3 - API & Integration Test Generation
**Activities**: Start backend coding, generate API + Integration tests (parallel)
```bash
# Run both in parallel (saves 3 hours!)
Start APITestAgent and IntegrationTestAgent for module {ModuleName}

# OR run separately
/start-api-tests {ModuleName}
/start-integration-tests {ModuleName}
```
**Duration**: 2.5 hours (parallel) | **Approvals**: 8 total | **Dependencies**: Integration needs Functional
**Outputs**: API tests, Integration tests, data flow diagrams

---

### Day 4 - Backend Development + Test Setup
**Activities**: Backend coding, complete test generation, set up test environment
```bash
# Verify all tests generated
ls tests/functional/{module}
ls tests/api/{module}
ls tests/integration/{module}

# Configure test environment
```
**Time**: 2 hours (test environment setup)

---

### Day 5 - Initial Test Execution
**Activities**: Backend coding continues, start executing functional tests
```bash
# Run functional tests
npx playwright test tests/functional/{module}

# Generate report
npx playwright show-report
```
**Expected**: ~33% pass rate (code not complete)
**Time**: 2-3 hours (initial test execution)

---

### Day 6 - API Test Execution
**Activities**: Backend coding continues, execute API tests
```bash
# Run API tests
npx playwright test tests/api/{module}

# Re-run functional tests
npx playwright test tests/functional/{module}
```
**Expected**: ~70% pass rate (more endpoints working)
**Time**: 2-4 hours (test execution)

---

### Day 7 - Integration Test Execution
**Activities**: Backend code complete, execute integration tests
```bash
# Run integration tests
npx playwright test tests/integration/{module}

# Run all tests
npx playwright test

# Generate report
npx playwright show-report
```
**Expected**: ~86% pass rate
**Time**: 3-4 hours (full suite execution)

---

### Day 8 - Code Complete & E2E Generation
**Activities**: Code handoff, start E2E test generation
**Milestone**: Code Complete
```bash
# After code complete
/start-e2e-tests {ModuleName}
```
**Duration**: 3 hours | **Approvals**: 4 | **Dependencies**: Functional + Integration
**Outputs**: E2E tests, user journey maps
**Time**: 3 hours (E2E generation) + 2 hours (test execution)

---

### Day 9 - Intensive Testing & Bug Reporting
**Activities**: Full test suite execution, log all bugs (P1, P2, P3, P4)
```bash
# Execute complete test suite
npx playwright test

# Generate detailed report
npx playwright show-report
```
**Expected**: ~78% pass rate, 10 bugs logged
**Time**: 6-8 hours (full testing + bug reporting)

---

### Day 10 - Bug Fixes & Regression (P1/P2)
**Activities**: Retest P1/P2 bugs, continue regression testing
```bash
# Retest fixed bugs
npx playwright test --last-failed

# Run full regression
npx playwright test
```
**Expected**: ~89% pass rate, P1/P2 bugs fixed
**Time**: 6-8 hours (regression + retesting)

---

### Day 11 - Final Fixes & Full Regression (All Priorities)
**Activities**: Retest all bugs, final regression, prepare for healing
```bash
# Run complete regression suite
npx playwright test

# Generate final report
npx playwright show-report
```
**Expected**: ~93% pass rate, all bugs fixed (except P4)
**Time**: 6-7 hours (final regression)

---

### Day 12 - Locator Healing & Final Regression
**Activities**: Heal broken locators, final regression test
**Milestone**: Test Execution Complete
```bash
# Heal broken locators (if needed)
/heal-locators {ModuleName}

# Run final regression
npx playwright test
```
**Duration**: 1-2 hours (healing) | **Approvals**: 4
**Expected**: 100% pass rate
**Time**: 4-5 hours (healing + final regression)

---

### Day 13 - UAT Begins
**Activities**: Support UAT testing, provide test scenarios
**Milestone**: UAT Starts
```bash
# Run sanity tests in UAT
npx playwright test --grep "@smoke"

# Run critical path tests
npx playwright test tests/e2e/{module}
```
**Time**: 4-6 hours (UAT support)

---

### Day 14 - UAT Continues & Documentation
**Activities**: Final UAT support, generate traceability report, coverage report
```bash
# Run final regression
npx playwright test

# Generate reports
npx playwright test --reporter=html
```
**Deliverables**: Traceability report, coverage report, UAT sign-off
**Time**: 4-6 hours (UAT + reporting)

---

### Day 15 - Retrospective & Deployment
**Activities**: Sprint retrospective, demo, deployment prep
**Time**: 3 hours (retrospective + demo)

---

## Freeze Points Checklist

- [ ] **Day 1 EOD**: Story Freeze (UI + Backend) → START Functional
- [ ] **Day 2 EOD**: API + DB Schema Freeze → START API + Integration
- [ ] **Day 8**: Code Complete → START E2E
- [ ] **Day 12**: Test Complete → RUN Healing (if failures)

---

## Approval Response Guide

At each checkpoint, respond with:
- **[A]** - Approve and continue to next phase
- **[M]** - Modify (provide corrections and retry)
- **[R]** - Reject and stop execution

**Expected approval time**: 5-10 minutes per checkpoint

---

## Parallel vs Sequential

**Can Run in Parallel**:
- APITestAgent + IntegrationTestAgent (Day 3)

**Must Run Sequentially**:
- Functional (Day 1) → Integration (Day 3) → E2E (Day 8)

---

## Test Execution Commands

```bash
# Run specific test suite
npx playwright test tests/functional/{module}
npx playwright test tests/api/{module}
npx playwright test tests/integration/{module}
npx playwright test tests/e2e/{module}

# Run all tests
npx playwright test

# Generate report
npx playwright show-report
```

---

## Troubleshooting

### Agent won't start
```bash
/verify  # Check configuration
```

### Tests failing with locator errors
```bash
/heal-locators {ModuleName}
```

### Need to regenerate tests
```bash
# Just re-run the agent
/start-functional-tests {ModuleName}
```

---

## Required Files

Before starting agents:

1. **orchestrator-config.json** (project root)
2. **requirements/{ModuleName}.md** (REQ-XXX, AC-XXX format)
3. **Frontend code** (at frontendProjectPath)
4. **MCP servers** connected (optional but recommended)

---

## Time Budget

| Agent | Duration | Approval Time | When |
|-------|----------|---------------|------|
| ProjectSetup | 1h | 20-40m | Day 0 (first sprint only) |
| Functional | 3h | 20-40m | Day 1 |
| API | 2h | 20-40m | Day 3 |
| Integration | 2.5h | 20-40m | Day 3 |
| E2E | 3h | 20-40m | Day 8 |
| Healing | 1-2h | 20-40m | Day 12 |

**Total**: 11.5-13.5 hours across 15 days

---

## Success Metrics

- [ ] 100% Requirements documented (Day 0)
- [ ] 100% Functional tests generated (Day 1)
- [ ] 100% API tests generated (Day 3)
- [ ] 100% Integration tests generated (Day 3)
- [ ] 100% E2E tests generated (Day 8)
- [ ] >90% Test pass rate (Day 11)
- [ ] 100% Traceability (REQ→AC→TC)

---

## Emergency Contacts

**Issue**: Agent stuck or error
**Action**: Check CLAUDE.md Troubleshooting section

**Issue**: MCP servers not working
**Action**: Tests still work (uses frontend code analysis)

**Issue**: Deadline pressure
**Action**: Prioritize Functional + API tests, defer E2E
