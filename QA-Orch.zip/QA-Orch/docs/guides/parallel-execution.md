# Parallel Execution Guide

## Overview

The QA Test Orchestrator supports parallel execution of multiple agents, enabling significant time savings (40%+) when generating tests for multiple modules or running independent agents simultaneously.

## Benefits

- ⚡ **40%+ Time Savings** - Process multiple modules concurrently
- 🔄 **Automatic Load Balancing** - Respects `maxConcurrentAgents` setting
- 🎯 **Dependency Resolution** - Automatically orders dependent agents
- 🛡️ **Safe Execution** - Prevents resource conflicts

## Enabling Parallel Execution

### Configuration

```json
{
  "agents": {
    "parallelExecution": true,
    "maxConcurrentAgents": 3
  }
}
```

- **parallelExecution**: Enable/disable parallel execution
- **maxConcurrentAgents**: Maximum agents running simultaneously

## Agent Parallelizability

### Parallelizable Agents

These agents can run in parallel:

- ✅ **FunctionalTestAutomationAgent** - Generates to separate directories
- ✅ **IntegrationTestAgent** - Generates to separate directories
- ✅ **APITestAgent** - Generates to separate directories
- ✅ **EndToEndTestAgent** - Generates to separate directories

### Non-Parallelizable Agents

These agents must run sequentially:

- ❌ **LocatorHealingAgent** - Modifies shared page objects
- ❌ **ProjectSetupAgent** - Modifies shared project structure

## Usage Examples

### Parallel Agents for Single Module

Generate multiple test types for one module:

```
Start FunctionalTestAutomationAgent, IntegrationTestAgent, and APITestAgent in parallel for module AbsenceCode
```

**Execution**:
1. All 3 agents start simultaneously
2. Each runs independently
3. Generated artifacts go to different directories

### Parallel Modules with Same Agent

Process multiple modules with the same agent:

```
Start FunctionalTestAutomationAgent for modules: AbsenceCode, TimeOff, Calendar in parallel
```

**Execution**:
1. Up to 3 agents run concurrently (maxConcurrentAgents)
2. Module 4+ queued until a slot opens
3. Each module gets its own agent instance

### Mixed Parallel and Sequential

```
Start FunctionalTestAutomationAgent and APITestAgent in parallel, then LocatorHealingAgent
```

**Execution**:
1. FunctionalTestAutomationAgent and APITestAgent run in parallel
2. Wait for both to complete
3. LocatorHealingAgent runs sequentially

## Dependency Resolution

### Automatic Dependency Ordering

The orchestrator automatically orders agents based on dependencies:

```javascript
// Configuration
{
  "name": "EndToEndTestAgent",
  "dependencies": ["FunctionalTestAutomationAgent", "IntegrationTestAgent"]
}
```

**User Command**:
```
Start EndToEndTestAgent for module AbsenceCode
```

**Automatic Execution Order**:
1. FunctionalTestAutomationAgent starts
2. IntegrationTestAgent starts (no dependency on FunctionalTestAutomationAgent)
3. Wait for both to complete
4. EndToEndTestAgent starts

### Dependency Levels

The orchestrator groups agents into levels for parallel execution:

**Example Dependency Graph**:
```
Level 0: FunctionalTestAutomationAgent, APITestAgent
Level 1: IntegrationTestAgent (depends on Functional)
Level 2: EndToEndTestAgent (depends on Functional + Integration)
```

**Execution**:
1. Level 0 agents run in parallel
2. Wait for Level 0 completion
3. Level 1 agents run in parallel
4. Wait for Level 1 completion
5. Level 2 agents run in parallel

## Performance Comparison

### Sequential Execution (v2.0)

```
Module 1: Functional → Integration → API → E2E
Time: 30 + 20 + 15 + 25 = 90 minutes

Module 2: Functional → Integration → API → E2E
Time: 90 minutes

Module 3: Functional → Integration → API → E2E
Time: 90 minutes

Total: 270 minutes (4.5 hours)
```

### Parallel Execution (v3.0)

```
Module 1, 2, 3 Functional (parallel): 30 minutes
Module 1, 2, 3 Integration (parallel): 20 minutes
Module 1, 2, 3 API (parallel): 15 minutes
Module 1, 2, 3 E2E (parallel): 25 minutes

Total: 90 minutes (1.5 hours)
```

**Result**: 67% time savings

## Resource Management

### CPU and Memory

**Rule of Thumb**:
- Each agent uses ~500MB RAM
- Set `maxConcurrentAgents` based on available resources:
  - 4GB RAM → max 2-3 agents
  - 8GB RAM → max 4-6 agents
  - 16GB RAM → max 8-12 agents

### File System

Agents write to different directories:
- Functional → `tests/functional/{module}/`
- Integration → `tests/integration/{module}/`
- API → `tests/api/{module}/`

**Conflict Prevention**:
- Each agent has unique output paths
- State manager uses file locking
- Page objects namespaced by module

## Monitoring Parallel Execution

### Check Orchestrator Status

```javascript
const status = orchestrator.getStatus();
console.log(`Running: ${status.running}`);
console.log(`Completed: ${status.completed}`);
console.log(`Queued: ${status.queued}`);
```

### Per-Agent Status

```javascript
const agentStatus = orchestrator.getAgentStatus('FunctionalTestAutomationAgent');
console.log(`State: ${agentStatus.state}`);
console.log(`Progress: ${agentStatus.progress}%`);
```

## Common Issues

### Issue: Agents Not Running in Parallel

**Symptoms**:
- Agents execute sequentially despite parallel configuration
- Only 1 agent runs at a time

**Possible Causes**:
1. `parallelExecution: false` in config
2. `maxConcurrentAgents: 1`
3. Agents have dependencies preventing parallel execution

**Solutions**:
```json
{
  "agents": {
    "parallelExecution": true,
    "maxConcurrentAgents": 3
  }
}
```

### Issue: Resource Exhaustion

**Symptoms**:
- System slowdown
- Out of memory errors
- Agent failures

**Solutions**:
1. Reduce `maxConcurrentAgents`
2. Close other applications
3. Process fewer modules per batch

### Issue: File Conflicts

**Symptoms**:
- Corrupted page objects
- Missing test files
- State management errors

**Possible Causes**:
- LocatorHealingAgent running in parallel
- Custom agents writing to same files

**Solutions**:
1. Set LocatorHealingAgent `parallelizable: false`
2. Ensure agents write to unique paths
3. Use state manager for coordination

## Best Practices

### 1. Start Small

Begin with 2-3 concurrent agents and increase gradually:

```json
{
  "maxConcurrentAgents": 2
}
```

### 2. Group by Dependency

Execute agents in dependency groups:

```
# Good: Parallel within same dependency level
Start FunctionalTestAutomationAgent and APITestAgent in parallel

# Avoid: Trying to parallelize dependent agents
Start IntegrationTestAgent and EndToEndTestAgent in parallel
(EndToEndTestAgent depends on IntegrationTestAgent)
```

### 3. Monitor Resource Usage

Check system resources during execution:
- Task Manager (Windows)
- Activity Monitor (Mac)
- `htop` (Linux)

### 4. Use Module Batching

Process modules in batches:

```
# Batch 1
Start FunctionalTestAutomationAgent for modules: Module1, Module2, Module3 in parallel

# Batch 2
Start FunctionalTestAutomationAgent for modules: Module4, Module5, Module6 in parallel
```

### 5. Test Incrementally

1. Test with 1 agent first
2. Add parallel execution with 2 agents
3. Scale up to max concurrent agents

## Advanced: Programmatic Parallel Execution

### Execute Multiple Agents

```javascript
const orchestrator = new AgentOrchestrator({ maxConcurrent: 3 });

// Register agents
orchestrator.registerAgent(FunctionalTestAutomationAgent, config1);
orchestrator.registerAgent(IntegrationTestAgent, config2);
orchestrator.registerAgent(APITestAgent, config3);

// Execute all in parallel
const results = await orchestrator.executeParallel([
  'FunctionalTestAutomationAgent',
  'IntegrationTestAgent',
  'APITestAgent'
]);

// Process results
results.forEach(result => {
  console.log(`${result.agent}: ${result.success ? '✅' : '❌'}`);
});
```

### Process Modules in Parallel

```javascript
const modules = ['AbsenceCode', 'TimeOff', 'Calendar'];

const promises = modules.map(module => {
  return orchestrator.executeSingle('FunctionalTestAutomationAgent', {
    moduleName: module
  });
});

const results = await Promise.all(promises);
```

## Configuration Reference

### Full Parallel Configuration

```json
{
  "agents": {
    "enabled": true,
    "parallelExecution": true,
    "maxConcurrentAgents": 3,
    "orchestration": {
      "strategy": "dependency-aware",
      "parallelLevels": true,
      "failureHandling": "continue-others"
    }
  }
}
```

**Settings**:
- **strategy**: "dependency-aware" | "sequential" | "parallel"
- **parallelLevels**: Execute agents level-by-level
- **failureHandling**: "continue-others" | "stop-all" | "retry"

## Related Documentation

- [Getting Started Guide](../getting-started.md)
- [Configuration Guide](configuration.md)
- [Agent Architecture](../architecture.md)
