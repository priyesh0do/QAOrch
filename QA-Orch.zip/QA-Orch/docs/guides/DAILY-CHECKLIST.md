# 15-Day Sprint Daily Checklist

**Print this page and check off tasks as you complete them!**

---

## Sprint Information

**Sprint Number**: _______________________
**Start Date**: _______________________
**End Date**: _______________________
**Module Name**: _______________________
**Team**: _______________________

---

## Day 0 - Sprint Planning (Date: ______)

### Dev Team
- [ ] Create EPIC in JIRA
- [ ] Break down into user stories
- [ ] Define acceptance criteria (REQ-XXX, AC-XXX)
- [ ] Story refinement meeting
- [ ] PO review and approval

### QA Team
- [ ] First sprint only: Run `/setup-project` (1 hour)
- [ ] Create `requirements/{ModuleName}.md`
- [ ] Review acceptance criteria
- [ ] Run `/verify`
- [ ] Prepare test data strategy

**Time**: Dev: 4-6h | QA: 2-3h

---

## Day 1 - Design & Functional Tests (Date: ______)

### Dev Team
- [ ] Architecture design (High-level, System)
- [ ] UX/UI mockups
- [ ] API endpoint definitions (draft)
- [ ] Database schema (draft)
- [ ] Data flow diagrams
- [ ] **EOD: Story Freeze** ⚠️

### QA Team
- [ ] Review stories and AC
- [ ] Wait for story freeze
- [ ] Run `/start-functional-tests {ModuleName}`
- [ ] Approve Analysis Phase
- [ ] Approve Design Phase
- [ ] Approve Generation Phase
- [ ] Approve Validation Phase

**Time**: Dev: 6-8h | QA: 3-4h

---

## Day 2 - Schema Finalization (Date: ______)

### Dev Team
- [ ] Finalize DB schema scripts
- [ ] Create migration scripts
- [ ] Complete API definitions (OpenAPI/Swagger)
- [ ] Define request/response schemas
- [ ] API contract documentation
- [ ] **EOD: API & DB Freeze** ⚠️

### QA Team
- [ ] Complete functional test generation
- [ ] Review API specifications
- [ ] Review DB schema
- [ ] Validate schema against requirements
- [ ] Prepare for Day 3 test generation

**Time**: Dev: 6-8h | QA: 1-2h

---

## Day 3 - API & Integration Tests (Date: ______)

### Dev Team
- [ ] Start backend service implementation
- [ ] Implement first API endpoints
- [ ] Database connection setup
- [ ] Initial data models
- [ ] Basic CRUD operations

### QA Team
- [ ] Run `/start-api-tests {ModuleName}`
- [ ] Run `/start-integration-tests {ModuleName}`
- [ ] OR: `Start APITestAgent and IntegrationTestAgent for module {ModuleName}`
- [ ] Approve all 8 checkpoints (4 per agent)
- [ ] Complete functional tests if pending

**Time**: Dev: 6-8h | QA: 2.5h (parallel)
**Tip**: Run both agents in parallel to save 3 hours!

---

## Day 4 - Test Generation Complete (Date: ______)

### Dev Team
- [ ] Continue backend implementation
- [ ] Implement more API endpoints
- [ ] Database CRUD operations
- [ ] Error handling setup
- [ ] Unit test framework setup

### QA Team
- [ ] Complete API test generation
- [ ] Complete Integration test generation
- [ ] Review all generated artifacts (~45 test specs)
- [ ] Set up test execution environment
- [ ] Configure test data and fixtures
- [ ] Review page objects and locators

**Time**: Dev: 6-8h | QA: 2-3h

---

## Day 5 - Initial Test Execution (Date: ______)

### Dev Team
- [ ] Continue backend implementation
- [ ] Implement business logic
- [ ] Database operations
- [ ] Validation rules
- [ ] Unit tests

### QA Team
- [ ] Run: `npx playwright test tests/functional/{module}`
- [ ] Log initial failures (expected)
- [ ] Create test execution baseline
- [ ] Document failures for tracking

**Test Target**: 15 tests → 5 passed (33%)
**Time**: Dev: 6-8h | QA: 2-4h

---

## Day 6 - API Test Execution (Date: ______)

### Dev Team
- [ ] Continue backend implementation
- [ ] Complete API endpoints
- [ ] Authentication/authorization
- [ ] Error handling
- [ ] Input validation

### QA Team
- [ ] Run: `npx playwright test tests/api/{module}`
- [ ] Re-run functional tests
- [ ] Validate API schemas
- [ ] Document test results
- [ ] Compare with OpenAPI spec

**Test Target**: API: 7/10 passed (70%), Functional: 10/15 passed (67%)
**Time**: Dev: 6-8h | QA: 4-6h

---

## Day 7 - Integration Test Execution (Date: ______)

### Dev Team
- [ ] Complete backend implementation (100%)
- [ ] Final API endpoints
- [ ] Database optimization
- [ ] Complete unit tests
- [ ] Code review prep

### QA Team
- [ ] Run: `npx playwright test tests/integration/{module}`
- [ ] Validate data flow (UI → API → DB)
- [ ] Test database state changes
- [ ] Run all test suites
- [ ] Pre-Code Complete checklist

**Test Target**: Integration: 10/12 passed (83%), All: 32/37 passed (86%)
**Time**: Dev: 6-8h | QA: 4-6h

---

## Day 8 - Code Complete & E2E Tests (Date: ______)

### Dev Team
- [ ] **Code complete** ✓
- [ ] Integration testing
- [ ] Deploy to test environment
- [ ] Handoff to QA
- [ ] Support QA testing

### QA Team
- [ ] Verify code complete
- [ ] Run `/start-e2e-tests {ModuleName}`
- [ ] Approve all 4 checkpoints
- [ ] Continue test execution (functional, API, integration)
- [ ] Document test results

**Time**: Dev: 4-6h | QA: 5-6h

---

## Day 9 - Intensive Testing (Date: ______)

### Dev Team
- [ ] Receive bug reports from QA
- [ ] Triage bugs (P1, P2, P3, P4)
- [ ] Start fixing P1 (Critical) bugs
- [ ] Hot fixes for blockers
- [ ] Deploy fixes

### QA Team
- [ ] Run: `npx playwright test` (complete suite)
- [ ] Log all defects in JIRA
- [ ] Create detailed bug reports
- [ ] Track test execution metrics
- [ ] Identify blocker issues

**Test Target**: 35/45 passed (78%)
**Bugs Expected**: ~10 (P1: 2, P2: 3, P3: 3, P4: 2)
**Time**: Dev: 6-8h | QA: 6-8h

---

## Day 10 - Bug Fixes & Regression (P1/P2) (Date: ______)

### Dev Team
- [ ] Complete P1 bug fixes
- [ ] Start P2 (High) bug fixes
- [ ] Deploy fixes continuously
- [ ] Update API docs if needed
- [ ] Code review for bug fixes

### QA Team
- [ ] Retest fixed P1 bugs
- [ ] Run: `npx playwright test --last-failed`
- [ ] Continue full regression
- [ ] Update test data if needed
- [ ] Track locator failures
- [ ] Monitor test stability

**Test Target**: 40/45 passed (89%)
**Bugs Fixed**: P1: 2/2, P2: 3/3
**Locator Issues**: ~3 identified
**Time**: Dev: 6-8h | QA: 6-8h

---

## Day 11 - Final Fixes & Full Regression (Date: ______)

### Dev Team
- [ ] Complete P2 bug fixes
- [ ] Fix P3 (Medium) bugs
- [ ] P4 (Low) bugs - defer if needed
- [ ] Final code review
- [ ] Code stabilization
- [ ] Prepare for UAT

### QA Team
- [ ] Retest all fixed bugs
- [ ] Run: `npx playwright test` (complete regression)
- [ ] Validate all scenarios
- [ ] Document final results
- [ ] Consolidate locator failure list
- [ ] Prepare test summary report

**Test Target**: 42/45 passed (93%)
**Bugs Status**: P1/P2/P3 fixed, P4 deferred
**Ready for**: Locator healing
**Time**: Dev: 6-8h | QA: 6-7h

---

## Day 12 - Locator Healing & Final Regression (Date: ______)

### Dev Team
- [ ] Final bug fixes (if any)
- [ ] Code review
- [ ] Documentation
- [ ] Deployment prep
- [ ] Support QA

### QA Team
- [ ] Run `/heal-locators {ModuleName}`
- [ ] Approve all 4 checkpoints
- [ ] Review healed locators
- [ ] Run final regression: `npx playwright test`
- [ ] Generate healing report
- [ ] Verify 100% pass rate

**Test Target**: 45/45 passed (100%) ✓
**Locator Healing**: 3 locators healed
**Status**: Ready for UAT
**Time**: Dev: 4-6h | QA: 4-5h

---

## Day 13 - UAT Begins (Date: ______)

### Dev Team
- [ ] Support UAT testing
- [ ] Monitor test environment
- [ ] Address urgent UAT issues
- [ ] Be available for questions
- [ ] Prepare deployment scripts

### QA Team
- [ ] Support UAT testing
- [ ] Provide test scenarios to business users
- [ ] Run: `npx playwright test --grep "@smoke"`
- [ ] Monitor UAT defects
- [ ] Assist users with test execution
- [ ] Document UAT feedback

**UAT Target**: 10 scenarios, 6 executed, 5 passed
**Time**: Dev: 4-6h | QA: 4-6h

---

## Day 14 - UAT Continues & Reports (Date: ______)

### Dev Team
- [ ] Fix UAT defects (if any)
- [ ] Address usability feedback
- [ ] Code refinements
- [ ] Prepare deployment plan
- [ ] Final code review

### QA Team
- [ ] Continue UAT support
- [ ] Retest UAT defects
- [ ] Run final regression: `npx playwright test`
- [ ] Generate traceability report
- [ ] Generate coverage report
- [ ] Prepare test completion report
- [ ] UAT sign-off document

**Deliverables**: Traceability report, Coverage report, UAT sign-off
**Time**: Dev: 4-6h | QA: 4-6h

---

## Day 15 - Retrospective & Demo (Date: ______)

### All Teams
- [ ] Sprint retrospective
- [ ] Demo to stakeholders
- [ ] Present test coverage
- [ ] Present traceability report
- [ ] Plan deployment
- [ ] Prepare for next sprint
- [ ] Document lessons learned
- [ ] Archive test artifacts

**Time**: Dev: 3h | QA: 3h

---

## Sprint Summary

### Test Execution Metrics

| Metric | Target | Actual | Status |
|--------|--------|--------|--------|
| Requirements documented | 100% | ___% | [ ] |
| AC coverage | 100% | ___% | [ ] |
| Test cases generated | 30-45 | ___ | [ ] |
| Day 5 pass rate | 33% | ___% | [ ] |
| Day 7 pass rate | 86% | ___% | [ ] |
| Day 9 pass rate | 78% | ___% | [ ] |
| Day 11 pass rate | 93% | ___% | [ ] |
| Day 12 pass rate | 100% | ___% | [ ] |
| Traceability | 100% | ___% | [ ] |

### Bug Metrics

| Priority | Found | Fixed | Deferred | Status |
|----------|-------|-------|----------|--------|
| P1 (Critical) | ___ | ___ | ___ | [ ] |
| P2 (High) | ___ | ___ | ___ | [ ] |
| P3 (Medium) | ___ | ___ | ___ | [ ] |
| P4 (Low) | ___ | ___ | ___ | [ ] |
| **Total** | ___ | ___ | ___ | [ ] |

### Agent Execution

| Agent | Day | Duration | Status |
|-------|-----|----------|--------|
| ProjectSetupAgent | Day 0 | ___h | [ ] |
| FunctionalTestAutomationAgent | Day 1 | ___h | [ ] |
| APITestAgent | Day 3 | ___h | [ ] |
| IntegrationTestAgent | Day 3 | ___h | [ ] |
| EndToEndTestAgent | Day 8 | ___h | [ ] |
| LocatorHealingAgent | Day 12 | ___h | [ ] |

### Freeze Points Adherence

- [ ] Day 1 EOD: Story Freeze (on-time / delayed by ___ days)
- [ ] Day 2 EOD: API + DB Freeze (on-time / delayed by ___ days)
- [ ] Day 8: Code Complete (on-time / delayed by ___ days)
- [ ] Day 12: Test Complete (on-time / delayed by ___ days)

---

## Lessons Learned

### What Went Well
1. _________________________________________________
2. _________________________________________________
3. _________________________________________________

### What Can Be Improved
1. _________________________________________________
2. _________________________________________________
3. _________________________________________________

### Action Items for Next Sprint
1. _________________________________________________
2. _________________________________________________
3. _________________________________________________

---

## Sign-off

**QA Lead**: __________________________ Date: __________

**Dev Lead**: __________________________ Date: __________

**Product Owner**: __________________________ Date: __________

---

**Sprint Status**: [ ] Complete [ ] Partial [ ] Deferred to next sprint

**Ready for Production**: [ ] Yes [ ] No

**Next Sprint Planning Date**: __________

---

## Quick Reference

### Key Commands
```bash
# Day 0
/setup-project (first sprint only)
/verify

# Day 1
/start-functional-tests {ModuleName}

# Day 3
Start APITestAgent and IntegrationTestAgent for module {ModuleName}

# Day 8
/start-e2e-tests {ModuleName}

# Day 12
/heal-locators {ModuleName}

# Test Execution
npx playwright test
npx playwright test tests/functional/{module}
npx playwright test tests/api/{module}
npx playwright test tests/integration/{module}
npx playwright test tests/e2e/{module}
npx playwright show-report
```

### Key Files
- **Config**: `orchestrator-config.json`
- **Requirements**: `requirements/{ModuleName}.md`
- **Functional Tests**: `tests/functional/{module}/*.spec.js`
- **Page Objects**: `pages/{module}/*.page.js`
- **Traceability**: `test-designs/{module}/traceability-matrix.md`

---

**PRINT THIS PAGE AND USE IT AS YOUR DAILY SPRINT TRACKER!**
