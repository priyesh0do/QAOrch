# 15-Day Sprint Plan - QA Test Orchestrator Integration

**Version**: 1.0.0
**Date**: March 2026
**Sprint Duration**: 15 working days
**Parallel Workflows**: Dev Team (OneBot) + QA Team (QA Orchestrator)

---

## Table of Contents

1. [Overview](#overview)
2. [Two Scenarios](#two-scenarios)
3. [Critical Freeze Points](#critical-freeze-points)
4. [Day-Wise Sprint Plan](#day-wise-sprint-plan)
5. [Parallel Execution Strategy](#parallel-execution-strategy)
6. [Handoff Checklist](#handoff-checklist)
7. [Agent Execution Timeline](#agent-execution-timeline)

---

## Overview

This plan integrates the **QA Test Orchestrator** with your existing development workflow where the dev team uses **OneBot (Claude Code)** for development. The plan ensures QA test generation happens in parallel with development, respecting critical freeze points.

### Team Structure

| Team | Tool | Responsibilities |
|------|------|------------------|
| **Dev Team** | OneBot (Claude Code) | Architecture, code, DB schema, API definitions |
| **QA Team** | QA Orchestrator (Claude Code) | Requirements parsing, test generation, traceability |
| **PO/BA** | JIRA | Master stories (EPICs), acceptance criteria, story review |

---

## Two Scenarios

### Scenario 1: First Sprint (Project Initialization)

**When**: Starting a brand new module or project for the first time

**Day 0 Additional Step**:
```bash
# Run ONCE at project start
/setup-project
```

**What it does**:
- Creates project directory structure
- Generates base classes and utilities
- Creates rules.md with coding standards
- Analyzes reference projects (if configured)
- Sets up Playwright configuration

**Approval**: 4 checkpoints (1 hour total)

**Output**:
```
ProjectRoot/
├── pages/              # Page object directory
├── tests/
│   ├── functional/
│   ├── integration/
│   ├── api/
│   └── e2e/
├── test-designs/       # Test design documents
├── utils/              # Base classes
└── rules.md           # QA coding standards
```

### Scenario 2: Ongoing Sprints

**When**: All subsequent sprints after initial setup

**Day 0**: Skip ProjectSetupAgent, start directly with Day 1 activities

---

## Critical Freeze Points

These are **HARD STOPS** where QA needs stable artifacts to generate tests:

| Day | Freeze Point | Required For | QA Action |
|-----|--------------|--------------|-----------|
| **Day 1 EOD** | **Story Freeze** (UI + Backend) | Functional tests | Start FunctionalTestAutomationAgent |
| **Day 2 EOD** | **API Definition Freeze** | API tests | Start APITestAgent |
| **Day 2 EOD** | **DB Schema Freeze** | Integration tests | Start IntegrationTestAgent (after functional) |
| **Day 8** | **Code Complete** | E2E tests | Start EndToEndTestAgent |
| **Day 12** | **Test Execution Complete** | Locator healing | Run LocatorHealingAgent (if failures) |

---

## Day-Wise Sprint Plan

### Day 0: Planning & Refinement (Sprint Planning Day)

**Dev Team (OneBot)**:
- Create Master Story (EPIC) in JIRA
- Define high-level requirements
- Break down into user stories
- Define detailed Acceptance Criteria

**QA Team (Orchestrator)**:
- **SCENARIO 1 ONLY**: Run `/setup-project` (1 hour)
- Review acceptance criteria for completeness
- Ensure REQ-XXX and AC-XXX format is followed
- Prepare requirements documents: `requirements/{ModuleName}.md`

**Deliverables**:
- JIRA EPIC with detailed acceptance criteria
- Requirements document in `requirements/{ModuleName}.md` (REQ-XXX, AC-XXX format)
- **First Sprint Only**: Project structure created

**QA Orchestrator Commands**:
```bash
# FIRST SPRINT ONLY
/setup-project

# Verify configuration
/verify
```

---

### Day 1: Design + Story Creation + DB Schema

**FREEZE POINT**: EOD - Story Freeze (UI + Backend)

**Dev Team (OneBot)**:
- Architecture design (High-level, System design)
- UX/UI mockups
- API endpoint definitions (draft)
- Backend service design
- Database schema (initial draft)
- Data flow diagrams

**QA Team (Orchestrator)**:
- Review finalized stories and acceptance criteria
- **START FUNCTIONAL TEST GENERATION** (after story freeze)
- Parse requirements
- Identify MDS components
- Create traceability matrix

**Deliverables**:
- Architecture documentation
- DB schema (draft)
- API schema (draft)
- **Frozen user stories** (UI + Backend)

**QA Orchestrator Commands** (EOD, after story freeze):
```bash
# Start functional test generation
/start-functional-tests {ModuleName}

# Or naturally:
Start FunctionalTestAutomationAgent for module {ModuleName}
```

**Timeline**:
- Analysis Phase: 30 min → [Approve]
- Design Phase: 45 min → [Approve]
- Generation Phase: 1 hour → [Approve]
- Validation Phase: 30 min → [Approve]
- **Total: ~3 hours** (requires QA presence for 4 approvals)

**Outputs**:
```
test-designs/{module}/functional-design.md
test-designs/{module}/traceability-matrix.md
pages/{module}/*.page.js
tests/functional/{module}/*.spec.js
```

---

### Day 2: DB Schema Scripts + API Schema Definition

**FREEZE POINT**: EOD - API Definition Freeze + DB Schema Freeze

**Dev Team (OneBot)**:
- Finalize DB schema scripts
- Complete API endpoint definitions (OpenAPI/Swagger)
- Define request/response schemas
- Database migration scripts

**QA Team (Orchestrator)**:
- **CONTINUE** functional test generation (if not complete from Day 1)
- Review API specifications
- Review DB schema

**Deliverables**:
- **Frozen DB schema scripts**
- **Frozen API definitions** (OpenAPI/Swagger spec)
- Functional tests (in progress or completed)

**QA Orchestrator Status**:
- FunctionalTestAutomationAgent should be in Generation or Validation phase

---

### Day 3: API Schema Finalization + Backend Dev Start

**Dev Team (OneBot)**:
- Start backend service implementation
- Implement API endpoints (partial)
- Database integration

**QA Team (Orchestrator)**:
- **START API TEST GENERATION** (using frozen API spec from Day 2)
- **START INTEGRATION TEST GENERATION** (using frozen DB schema)
- Complete functional test generation

**QA Orchestrator Commands**:
```bash
# Start API tests
/start-api-tests {ModuleName}

# Start integration tests (depends on functional tests being done)
/start-integration-tests {ModuleName}

# Or run in parallel:
Start APITestAgent and IntegrationTestAgent for module {ModuleName}
```

**Parallel Execution**:
- APITestAgent: Independent, can run in parallel
- IntegrationTestAgent: Depends on FunctionalTestAutomationAgent (must be complete)

**Timeline**:
- APITestAgent: ~2 hours (4 approval checkpoints)
- IntegrationTestAgent: ~2.5 hours (4 approval checkpoints)
- **Can run concurrently** with user managing approvals

**Outputs**:
```
# API Tests
tests/api/{module}/*.spec.js
tests/api/services/apiClient.js
tests/api/services/schemaValidator.js

# Integration Tests
test-designs/{module}/integration-design.md
test-designs/{module}/data-flow-diagram.md
tests/integration/{module}/*.spec.js
```

---

### Day 4: Backend Development Begins + Test Generation Complete

**Dev Team (OneBot)**:
- Start backend service implementation
- Implement first API endpoints (CRUD operations)
- Database connection setup
- Initial data models implementation
- Set up unit test framework

**QA Team (Orchestrator)**:
- **Complete API test generation** (if started Day 3)
- **Complete Integration test generation** (if started Day 3)
- Review all generated test artifacts
- Set up test execution environment
- Configure test data and fixtures

**Deliverables**:
- First API endpoints implemented
- All test generation complete (Functional + API + Integration)
- Test environment ready

**QA Activities**:
```bash
# Verify all tests are generated
ls tests/functional/{module}
ls tests/api/{module}
ls tests/integration/{module}

# Review generated page objects
ls pages/{module}

# Set up test data
# Configure baseUrl and environment
```

**Outputs**:
- All test specs generated: 30-45 test files
- All page objects created: 10-15 page objects
- Test environment configured

---

### Day 5: Backend Development + Initial Test Execution

**Dev Team (OneBot)**:
- Continue API endpoint implementation
- Implement business logic for core features
- Database CRUD operations
- Error handling implementation
- Unit tests for backend services

**QA Team (Orchestrator)**:
- **START TEST EXECUTION** - Functional tests
- Execute tests against partially working endpoints
- Log initial failures (expected due to incomplete code)
- Create test execution baseline
- Document test execution process

**Deliverables**:
- 50% of API endpoints complete
- Initial test execution report
- Failure logs documented

**QA Activities**:
```bash
# Run functional tests
npx playwright test tests/functional/{module}

# Generate report
npx playwright show-report

# Document results
# Expected: Some tests pass, some fail (code not complete)
```

**Test Execution Tracking**:
```
Functional Tests:
- Total: 15 tests
- Passed: 5 (33%)
- Failed: 10 (67%)
- Reason: Backend not complete

Action: Log failures, track for Day 8 retest
```

---

### Day 6: Backend Development + API Test Execution

**Dev Team (OneBot)**:
- Continue backend implementation
- Complete remaining API endpoints
- Implement validation logic
- Add authentication/authorization
- Database transaction handling
- Unit tests coverage

**QA Team (Orchestrator)**:
- **Execute API tests** against available endpoints
- Test API request/response schemas
- Validate error handling
- Document API test results
- Compare with OpenAPI spec

**Deliverables**:
- 75% of backend services complete
- API test execution report
- Schema validation results

**QA Activities**:
```bash
# Run API tests
npx playwright test tests/api/{module}

# Test specific endpoints
npx playwright test tests/api/{module}/get-*.spec.js
npx playwright test tests/api/{module}/post-*.spec.js

# Generate API test report
npx playwright show-report
```

**Test Execution Tracking**:
```
API Tests:
- Total: 10 tests
- Passed: 7 (70%)
- Failed: 3 (30%)
- Reason: Some endpoints not implemented

Functional Tests (Re-run):
- Total: 15 tests
- Passed: 10 (67%)
- Failed: 5 (33%)
- Reason: More endpoints working
```

---

### Day 7: Backend Development + Integration Test Execution

**Dev Team (OneBot)**:
- Complete backend service implementation
- Final API endpoints
- Database optimization
- Performance testing
- Complete unit tests
- Code review preparation

**QA Team (Orchestrator)**:
- **Execute Integration tests** (UI → API → DB)
- Validate data flow across layers
- Test database state changes
- Verify data persistence
- Document integration test results

**Deliverables**:
- **Backend 100% code complete**
- Integration test execution report
- Data flow validation complete
- Pre-handoff checklist completed

**QA Activities**:
```bash
# Run integration tests
npx playwright test tests/integration/{module}

# Verify data flow
# Check database state after test execution

# Re-run all tests
npx playwright test

# Generate comprehensive report
npx playwright show-report
```

**Test Execution Tracking**:
```
Integration Tests:
- Total: 12 tests
- Passed: 10 (83%)
- Failed: 2 (17%)
- Reason: Minor data mapping issues

All Tests (Re-run):
- Total: 37 tests
- Passed: 32 (86%)
- Failed: 5 (14%)
- Reason: Minor bugs, tracked in JIRA

Action: Report bugs to Dev team
```

**Pre-Code Complete Checklist**:
- [ ] All API endpoints implemented
- [ ] All database operations working
- [ ] Unit tests passing (>90%)
- [ ] Test environment stable
- [ ] Test data seeded
- [ ] Ready for Day 8 handoff

---

### Day 8: Code Complete + E2E Test Generation

**MILESTONE**: Code Complete (Dev team delivers working code)

**Dev Team (OneBot)**:
- Code complete (all endpoints working)
- Integration testing complete
- Ready for QA testing

**QA Team (Orchestrator)**:
- **START E2E TEST GENERATION** (complete user journeys)
- Continue test execution (functional, API, integration)
- Document test results

**QA Orchestrator Commands**:
```bash
# Start E2E tests (requires functional + integration to be complete)
/start-e2e-tests {ModuleName}
```

**Timeline**:
- EndToEndTestAgent: ~3 hours (4 approval checkpoints)

**Outputs**:
```
test-designs/{module}/e2e-design.md
test-designs/{module}/user-journey-map.md
tests/e2e/{module}/*.spec.js
```

---

### Day 9: Intensive Testing + Bug Reporting (Priority 1 Bugs)

**MILESTONE**: Full Test Suite Execution Begins

**Dev Team (OneBot)**:
- Receive bug reports from QA
- Triage bugs (P1, P2, P3, P4)
- Start fixing **Priority 1 (Critical)** bugs
- Hot fixes for blockers
- Deploy fixes to test environment

**QA Team (Orchestrator)**:
- **Execute complete test suite** (Functional + API + Integration + E2E)
- Log **all defects** in JIRA with priority
- Create bug reports with detailed steps
- Track test execution metrics
- Identify blocker issues

**Deliverables**:
- Complete test execution report
- Bug reports logged in JIRA
- Priority 1 bugs identified
- Test metrics dashboard

**QA Activities**:
```bash
# Execute complete test suite
npx playwright test

# Run by test type
npx playwright test tests/functional/{module}
npx playwright test tests/api/{module}
npx playwright test tests/integration/{module}
npx playwright test tests/e2e/{module}

# Generate detailed report
npx playwright show-report

# Run specific failed tests
npx playwright test --grep "failing-test-name"
```

**Test Execution Results (Day 9)**:
```
Complete Test Suite:
- Total: 45 tests
- Passed: 35 (78%)
- Failed: 10 (22%)

By Test Type:
Functional: 15 tests → 12 passed (80%), 3 failed
API: 10 tests → 9 passed (90%), 1 failed
Integration: 12 tests → 10 passed (83%), 2 failed
E2E: 8 tests → 4 passed (50%), 4 failed

Bugs Logged:
- P1 (Critical): 2 bugs
- P2 (High): 3 bugs
- P3 (Medium): 3 bugs
- P4 (Low): 2 bugs
Total: 10 bugs
```

**Bug Report Example**:
```markdown
Bug ID: BUG-001
Priority: P1 (Critical)
Module: {ModuleName}
Test: TC-005 - Add New Record
Steps:
1. Navigate to Add form
2. Fill all required fields
3. Click Submit

Expected: Record saved, success message
Actual: Error 500, database constraint violation

Environment: Test
Browser: Chrome
Screenshot: attached
```

---

### Day 10: Bug Fixes + Regression Testing (Priority 1 & 2)

**Dev Team (OneBot)**:
- Complete **Priority 1** bug fixes
- Start **Priority 2 (High)** bug fixes
- Deploy fixes to test environment
- Update API documentation if needed
- Code review for bug fixes

**QA Team (Orchestrator)**:
- **Retest fixed P1 bugs**
- Continue full regression testing
- Execute tests for P1 bug areas
- Update test data if needed
- Track locator failures
- Monitor test stability

**Deliverables**:
- P1 bugs fixed and verified
- P2 bugs fixed
- Regression test report
- Updated bug status in JIRA

**QA Activities**:
```bash
# Retest P1 bugs
npx playwright test tests/functional/{module}/TC-005-add-record.spec.js
npx playwright test tests/integration/{module}/INT-003-data-save.spec.js

# Run full regression
npx playwright test

# Run failed tests from Day 9
npx playwright test --last-failed

# Generate comparison report
npx playwright show-report
```

**Test Execution Results (Day 10)**:
```
Complete Test Suite:
- Total: 45 tests
- Passed: 40 (89%)
- Failed: 5 (11%)

Improvement from Day 9: +11%

P1 Bug Retest:
- BUG-001: FIXED ✓
- BUG-002: FIXED ✓

P2 Bug Retest:
- BUG-003: FIXED ✓
- BUG-004: FIXED ✓
- BUG-005: IN PROGRESS

Remaining Failures:
- P2: 1 bug (in progress)
- P3: 3 bugs
- P4: 2 bugs

Locator Issues Identified: 3
- Login button selector changed
- Dashboard table header changed
- Form submit button not found
```

**Locator Failure Tracking**:
```
Test: TC-012 - Dashboard Navigation
Error: Locator '[data-testid="dashboard-btn"]' not found
Reason: Button changed to '[data-testid="dash-button"]'
Action: Track for Day 12 healing

Test: TC-018 - Form Submission
Error: Locator 'button:has-text("Submit")' timeout
Reason: Button text changed to "Save Changes"
Action: Track for Day 12 healing
```

---

### Day 11: Final Bug Fixes + Full Regression (All Priorities)

**Dev Team (OneBot)**:
- Complete **Priority 2** bug fixes
- Fix **Priority 3 (Medium)** bugs
- **Priority 4 (Low)** bugs - defer if needed
- Final code review
- Code stabilization
- Prepare for UAT

**QA Team (Orchestrator)**:
- **Retest all fixed bugs** (P1, P2, P3)
- Execute complete regression suite
- Validate all test scenarios
- Document final test results
- Prepare bug summary report
- **Consolidate locator failure list** for Day 12

**Deliverables**:
- All P1, P2, P3 bugs fixed and verified
- P4 bugs documented (deferred if needed)
- Final regression report
- Locator failure list
- Test execution summary

**QA Activities**:
```bash
# Run complete regression suite
npx playwright test

# Run by priority areas
npx playwright test tests/functional/{module} --workers=4
npx playwright test tests/api/{module} --workers=4
npx playwright test tests/integration/{module} --workers=4
npx playwright test tests/e2e/{module} --workers=4

# Generate final report
npx playwright show-report

# Export results
npx playwright test --reporter=json > test-results-day11.json
```

**Test Execution Results (Day 11)**:
```
Complete Test Suite:
- Total: 45 tests
- Passed: 42 (93%)
- Failed: 3 (7%)

Improvement from Day 10: +4%

Bug Status:
- P1 (Critical): 2 bugs → FIXED ✓
- P2 (High): 3 bugs → FIXED ✓
- P3 (Medium): 3 bugs → FIXED ✓
- P4 (Low): 2 bugs → DEFERRED (documented)

Remaining Failures (3 tests):
All due to UI locator changes (not bugs)
- TC-012: Dashboard navigation
- TC-018: Form submission
- TC-025: Table sorting

Action: Run LocatorHealingAgent on Day 12
```

**Test Execution Summary Report**:
```markdown
# Test Execution Summary - Day 11

## Overall Results
- **Total Tests**: 45
- **Pass Rate**: 93%
- **Execution Time**: 8 minutes

## By Test Type
| Type | Total | Passed | Failed | Pass % |
|------|-------|--------|--------|--------|
| Functional | 15 | 14 | 1 | 93% |
| API | 10 | 10 | 0 | 100% |
| Integration | 12 | 12 | 0 | 100% |
| E2E | 8 | 6 | 2 | 75% |

## Bug Summary
- **Total Bugs Found**: 10
- **Fixed**: 8
- **Deferred**: 2 (P4)

## Issues
- **Locator Failures**: 3 (scheduled for healing Day 12)
- **Blockers**: 0
- **Outstanding**: 0

## Readiness for UAT
- ✓ All critical bugs fixed
- ✓ Pass rate >90%
- ✓ No blockers
- ⚠ Locator healing needed (Day 12)

## Recommendation
- Proceed with locator healing on Day 12
- UAT ready after healing completion
```

---

### Day 12: Locator Healing + Regression

**MILESTONE**: Test Execution Complete

**Dev Team (OneBot)**:
- Final bug fixes
- Code review
- Documentation

**QA Team (Orchestrator)**:
- **RUN LOCATOR HEALING** (if tests are failing due to UI changes)
- Update test suite with healed locators
- Final regression testing

**QA Orchestrator Commands**:
```bash
# Heal broken locators
/heal-locators {ModuleName}

# Or naturally:
Heal broken locators in the {ModuleName} module
```

**What LocatorHealingAgent does**:
1. Analyzes failed tests
2. Identifies broken locators
3. Generates 5 alternative locator strategies per failure
4. Updates page objects with best alternatives
5. Creates backup files (*.page.js.bak)

**Timeline**: 1-2 hours (4 approval checkpoints)

**Outputs**:
```
Updated: pages/{module}/*.page.js
Backups: pages/{module}/*.page.js.bak
Report: logs/{module}-healing-report.md
```

---

### Day 13: UAT Begins + User Testing Support

**MILESTONE**: UAT (User Acceptance Testing) Begins

**Dev Team (OneBot)**:
- Support UAT testing
- Monitor production-like environment
- Address urgent UAT issues
- Be available for questions
- Prepare deployment scripts

**QA Team (Orchestrator)**:
- **Support UAT testing**
- Provide test scenarios to business users
- Execute sanity tests in UAT environment
- Monitor UAT defects
- Update tests if new scenarios emerge
- Assist users with test execution

**Business Users / PO**:
- Execute UAT scenarios
- Validate against acceptance criteria
- Report UAT defects
- Provide feedback on usability

**Deliverables**:
- UAT environment ready
- UAT test scenarios provided
- Initial UAT feedback received
- UAT defect log

**QA Activities**:
```bash
# Run sanity tests in UAT environment
npx playwright test --grep "@smoke"

# Run critical path tests
npx playwright test tests/e2e/{module}

# Generate UAT report
npx playwright show-report
```

**UAT Test Scenarios Provided to Business**:
```markdown
# UAT Test Scenarios - {ModuleName}

## Scenario 1: Add New Record
1. Login as Manager
2. Navigate to {Module}
3. Click Add button
4. Fill all required fields
5. Submit form
6. Verify success message

Expected: Record appears in list

## Scenario 2: Edit Existing Record
...

## Scenario 3: Delete Record
...
```

**UAT Execution Tracking**:
```
UAT Scenarios:
- Total: 10 scenarios
- Executed: 6 scenarios
- Passed: 5
- Failed: 1

UAT Defects:
- UAT-001: Date format not user-friendly (P3)
- Expected: More feedback tomorrow
```

---

### Day 14: UAT Continues + Final Fixes

**Dev Team (OneBot)**:
- Fix UAT defects (if any)
- Address usability feedback
- Code refinements
- Prepare deployment plan
- Final code review

**QA Team (Orchestrator)**:
- **Continue UAT support**
- Retest UAT defects
- Execute final regression suite
- **Generate traceability report** for sign-off
- **Document test coverage**
- Prepare test completion report

**Business Users / PO**:
- Complete remaining UAT scenarios
- Final sign-off on acceptance criteria
- Approve for deployment

**Deliverables**:
- UAT defects fixed
- Final regression pass
- **Traceability report** (REQ → AC → TC)
- **Test coverage report**
- UAT sign-off document

**QA Activities**:
```bash
# Run final regression suite
npx playwright test

# Generate traceability report
# Review: test-designs/{module}/traceability-matrix.md

# Generate coverage report
npx playwright test --reporter=html

# Export test results
npx playwright test --reporter=json > final-test-results.json
```

**Final Traceability Report**:
```markdown
# Traceability Matrix - {ModuleName}

## Summary
- **Total Requirements**: 5
- **Total Acceptance Criteria**: 12
- **Total Test Cases**: 45
- **Coverage**: 100%

## Mapping

### REQ-001: Add New Record
- AC-001: Display Add Button
  - TC-001: Verify Add button visible
  - TC-002: Verify Add button clickable
- AC-002: Open Add Form
  - TC-003: Verify form opens
  - TC-004: Verify all fields present
  - TC-005: Verify field validations

### REQ-002: Edit Existing Record
...

## Coverage Analysis
- All acceptance criteria have test coverage
- All test cases trace to acceptance criteria
- No orphaned test cases
- No uncovered acceptance criteria
```

**Test Coverage Report**:
```markdown
# Test Coverage Report - {ModuleName}

## Test Execution Summary
- **Total Tests**: 45
- **Passed**: 45 (100%)
- **Failed**: 0
- **Pass Rate**: 100%
- **Execution Time**: 8 minutes

## Coverage by Test Type
| Type | Tests | Coverage | Status |
|------|-------|----------|--------|
| Functional | 15 | 100% REQ/AC | ✓ Pass |
| API | 10 | 100% Endpoints | ✓ Pass |
| Integration | 12 | 100% Data Flow | ✓ Pass |
| E2E | 8 | 100% Journeys | ✓ Pass |

## Requirements Coverage
- **REQ-001**: 10 test cases → 100% coverage
- **REQ-002**: 8 test cases → 100% coverage
- **REQ-003**: 12 test cases → 100% coverage
- **REQ-004**: 9 test cases → 100% coverage
- **REQ-005**: 6 test cases → 100% coverage

## Code Coverage (if applicable)
- Statement Coverage: 85%
- Branch Coverage: 78%
- Function Coverage: 92%

## Defects Summary
- **Total Defects**: 12
- **Fixed**: 10
- **Deferred**: 2 (P4, documented)
- **Outstanding**: 0

## Recommendation
✅ **READY FOR DEPLOYMENT**
```

**UAT Sign-off Document**:
```markdown
# UAT Sign-off - {ModuleName}

Sprint: {Number}
Date: {Date}
Module: {ModuleName}

## UAT Execution
- **Scenarios Executed**: 10/10 (100%)
- **Pass Rate**: 100%
- **User Feedback**: Positive

## Acceptance Criteria Validation
All acceptance criteria validated and approved:
- ✓ REQ-001: Add New Record
- ✓ REQ-002: Edit Record
- ✓ REQ-003: Delete Record
- ✓ REQ-004: List Records
- ✓ REQ-005: Search Records

## Defects
- No critical defects
- 2 P4 defects deferred to next sprint

## Sign-off
- Product Owner: ________________ Date: ______
- QA Lead: ________________ Date: ______
- Dev Lead: ________________ Date: ______

## Approval
✅ APPROVED FOR PRODUCTION DEPLOYMENT
```

---

### Day 15: Retrospective + Deployment Prep

**All Teams**:
- Sprint retrospective
- Demo to stakeholders
- Plan deployment
- Prepare for next sprint

**QA Deliverables**:
- Complete test suite (functional, integration, API, E2E)
- Traceability matrices (REQ → AC → TC)
- Test execution reports
- Coverage reports

---

## Parallel Execution Strategy

### Independent Agents (Can Run in Parallel)

```
┌─────────────────────────────────────────────────┐
│  Day 3: Start Both Agents Concurrently         │
├─────────────────────────────────────────────────┤
│  Agent 1: APITestAgent                          │
│  Agent 2: IntegrationTestAgent                  │
│                                                  │
│  ✓ No dependencies between them                 │
│  ✓ User manages approval checkpoints            │
│  ✓ Both complete in ~2-3 hours total            │
└─────────────────────────────────────────────────┘
```

**Command**:
```bash
Start APITestAgent and IntegrationTestAgent for module {ModuleName}
```

### Dependent Agents (Must Run Sequentially)

```
Day 1: FunctionalTestAutomationAgent
         ↓ (must complete)
Day 3: IntegrationTestAgent
         ↓ (must complete)
Day 8: EndToEndTestAgent
```

**Reason**: Each agent builds on artifacts from previous agents.

---

## Handoff Checklist

### Dev → QA Handoff Points

#### Day 1 EOD: Story Freeze
- [ ] All user stories finalized in JIRA
- [ ] Acceptance criteria in REQ-XXX, AC-XXX format
- [ ] Requirements document created at `requirements/{ModuleName}.md`
- [ ] UI mockups available (for MDS component identification)
- [ ] **QA Action**: Start `/start-functional-tests`

#### Day 2 EOD: API + DB Freeze
- [ ] OpenAPI/Swagger spec finalized
- [ ] DB schema scripts committed
- [ ] API endpoint list with request/response schemas
- [ ] Database ERD available
- [ ] **QA Action**: Start `/start-api-tests` and `/start-integration-tests`

#### Day 8: Code Complete
- [ ] All backend services deployed to test environment
- [ ] All API endpoints working
- [ ] Database seeded with test data
- [ ] Application accessible at baseUrl
- [ ] **QA Action**: Start `/start-e2e-tests` and begin test execution

#### Day 12: Test Complete
- [ ] All critical bugs fixed
- [ ] Test environment stable
- [ ] **QA Action**: Run `/heal-locators` if needed

---

## Agent Execution Timeline

### Visual Timeline

```
Day 0  [PROJECT SETUP]* (First Sprint Only)
       └─ /setup-project (1 hour, 4 approvals)

Day 1  [FUNCTIONAL TESTS]
       └─ /start-functional-tests (3 hours, 4 approvals)

Day 3  [API + INTEGRATION TESTS] (Parallel)
       ├─ /start-api-tests (2 hours, 4 approvals)
       └─ /start-integration-tests (2.5 hours, 4 approvals)

Day 8  [E2E TESTS]
       └─ /start-e2e-tests (3 hours, 4 approvals)

Day 12 [LOCATOR HEALING]
       └─ /heal-locators (1-2 hours, 4 approvals)
```

### Total QA Orchestrator Time

**First Sprint**:
- ProjectSetupAgent: 1 hour
- FunctionalTestAutomationAgent: 3 hours
- APITestAgent: 2 hours
- IntegrationTestAgent: 2.5 hours
- EndToEndTestAgent: 3 hours
- LocatorHealingAgent: 1-2 hours
- **Total: 12.5-13.5 hours** (spread across 15 days)

**Subsequent Sprints**:
- **Total: 11.5-12.5 hours** (skip ProjectSetupAgent)

### Approval Time Requirements

Each agent requires QA engineer presence for 4 approval checkpoints:
- Analysis: 5-10 minutes
- Design: 5-10 minutes
- Generation: 5-10 minutes
- Validation: 5-10 minutes

**Total per agent**: 20-40 minutes of active approval time

---

## Example: Running Sprint for Module "AbsenceCode"

### Day 0: Sprint Planning

```bash
# First Sprint Only
/setup-project

# Verify setup
/verify
```

**Create requirements document**: `requirements/AbsenceCode.md`
```markdown
## REQ-001: Add New Absence Code
Users shall be able to add new absence codes.

### AC-001: Display Add Button
The system shall display an "Add" button on the absence code list page.

### AC-002: Open Add Form
When the Add button is clicked, a form shall open with fields for code, description, and type.
```

### Day 1 EOD: After Story Freeze

```bash
# Start functional test generation
/start-functional-tests AbsenceCode
```

**Checkpoint 1 - Analysis** (30 min later):
```
╔════════════════════════════════════════════════════════════╗
║              PHASE 1: ANALYSIS COMPLETE                    ║
╚════════════════════════════════════════════════════════════╝

Extracted Requirements:
  ✓ REQ-001: Add New Absence Code (2 acceptance criteria)

Extracted Acceptance Criteria:
  ✓ AC-001: Display Add Button
  ✓ AC-002: Open Add Form

Identified Components:
  • MdsButton (Add button)
  • MdsInput (Code, Description fields)
  • MdsSelect (Type dropdown)

[A]pprove to continue to Phase 2
```
→ User types: **A**

**Continue approving** at Phase 2, 3, and 4.

### Day 3: After API/DB Freeze

```bash
# Start API and integration tests in parallel
Start APITestAgent and IntegrationTestAgent for module AbsenceCode
```

### Day 8: After Code Complete

```bash
# Start E2E tests
/start-e2e-tests AbsenceCode
```

### Day 12: If Tests Fail with Locator Issues

```bash
# Heal broken locators
/heal-locators AbsenceCode
```

---

## Configuration for Sprint

Ensure `orchestrator-config.json` is set up correctly:

```json
{
  "version": "3.0.0",
  "architecture": "agent-driven",
  "projectPath": "./test-automation",
  "requirementPath": "./requirements",
  "frontendProjectPath": "./frontend-app/src",
  "referenceProjectPath": "./reference-tests",
  "baseUrl": "http://localhost:5173",
  "framework": "Playwright",
  "language": "JavaScript",
  "agents": {
    "enabled": true,
    "parallelExecution": true,
    "maxConcurrentAgents": 3
  }
}
```

---

## Tips for Success

### 1. Prepare Requirements Early
- Ensure Day 0 requirements are in REQ-XXX/AC-XXX format
- Each AC should be testable and specific
- Avoid generic criteria like "system should work"

### 2. Respect Freeze Points
- Don't start test generation before freeze points
- Changes after freeze require test regeneration

### 3. Use Parallel Execution
- Run APITestAgent and IntegrationTestAgent together on Day 3
- Saves 2-3 hours of sequential execution

### 4. Monitor Test Execution
- Track failures between Days 4-11
- Prepare list of broken locators for Day 12 healing

### 5. Keep Claude Code Open
- QA engineer needs to approve checkpoints
- Each agent requires 20-40 minutes of active attention

### 6. Leverage Traceability
- Generated traceability matrices help with coverage reports
- Use for sprint demos and sign-off

---

## Troubleshooting

### Issue: Dev Stories Not Ready on Day 1 EOD

**Impact**: Cannot start FunctionalTestAutomationAgent

**Solution**:
- Push functional test generation to Day 2
- Adjust timeline: API/Integration tests move to Day 4
- Communicate delay to team

### Issue: API Definition Changes After Day 2 Freeze

**Impact**: API tests may be incorrect

**Solution**:
```bash
# Regenerate API tests
/start-api-tests {ModuleName}
# Approve all 4 checkpoints again
```

### Issue: Too Many Locator Failures on Day 12

**Impact**: Healing takes too long

**Solution**:
- Prioritize critical test failures
- Run healing for specific pages only
- Consider frontend code quality issues

### Issue: E2E Tests Depend on External Services

**Impact**: E2E generation blocked

**Solution**:
- Mock external services
- Update orchestrator-config.json with mock URLs
- Generate E2E tests with mock endpoints

---

## Sprint Metrics to Track

| Metric | Target | How to Measure |
|--------|--------|----------------|
| Requirements Ready (Day 0) | 100% | All REQ-XXX/AC-XXX documented |
| Story Freeze On-Time (Day 1) | 100% | No changes after EOD |
| Functional Tests Generated (Day 1) | 100% | All ACs have test cases |
| API/DB Freeze On-Time (Day 2) | 100% | No schema changes after EOD |
| Test Generation Complete (Day 8) | 100% | All 4 test types generated |
| Test Execution Pass Rate (Day 11) | >90% | Exclude known bugs |
| Locator Healing Success (Day 12) | >95% | Tests pass after healing |
| Traceability Coverage (Day 15) | 100% | All REQ→AC→TC mapped |

---

## Next Steps

1. **Week 1**: Run this plan for one module as pilot
2. **Week 2**: Gather feedback and adjust timeline
3. **Week 3**: Roll out to all team members
4. **Week 4**: Measure metrics and optimize

---

## Summary

| Day | Dev Team | QA Team | Orchestrator Action | Freeze Point |
|-----|----------|---------|---------------------|--------------|
| 0 | Epic, Stories, AC | Requirements doc | `/setup-project` (first sprint only) | - |
| 1 | Design, DB draft | Review AC | `/start-functional-tests` | Story Freeze EOD |
| 2 | DB scripts, API spec | Continue functional | - | API + DB Freeze EOD |
| 3 | Backend start | Start API + Integration | `/start-api-tests`, `/start-integration-tests` | - |
| 4-7 | Backend dev | Test execution | - | - |
| 8 | Code complete | Start E2E | `/start-e2e-tests` | Code Complete |
| 9-11 | Bug fixes | Test + report bugs | - | - |
| 12 | Final fixes | Locator healing | `/heal-locators` | Test Complete |
| 13-14 | UAT support | UAT testing | - | - |
| 15 | Retrospective | Coverage report | - | - |

**Total Orchestrator Time**: 12.5 hours (first sprint), 11.5 hours (subsequent sprints)

**Total Approval Time**: ~2 hours (spread across sprint)

**Test Coverage**: 100% (REQ → AC → TC traceability)
