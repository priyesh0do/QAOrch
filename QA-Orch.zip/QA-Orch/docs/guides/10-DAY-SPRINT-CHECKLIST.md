# 10-Day Sprint Daily Checklist

**Print this page and track your sprint progress!**

---

## Sprint Information

**Sprint Number**: _______________________
**Start Date**: _______________________
**End Date**: _______________________
**Module Name**: _______________________
**Team**: _______________________

---

## WEEK 1

---

### Day 1 (Monday) - Sprint Planning + Functional Tests
**Date**: ______ | **Day**: 1 of 10

#### Dev Team
- [ ] Sprint planning meeting (2 hours)
- [ ] Create EPIC in JIRA
- [ ] Break down into user stories
- [ ] Define acceptance criteria (REQ-XXX, AC-XXX)
- [ ] Architecture design (High-level, System)
- [ ] Create UX/UI mockups
- [ ] Database schema (draft)
- [ ] API endpoint definitions (draft)
- [ ] **5:00 PM: Story Freeze** ⚠️

#### QA Team
- [ ] Attend sprint planning
- [ ] Review acceptance criteria
- [ ] Create `requirements/{ModuleName}.md`
- [ ] First sprint: Run `/setup-project`
- [ ] Run `/verify`
- [ ] **After 5:00 PM**: Run `/start-functional-tests {ModuleName}`
- [ ] Approve Analysis Phase
- [ ] Approve Design Phase
- [ ] Approve Generation Phase
- [ ] Approve Validation Phase

#### Outputs Checklist
- [ ] EPIC created in JIRA
- [ ] User stories with AC
- [ ] Architecture document
- [ ] Requirements document (REQ-XXX/AC-XXX)
- [ ] Functional test design
- [ ] Traceability matrix
- [ ] Page objects (10-15 files)
- [ ] Functional tests (15-20 specs)

#### Quality Checks
- [ ] Stories frozen by 5:00 PM
- [ ] Requirements in REQ-XXX/AC-XXX format
- [ ] Traceability: Every AC has TC
- [ ] Functional tests cover all AC

**Time**: Dev: 6-8h | QA: 3-5h

---

### Day 2 (Tuesday) - API + Integration Tests
**Date**: ______ | **Day**: 2 of 10
**Quality Gate 1**: End of Day ⚠️

#### Dev Team
- [ ] Finalize DB schema scripts
- [ ] Create migration scripts
- [ ] Complete API definitions (OpenAPI/Swagger)
- [ ] Define request/response schemas
- [ ] API contract documentation
- [ ] **5:00 PM: API Freeze** ⚠️
- [ ] **5:00 PM: DB Schema Freeze** ⚠️

#### QA Team
- [ ] Complete functional tests (if not done Day 1)
- [ ] Review API specifications
- [ ] Review DB schema
- [ ] **After 5:00 PM**: Run API + Integration in parallel
- [ ] `Start APITestAgent and IntegrationTestAgent for module {ModuleName}`
- [ ] Approve 8 checkpoints (4 per agent)
- [ ] Review generated artifacts

#### Outputs Checklist
- [ ] DB schema scripts (frozen)
- [ ] OpenAPI specification (frozen)
- [ ] API test design
- [ ] Integration test design
- [ ] Data flow diagram
- [ ] API tests (10-15 specs)
- [ ] Integration tests (12-15 specs)

#### Quality Gate 1 Criteria
- [ ] All stories frozen
- [ ] Functional tests 100% generated
- [ ] API tests 100% generated
- [ ] Integration tests 100% generated
- [ ] Traceability matrix complete
- [ ] API/DB schemas frozen
- [ ] Total tests: 37-50 specs

**Sign-off**: ___________ (QA Lead) ___________ (Dev Lead)

**Time**: Dev: 6-8h | QA: 4-5h

---

### Day 3 (Wednesday) - E2E Tests + Backend Starts
**Date**: ______ | **Day**: 3 of 10

#### Dev Team
- [ ] Start backend service implementation
- [ ] Implement first API endpoints (CRUD)
- [ ] Database connection setup
- [ ] Initial data models
- [ ] Business logic (basic operations)
- [ ] Error handling setup

#### QA Team
- [ ] Run `/start-e2e-tests {ModuleName}`
- [ ] Approve 4 checkpoints
- [ ] Review E2E test design
- [ ] Review user journey map
- [ ] Set up test execution environment
- [ ] Configure test data fixtures
- [ ] Review all generated artifacts

#### Outputs Checklist
- [ ] Backend service skeleton
- [ ] First API endpoints (partial)
- [ ] E2E test design
- [ ] User journey map
- [ ] E2E tests (8-10 specs)
- [ ] Test environment configured
- [ ] Test fixtures created
- [ ] **All test generation complete** (45-60 specs)

#### Quality Checks
- [ ] E2E tests cover user journeys
- [ ] Test environment ready
- [ ] Total: 45-60 test specs generated

**Time**: Dev: 6-8h | QA: 6-7h

---

### Day 4 (Thursday) - Backend Dev + Initial Testing
**Date**: ______ | **Day**: 4 of 10

#### Dev Team
- [ ] Continue backend implementation
- [ ] Implement more API endpoints
- [ ] Database CRUD operations
- [ ] Business logic
- [ ] Validation rules
- [ ] Error handling
- [ ] Unit tests

#### QA Team
- [ ] Run functional tests: `npx playwright test tests/functional/{module}`
- [ ] Run API tests: `npx playwright test tests/api/{module}`
- [ ] Document initial results
- [ ] Log failures (expected - code not complete)
- [ ] Create baseline
- [ ] Track metrics

#### Test Results (Day 4)
Functional Tests:
- Total: _____ | Passed: _____ ( ___% ) | Failed: _____ ( ___% )

API Tests:
- Total: _____ | Passed: _____ ( ___% ) | Failed: _____ ( ___% )

**Expected**: 40-50% pass rate

#### Quality Checks
- [ ] Backend 40-50% complete
- [ ] Test environment stable
- [ ] Failures logged and tracked

**Time**: Dev: 6-8h | QA: 6-7h

---

### Day 5 (Friday) - Full Testing - END OF WEEK 1
**Date**: ______ | **Day**: 5 of 10
**Quality Gate 2**: End of Week 1 ⚠️

#### Dev Team
- [ ] Continue backend implementation
- [ ] Target: 70-80% complete
- [ ] Most API endpoints working
- [ ] Database operations stable
- [ ] Business logic
- [ ] Authentication/authorization
- [ ] Unit tests passing (>80%)

#### QA Team
- [ ] Run complete test suite: `npx playwright test`
- [ ] Execute all test types
- [ ] Generate comprehensive report
- [ ] Document all failures
- [ ] Track locator issues
- [ ] Prepare Week 1 summary

#### Test Results (Day 5)
| Test Type | Total | Passed | Failed | Pass % |
|-----------|-------|--------|--------|--------|
| Functional | _____ | _____ | _____ | _____% |
| API | _____ | _____ | _____ | _____% |
| Integration | _____ | _____ | _____ | _____% |
| E2E | _____ | _____ | _____ | _____% |
| **Overall** | _____ | _____ | _____ | _____% |

**Expected**: ~60% overall pass rate

#### Quality Gate 2 Criteria
- [ ] All tests generated (45-60 specs)
- [ ] Test environment stable
- [ ] Backend 70-80% complete
- [ ] Pass rate ~60%
- [ ] Week 1 summary complete

**Sign-off**: ___________ (QA Lead) ___________ (Dev Lead)

**Time**: Dev: 6-8h | QA: 6-8h

---

## [WEEKEND - Saturday & Sunday]

**No work activities - Team rest**

Optional (if critical):
- [ ] Emergency bug fixes
- [ ] Environment maintenance

---

## WEEK 2

---

### Day 6 (Monday) - Code Complete + Bug Reporting
**Date**: ______ | **Day**: 6 of 10

#### Dev Team
- [ ] Complete remaining backend (20-30%)
- [ ] Final API endpoints
- [ ] Database optimization
- [ ] Complete unit tests
- [ ] Integration testing
- [ ] **CODE COMPLETE** ✓
- [ ] Handoff to QA

#### QA Team
- [ ] Verify code complete
- [ ] Run complete test suite: `npx playwright test`
- [ ] Execute all test types
- [ ] Log all defects in JIRA (P1, P2, P3, P4)
- [ ] Create detailed bug reports
- [ ] Track metrics
- [ ] Bug triage

#### Test Results (Day 6)
| Test Type | Total | Passed | Failed | Pass % |
|-----------|-------|--------|--------|--------|
| Functional | _____ | _____ | _____ | _____% |
| API | _____ | _____ | _____ | _____% |
| Integration | _____ | _____ | _____ | _____% |
| E2E | _____ | _____ | _____ | _____% |
| **Overall** | _____ | _____ | _____ | _____% |

**Expected**: 75-80% pass rate

#### Bugs Logged
| Priority | Count | Examples |
|----------|-------|----------|
| P1 (Critical) | _____ | _________________________ |
| P2 (High) | _____ | _________________________ |
| P3 (Medium) | _____ | _________________________ |
| P4 (Low) | _____ | _________________________ |
| **Total** | _____ | |

**Expected**: 8-12 total bugs

#### Quality Checks
- [ ] Code 100% complete
- [ ] All bugs logged with priority
- [ ] Bug triage complete

**Time**: Dev: 6-8h | QA: 6-8h

---

### Day 7 (Tuesday) - P1/P2 Bug Fixes
**Date**: ______ | **Day**: 7 of 10
**Quality Gate 3**: End of Day ⚠️

#### Dev Team
- [ ] Fix P1 (Critical) bugs
- [ ] Fix P2 (High) bugs
- [ ] Deploy fixes to test environment
- [ ] Update API docs (if needed)
- [ ] Code review for bug fixes

#### QA Team
- [ ] Retest P1 bugs
- [ ] Retest P2 bugs
- [ ] Run regression: `npx playwright test`
- [ ] Validate bug fixes
- [ ] Update test data (if needed)
- [ ] Track locator failures
- [ ] Monitor stability

#### Test Results (Day 7)
| Test Type | Total | Passed | Failed | Pass % |
|-----------|-------|--------|--------|--------|
| Functional | _____ | _____ | _____ | _____% |
| API | _____ | _____ | _____ | _____% |
| Integration | _____ | _____ | _____ | _____% |
| E2E | _____ | _____ | _____ | _____% |
| **Overall** | _____ | _____ | _____ | _____% |

**Expected**: 88-92% pass rate

#### Bug Status
| Priority | Total | Fixed | Remaining |
|----------|-------|-------|-----------|
| P1 (Critical) | _____ | _____ | _____ |
| P2 (High) | _____ | _____ | _____ |
| P3 (Medium) | _____ | _____ | _____ |
| P4 (Low) | _____ | _____ | _____ |

#### Locator Issues
- [ ] Locator failures tracked: _____ issues
- [ ] List prepared for Day 9 healing

#### Quality Gate 3 Criteria
- [ ] Code complete (100%)
- [ ] P1 bugs: All fixed ✓
- [ ] P2 bugs: All fixed ✓
- [ ] Pass rate >85%
- [ ] Regression suite stable

**Sign-off**: ___________ (Dev Lead) ___________ (QA Lead)

**Time**: Dev: 6-8h | QA: 6-8h

---

### Day 8 (Wednesday) - P3 Bug Fixes + Final Regression
**Date**: ______ | **Day**: 8 of 10

#### Dev Team
- [ ] Fix P3 (Medium) bugs
- [ ] Assess P4 (Low) bugs
  - [ ] Critical P4: Fix
  - [ ] Non-critical P4: Defer and document
- [ ] Final code review
- [ ] Code stabilization
- [ ] Documentation updates

#### QA Team
- [ ] Retest P3 bugs
- [ ] Run complete regression: `npx playwright test`
- [ ] Validate all scenarios
- [ ] Document results
- [ ] Finalize locator failure list
- [ ] Prepare for Day 9 healing

#### Test Results (Day 8)
| Test Type | Total | Passed | Failed | Pass % |
|-----------|-------|--------|--------|--------|
| Functional | _____ | _____ | _____ | _____% |
| API | _____ | _____ | _____ | _____% |
| Integration | _____ | _____ | _____ | _____% |
| E2E | _____ | _____ | _____ | _____% |
| **Overall** | _____ | _____ | _____ | _____% |

**Expected**: 93-95% pass rate

#### Bug Status (Final)
| Priority | Total | Fixed | Deferred |
|----------|-------|-------|----------|
| P1 (Critical) | _____ | _____ | 0 |
| P2 (High) | _____ | _____ | 0 |
| P3 (Medium) | _____ | _____ | 0 |
| P4 (Low) | _____ | _____ | _____ |

#### Locator Issues (Final List)
1. _________________________________ (Ready for healing)
2. _________________________________ (Ready for healing)
3. _________________________________ (Ready for healing)
4. _________________________________ (Ready for healing)
5. _________________________________ (Ready for healing)

#### Quality Checks
- [ ] P3 bugs: All fixed ✓
- [ ] P4 bugs: Assessed and documented
- [ ] Only locator issues remain
- [ ] Ready for Day 9 healing

**Time**: Dev: 6-8h | QA: 6-8h

---

### Day 9 (Thursday) - Locator Healing + 100% Pass
**Date**: ______ | **Day**: 9 of 10
**Quality Gate 4**: End of Day ⚠️

#### Dev Team
- [ ] Support QA testing
- [ ] Fix critical issues (if found)
- [ ] Final documentation
- [ ] Deployment preparation
- [ ] Create deployment scripts
- [ ] Production checklist

#### QA Team
- [ ] Run `/heal-locators {ModuleName}`
- [ ] Approve 4 checkpoints
- [ ] Review healed locators (5 alternatives each)
- [ ] Verify updated page objects
- [ ] Check backup files created
- [ ] **Final regression**: `npx playwright test`
- [ ] Verify 100% pass rate
- [ ] Generate healing report
- [ ] Generate coverage report
- [ ] Generate traceability report
- [ ] Prepare UAT test scenarios

#### Test Results (Day 9) - FINAL
| Test Type | Total | Passed | Failed | Pass % |
|-----------|-------|--------|--------|--------|
| Functional | _____ | _____ | _____ | _____% |
| API | _____ | _____ | _____ | _____% |
| Integration | _____ | _____ | _____ | _____% |
| E2E | _____ | _____ | _____ | _____% |
| **Overall** | _____ | _____ | _____ | _____% |

**Expected**: 100% pass rate ✓

#### Locator Healing Results
- [ ] Locators healed: _____ / _____ (100%)
- [ ] Page objects updated
- [ ] Backup files created: *.page.js.bak
- [ ] Healing report generated

#### Reports Checklist
- [ ] Test execution report (100%)
- [ ] Locator healing report
- [ ] Coverage report (100%)
- [ ] Traceability report (100%)
- [ ] UAT test scenarios document

#### Quality Gate 4 Criteria
- [ ] All bugs fixed (P1/P2/P3)
- [ ] Locator healing complete
- [ ] Test pass rate 100% ✓
- [ ] Coverage 100%
- [ ] Traceability 100%
- [ ] UAT scenarios ready

**Sign-off**: ___________ (QA Lead) ___________ (PO)

**Time**: Dev: 4-6h | QA: 6-7h

---

### Day 10 (Friday) - UAT + Final Sign-off - SPRINT COMPLETE
**Date**: ______ | **Day**: 10 of 10
**Quality Gate 5**: Sprint Complete ⚠️

#### Dev Team
- [ ] Support UAT testing
- [ ] Monitor environment
- [ ] Address urgent UAT issues
- [ ] Final documentation review
- [ ] Deployment readiness verification
- [ ] Sprint retrospective

#### QA Team
- [ ] Coordinate UAT with business users
- [ ] Provide UAT test scenarios
- [ ] Execute sanity tests: `npx playwright test --grep "@smoke"`
- [ ] Monitor UAT defects
- [ ] Assist users with testing
- [ ] Collect UAT feedback
- [ ] Address UAT issues (if any)
- [ ] Final regression (if changes made)
- [ ] Generate final reports
- [ ] Sprint retrospective
- [ ] Archive test artifacts

#### UAT Execution
| Scenario | Status | Notes |
|----------|--------|-------|
| 1. _________________ | [ ] Pass [ ] Fail | _________________ |
| 2. _________________ | [ ] Pass [ ] Fail | _________________ |
| 3. _________________ | [ ] Pass [ ] Fail | _________________ |
| 4. _________________ | [ ] Pass [ ] Fail | _________________ |
| 5. _________________ | [ ] Pass [ ] Fail | _________________ |
| 6. _________________ | [ ] Pass [ ] Fail | _________________ |
| 7. _________________ | [ ] Pass [ ] Fail | _________________ |
| 8. _________________ | [ ] Pass [ ] Fail | _________________ |
| 9. _________________ | [ ] Pass [ ] Fail | _________________ |
| 10. ________________ | [ ] Pass [ ] Fail | _________________ |

**UAT Results**:
- Total Scenarios: _____
- Executed: _____
- Passed: _____
- Failed: _____
- Pass Rate: _____%

**Expected**: 100% pass rate ✓

#### UAT Defects
| ID | Priority | Description | Status |
|----|----------|-------------|--------|
| UAT-001 | _____ | _________________________ | [ ] Fixed |
| UAT-002 | _____ | _________________________ | [ ] Fixed |

#### Final Reports Checklist
- [ ] UAT execution report
- [ ] UAT sign-off document
- [ ] Final test execution report (100%)
- [ ] Coverage report (100%)
- [ ] Traceability report (100%)
- [ ] Deployment readiness document
- [ ] Sprint retrospective notes
- [ ] Test artifacts archived

#### Quality Gate 5 Criteria
- [ ] UAT complete (100% scenarios passed)
- [ ] PO sign-off obtained
- [ ] All documentation complete
- [ ] Test pass rate 100%
- [ ] Coverage 100%
- [ ] Traceability 100%
- [ ] **READY FOR PRODUCTION** ✓

**Final Sign-off**:
- PO: _____________________ Date: ______
- Dev Lead: ________________ Date: ______
- QA Lead: _________________ Date: ______

**Status**: [ ] APPROVED FOR PRODUCTION DEPLOYMENT

**Time**: Dev: 4-6h | QA: 6-8h

---

## Sprint Summary

### Test Generation Metrics

| Metric | Target | Actual | Status |
|--------|--------|--------|--------|
| Functional Tests | 15-20 | _____ | [ ] |
| API Tests | 10-15 | _____ | [ ] |
| Integration Tests | 12-15 | _____ | [ ] |
| E2E Tests | 8-10 | _____ | [ ] |
| **Total Tests** | **45-60** | _____ | [ ] |

### Test Execution Metrics

| Day | Expected Pass % | Actual Pass % | Status |
|-----|-----------------|---------------|--------|
| Day 4 | 40-50% | _____% | [ ] |
| Day 5 | ~60% | _____% | [ ] |
| Day 6 | 75-80% | _____% | [ ] |
| Day 7 | 88-92% | _____% | [ ] |
| Day 8 | 93-95% | _____% | [ ] |
| Day 9 | 100% | _____% | [ ] |
| Day 10 | 100% | _____% | [ ] |

### Bug Metrics

| Priority | Found | Fixed | Deferred | Status |
|----------|-------|-------|----------|--------|
| P1 (Critical) | _____ | _____ | 0 | [ ] |
| P2 (High) | _____ | _____ | 0 | [ ] |
| P3 (Medium) | _____ | _____ | 0 | [ ] |
| P4 (Low) | _____ | _____ | _____ | [ ] |
| **Total** | _____ | _____ | _____ | [ ] |

### Quality Gates

| Gate | Day | Status | Sign-off |
|------|-----|--------|----------|
| QG1 | Day 2 | [ ] Passed | __________ |
| QG2 | Day 5 | [ ] Passed | __________ |
| QG3 | Day 7 | [ ] Passed | __________ |
| QG4 | Day 9 | [ ] Passed | __________ |
| QG5 | Day 10 | [ ] Passed | __________ |

### Coverage Metrics

| Metric | Target | Actual | Status |
|--------|--------|--------|--------|
| Requirements Coverage | 100% | _____% | [ ] |
| AC Coverage | 100% | _____% | [ ] |
| Test Case Coverage | 100% | _____% | [ ] |
| Traceability (REQ→AC→TC) | 100% | _____% | [ ] |

### Time Metrics

| Team | Week 1 | Week 2 | Total |
|------|--------|--------|-------|
| Dev | _____h | _____h | _____h |
| QA | _____h | _____h | _____h |

---

## Retrospective

### What Went Well
1. _________________________________________________
2. _________________________________________________
3. _________________________________________________

### What Can Be Improved
1. _________________________________________________
2. _________________________________________________
3. _________________________________________________

### Action Items for Next Sprint
1. _________________________________________________
2. _________________________________________________
3. _________________________________________________

### Freeze Points Adherence
- [ ] Day 1 (5:00 PM): Story Freeze (on-time / delayed by _____)
- [ ] Day 2 (5:00 PM): API/DB Freeze (on-time / delayed by _____)
- [ ] Day 6: Code Complete (on-time / delayed by _____)

---

## Quick Command Reference

```bash
# Day 1
/setup-project (first sprint only)
/verify
/start-functional-tests {ModuleName}

# Day 2
Start APITestAgent and IntegrationTestAgent for module {ModuleName}

# Day 3
/start-e2e-tests {ModuleName}

# Days 4-8
npx playwright test
npx playwright show-report

# Day 9
/heal-locators {ModuleName}
npx playwright test

# Day 10
npx playwright test --grep "@smoke"
```

---

**Sprint Status**: [ ] In Progress [ ] Complete [ ] Deferred

**Ready for Production**: [ ] Yes [ ] No

**Next Sprint Planning Date**: __________

---

**PRINT THIS PAGE AT SPRINT START AND TRACK DAILY PROGRESS!**
