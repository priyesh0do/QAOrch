# QA Story Points Guide

**Version**: 1.0.0  
**Date**: April 2026  
**Purpose**: Define how many story points a QA engineer can handle in a sprint

---

## Table of Contents

1. [Quick Answer](#quick-answer)
2. [Understanding QA Story Points](#understanding-qa-story-points)
3. [QA Velocity by Sprint Type](#qa-velocity-by-sprint-type)
4. [Story Point Estimation for QA Tasks](#story-point-estimation-for-qa-tasks)
5. [Calculating QA Capacity](#calculating-qa-capacity)
6. [Team vs Individual Story Points](#team-vs-individual-story-points)

---

## Quick Answer

### TL;DR - How Many Story Points Can QA Pick Up?

**For a 10-day sprint:**
- **Junior QA**: 8-13 story points
- **Mid-level QA**: 13-21 story points
- **Senior QA**: 21-34 story points

**For a 15-day sprint (2 weeks):**
- **Junior QA**: 13-21 story points
- **Mid-level QA**: 21-34 story points
- **Senior QA**: 34-55 story points

**Using Fibonacci Scale**: 1, 2, 3, 5, 8, 13, 21, 34, 55

---

## Understanding QA Story Points

### What Are Story Points?

**Story points** measure the **relative effort** required to complete a piece of work, considering:
- **Complexity**: How hard is it?
- **Effort**: How much work is needed?
- **Uncertainty**: How many unknowns?

**NOT time-based**: Story points ≠ hours (but there's a correlation)

---

### QA Story Points vs Dev Story Points

**Key Difference**: QA picks up story points from **user stories** (not separate QA tasks)

#### Scenario 1: QA Story Points = % of Dev Story Points

**Example**: User story "Add New Absence Code" = 8 story points

**Team Agreement**: QA = 40% of dev effort

**Calculation**:
- Dev work: 8 points × 60% = 4.8 points (rounded to 5)
- QA work: 8 points × 40% = 3.2 points (rounded to 3)
- **QA picks up**: 3 story points for this story

#### Scenario 2: QA Has Separate Story Point Allocation

**Example**: Sprint has 50 total story points

**Team Agreement**: QA = 30% of sprint capacity

**Calculation**:
- Total sprint: 50 points
- QA capacity: 50 × 30% = 15 points
- **QA picks up**: 15 story points worth of testing

---

## QA Velocity by Sprint Type

### 10-Day Sprint Velocity

#### Junior QA (0-2 years experience)

**Capacity**: 8-13 story points

**Breakdown**:
- Simple story (3 points): Can handle 3-4 stories = 9-12 points
- Medium story (5 points): Can handle 2-3 stories = 10-15 points
- Complex story (8 points): Can handle 1-2 stories = 8-16 points

**Recommended mix**:
- 1 medium story (5 points)
- 2 simple stories (3 points each)
- **Total**: 11 story points

**What this means**:
- 25-35 automated tests
- 10-15 ACs covered
- 4-6 user stories tested
- 50-60 hours of work

---

#### Mid-Level QA (2-5 years experience)

**Capacity**: 13-21 story points

**Breakdown**:
- Simple story (3 points): Can handle 5-7 stories = 15-21 points
- Medium story (5 points): Can handle 3-4 stories = 15-20 points
- Complex story (8 points): Can handle 2-3 stories = 16-24 points

**Recommended mix**:
- 1 complex story (8 points)
- 1 medium story (5 points)
- 1 simple story (3 points)
- **Total**: 16 story points

**What this means**:
- 40-50 automated tests
- 15-20 ACs covered
- 6-8 user stories tested
- 50-60 hours of work

---

#### Senior QA (5+ years experience)

**Capacity**: 21-34 story points

**Breakdown**:
- Simple story (3 points): Can handle 7-11 stories = 21-33 points
- Medium story (5 points): Can handle 5-7 stories = 25-35 points
- Complex story (8 points): Can handle 3-4 stories = 24-32 points

**Recommended mix**:
- 2 complex stories (8 points each)
- 2 medium stories (5 points each)
- 1 simple story (3 points)
- **Total**: 29 story points

**What this means**:
- 55-65 automated tests
- 20-25 ACs covered
- 8-10 user stories tested
- 50-60 hours of work

---

### 15-Day Sprint Velocity

#### Junior QA
**Capacity**: 13-21 story points  
**Test generation**: 40-50 automated tests

#### Mid-Level QA
**Capacity**: 21-34 story points  
**Test generation**: 60-75 automated tests

#### Senior QA
**Capacity**: 34-55 story points  
**Test generation**: 80-100 automated tests

---

## Story Point Estimation for QA Tasks

### Fibonacci Scale for QA Work

#### 1 Story Point (XS - Extra Small)

**Example Tasks**:
- Smoke test for 1 screen
- Verify 1-2 ACs (simple validation)
- Execute existing test suite (no new tests)

**Time**: ~4 hours  
**Tests**: 3-5 automated tests  
**ACs**: 1-2

**Example Story**: "Update button label text"
- **QA Work**: Verify label changed, update 1 test
- **Estimate**: 1 point

---

#### 2 Story Points (S - Small)

**Example Tasks**:
- Functional testing for 1 simple screen
- 2-3 ACs (CRUD operations)
- Generate functional tests only

**Time**: ~6-8 hours  
**Tests**: 6-10 automated tests  
**ACs**: 2-3

**Example Story**: "Add new field to form"
- **QA Work**: Test field validation, update page object, add tests
- **Estimate**: 2 points

---

#### 3 Story Points (M - Medium)

**Example Tasks**:
- Functional + API testing for 1 feature
- 3-5 ACs (CRUD + validation)
- Generate functional + API tests

**Time**: ~10-12 hours  
**Tests**: 10-15 automated tests  
**ACs**: 3-5

**Example Story**: "Add new absence code with validation"
- **QA Work**: Test UI, API, validation rules, generate tests
- **Estimate**: 3 points

---

#### 5 Story Points (L - Large)

**Example Tasks**:
- Functional + API + Integration testing
- 5-8 ACs (CRUD + validation + integration)
- Generate functional + API + integration tests

**Time**: ~16-20 hours  
**Tests**: 15-25 automated tests  
**ACs**: 5-8

**Example Story**: "Employee time-off request workflow"
- **QA Work**: Test UI, API, DB integration, email notifications
- **Estimate**: 5 points

---

#### 8 Story Points (XL - Extra Large)

**Example Tasks**:
- Functional + API + Integration + E2E testing
- 8-12 ACs (Complex workflow)
- Generate all test types + custom test data setup

**Time**: ~24-32 hours  
**Tests**: 25-40 automated tests  
**ACs**: 8-12

**Example Story**: "Payroll calculation engine with multiple rule sets"
- **QA Work**: Complex calculations, edge cases, integration testing, E2E scenarios
- **Estimate**: 8 points

---

#### 13 Story Points (XXL - Extra Extra Large)

**Example Tasks**:
- Complete module testing (all test types)
- 12-20 ACs (Multiple features)
- Generate all test types + performance testing

**Time**: ~40-50 hours  
**Tests**: 40-60 automated tests  
**ACs**: 12-20

**Example Story**: "Complete absence management module (add/edit/delete/approve/report)"
- **QA Work**: All CRUD operations, workflows, reports, integrations
- **Estimate**: 13 points

**⚠️ Warning**: 13+ points = Too large for one sprint. Split into smaller stories.

---

### Story Point Estimation Template

**Use this in sprint planning**:

```markdown
# Story: [Story Title]

## Story Points (Dev): X points

## QA Estimate

### Acceptance Criteria Count: Y ACs

### Test Types Needed:
- [ ] Functional (X tests)
- [ ] API (X tests)
- [ ] Integration (X tests)
- [ ] E2E (X tests)

### Total Tests Estimated: X tests

### Complexity:
- [ ] Simple (1.0x)
- [ ] Medium (1.3x)
- [ ] Complex (1.7x)

### Dependencies:
- [ ] External API
- [ ] Database changes
- [ ] Third-party service

### QA Story Points: [1 / 2 / 3 / 5 / 8 / 13]

**Rationale**: [Explain why]
```

---

## Calculating QA Capacity

### Method 1: Historical Velocity (Recommended)

**Track for 3 sprints**:

**Sprint 1**:
- Committed: 15 points
- Completed: 13 points
- Velocity: 13

**Sprint 2**:
- Committed: 18 points
- Completed: 16 points
- Velocity: 16

**Sprint 3**:
- Committed: 20 points
- Completed: 18 points
- Velocity: 18

**Average Velocity**: (13 + 16 + 18) / 3 = **15.67 points**

**Sprint 4 Capacity**: Commit **15-16 points** (rounded average)

**Rule**: Use 3-sprint rolling average for capacity planning

---

### Method 2: Time-Based Calculation

**Step 1: Calculate available hours**

10-day sprint:
- Working days: 10
- Hours per day: 6-8 (accounting for meetings, breaks)
- **Total available**: 60-80 hours

**Step 2: Subtract overhead**

- Sprint planning: 2 hours
- Daily standups: 5 hours (30 min × 10 days)
- Sprint retrospective: 2 hours
- Unplanned work: 5-10 hours
- **Total overhead**: 14-19 hours

**Net available**: 60 - 15 = **45 hours**

**Step 3: Convert hours to story points**

**Team's story point = hour ratio**:
- 1 story point = 3-4 hours (typical)

**Calculation**:
- 45 hours ÷ 3.5 hours/point = **12.86 points**
- **Capacity**: 13 points (rounded)

---

### Method 3: Test-Based Calculation

**Step 1: Know your velocity**

From QA Orchestrator metrics:
- Mid-level QA generates: 45-50 tests in 10 days

**Step 2: Map tests to story points**

**Team's mapping**:
- 1 story point = 3-4 automated tests

**Calculation**:
- 45 tests ÷ 3.5 tests/point = **12.86 points**
- **Capacity**: 13 points (rounded)

---

### Method 4: Acceptance Criteria-Based

**Step 1: Count ACs you can handle**

From QA Orchestrator metrics:
- Mid-level QA covers: 15-20 ACs in 10 days

**Step 2: Map ACs to story points**

**Team's mapping**:
- 1 story point = 1-2 ACs

**Calculation**:
- 15 ACs ÷ 1.2 ACs/point = **12.5 points**
- **Capacity**: 13 points (rounded)

---

## Team vs Individual Story Points

### Approach 1: Shared Story Points (Recommended)

**How it works**:
- Dev and QA work on the SAME story
- Story point belongs to the STORY, not the person
- Story is "Done" when both dev AND qa are complete

**Example**:

**Story**: "Add new absence code" = **8 story points**

**Sprint Planning**:
- Dev picks up story: 8 points
- QA picks up SAME story: (already counted, no additional points)
- **Total sprint commitment**: 8 points

**Tracking**:
- Dev completes → Story moves to "In Testing" (still 8 points in progress)
- QA completes → Story moves to "Done" (8 points completed)

**Sprint Burndown**:
- Day 1: 8 points remaining
- Day 5 (Dev done): 8 points remaining (QA testing)
- Day 8 (QA done): 0 points remaining ✅

**Benefits**:
- ✅ Reflects true "Definition of Done"
- ✅ Encourages dev-QA collaboration
- ✅ Simpler tracking

**Drawbacks**:
- ❌ QA work not explicitly visible
- ❌ Hard to measure QA-specific velocity

---

### Approach 2: Separate QA Story Points

**How it works**:
- Dev has story points
- QA has SEPARATE story points for testing
- Two sets of tasks

**Example**:

**Story**: "Add new absence code"
- **Dev work**: 5 story points
- **QA work**: 3 story points
- **Total story**: 8 story points

**Sprint Planning**:
- Dev commits: 5 points
- QA commits: 3 points
- **Total sprint commitment**: 8 points

**Tracking**:
- Dev completes → 5 points completed
- QA completes → 3 points completed
- Story "Done" → Total 8 points completed

**Sprint Burndown**:
- Day 1: 8 points remaining
- Day 5 (Dev done): 3 points remaining (QA testing)
- Day 8 (QA done): 0 points remaining ✅

**Benefits**:
- ✅ QA work explicitly visible
- ✅ Easy to track QA velocity
- ✅ QA capacity planning clearer

**Drawbacks**:
- ❌ More tracking overhead
- ❌ Can create handoff mentality (dev "throws over wall")

---

### Approach 3: QA-Specific Stories

**How it works**:
- Dev stories (feature development)
- QA stories (test automation, test infrastructure)
- Separate backlogs

**Example**:

**Dev Stories** (Sprint Backlog):
- Story 1: "Add new absence code" = 8 points (dev only)
- Story 2: "Edit absence code" = 5 points (dev only)
- Story 3: "Delete absence code" = 3 points (dev only)

**QA Stories** (Sprint Backlog):
- QA-1: "Automate absence code tests" = 8 points (QA only)
- QA-2: "Set up test data for absence module" = 3 points (QA only)
- QA-3: "Fix flaky tests in user module" = 2 points (QA only)

**Sprint Commitment**:
- Dev commits: 16 points (from dev stories)
- QA commits: 13 points (from QA stories)
- **Total sprint**: 29 points

**Benefits**:
- ✅ Complete independence
- ✅ QA has own backlog and priorities
- ✅ Easy to measure QA velocity

**Drawbacks**:
- ❌ Siloed dev and QA work
- ❌ No shared ownership of stories
- ❌ Harder to coordinate

---

## Recommended: Hybrid Approach

**Best of both worlds**:

### 80% Shared Stories + 20% QA-Specific Stories

**Example Sprint** (Mid-level QA, 10-day sprint):

**Shared Stories** (80% of QA capacity):
- Story 1: "Add absence code" = 8 points (shared with dev)
- Story 2: "Edit absence code" = 5 points (shared with dev)
- **QA contributes**: ~10 points (80% of 13 total capacity)

**QA-Specific Stories** (20% of QA capacity):
- QA-1: "Heal locators in user module" = 2 points
- QA-2: "Update test data fixtures" = 1 point
- **QA owns**: 3 points (20% of 13 total capacity)

**Total QA Commitment**: 13 story points

**Benefits**:
- ✅ Collaboration on main stories
- ✅ QA has bandwidth for technical debt
- ✅ Visible QA velocity
- ✅ Flexible capacity allocation

---

## QA Capacity Planning Template

### Sprint Planning Worksheet

**Use this during sprint planning**:

```markdown
# Sprint [Number] - QA Capacity Planning

## QA Engineer: [Name]
## Experience Level: [Junior / Mid / Senior]
## Sprint Duration: [10 days / 15 days]

## Historical Velocity (last 3 sprints)
- Sprint N-2: X points
- Sprint N-1: X points  
- Sprint N: X points
- **Average**: X points

## Capacity Calculation

### Available Hours
- Working days: 10
- Hours per day: 7
- Total: 70 hours

### Overhead
- Meetings: 10 hours
- Unplanned: 5 hours
- Total overhead: 15 hours

### Net Capacity
- 70 - 15 = **55 hours**

### Story Point Capacity
- 55 hours ÷ 3.5 hours/point = **15.7 points**
- **Rounded**: 16 points

## Planned Work

### Shared Stories (80% = 12 points)
- [ ] Story 1: [Name] - X points
- [ ] Story 2: [Name] - X points
- [ ] Story 3: [Name] - X points
- **Subtotal**: 12 points

### QA-Specific Stories (20% = 4 points)
- [ ] QA-1: [Name] - X points
- [ ] QA-2: [Name] - X points
- **Subtotal**: 4 points

## Total Commitment: 16 points

## Risk Assessment
- [ ] Dependencies: [List]
- [ ] Blockers: [List]
- [ ] Unknowns: [List]

## Sign-off
- QA Engineer: ___________
- Scrum Master: ___________
```

---

## Quick Reference Table

### QA Story Point Capacity by Experience and Sprint

| QA Level | 10-Day Sprint | 15-Day Sprint | Tests Generated | ACs Covered |
|----------|---------------|---------------|-----------------|-------------|
| **Junior** | 8-13 points | 13-21 points | 25-35 tests | 10-15 ACs |
| **Mid-Level** | 13-21 points | 21-34 points | 40-50 tests | 15-20 ACs |
| **Senior** | 21-34 points | 34-55 points | 55-65 tests | 20-25 ACs |

### Story Point to Effort Mapping

| Story Points | QA Time | Tests Generated | Example Task |
|--------------|---------|-----------------|--------------|
| 1 point | 4 hours | 3-5 tests | Simple field change |
| 2 points | 6-8 hours | 6-10 tests | Add new field |
| 3 points | 10-12 hours | 10-15 tests | CRUD + validation |
| 5 points | 16-20 hours | 15-25 tests | Feature with integration |
| 8 points | 24-32 hours | 25-40 tests | Complex workflow |
| 13 points | 40-50 hours | 40-60 tests | Complete module |

### Safe Commitment Guidelines

**Rule of Thumb**:
- **Junior QA**: Commit 60-70% of calculated capacity (leave buffer)
- **Mid-Level QA**: Commit 75-85% of calculated capacity
- **Senior QA**: Commit 85-95% of calculated capacity

**Why?**: Accounts for unknowns, unplanned work, and underestimation

**Example** (Mid-level QA):
- Calculated capacity: 18 points
- Safe commitment: 18 × 0.8 = **14.4 points**
- **Commit**: 14-15 points

---

## Summary

### Key Takeaways

1. **QA Story Points** (10-day sprint):
   - Junior: 8-13 points
   - Mid-level: 13-21 points
   - Senior: 21-34 points

2. **Best Approach**: Hybrid (80% shared stories + 20% QA-specific)

3. **Capacity Planning**: Use 3-sprint rolling average

4. **Safe Commitment**: Commit 70-85% of calculated capacity

5. **Story Point Mapping**:
   - 1 point = 3-4 hours = 3-5 tests
   - 3 points = 10-12 hours = 10-15 tests
   - 8 points = 24-32 hours = 25-40 tests

### Quick Estimation Cheat Sheet

**Use in Sprint Planning**:

```
AC Count → Story Points
1-2 ACs = 1-2 points
3-5 ACs = 3 points
5-8 ACs = 5 points
8-12 ACs = 8 points
12+ ACs = 13+ points (split story)
```

---

**Document Owner**: QA Lead  
**Review Frequency**: Quarterly  
**Last Updated**: April 2026
