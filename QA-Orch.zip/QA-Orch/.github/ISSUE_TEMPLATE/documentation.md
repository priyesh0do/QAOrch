---
name: Documentation Issue
about: Report missing, unclear, or incorrect documentation
title: '[DOCS] '
labels: documentation
assignees: ''
---

## Documentation Issue Type
- [ ] Missing documentation
- [ ] Unclear/confusing documentation
- [ ] Incorrect/outdated documentation
- [ ] Typo or formatting issue
- [ ] Example needed

## Location
Where is the documentation issue?
- **File/Page:** [e.g., docs/getting-started.md, README.md]
- **Section:** [e.g., "Parallel Execution" section]

## Current Documentation
What does the current documentation say (or what's missing)?

```
Paste current text or describe what's missing
```

## Suggested Improvement
What should the documentation say instead? Or what should be added?

```
Your suggested documentation text
```

## Context
Why is this change important? What confusion does it cause?

## Additional Resources
Link to any resources that might help improve the documentation:
- Related code files
- External documentation
- Related issues or discussions
