---
name: Bug Report
about: Report a bug or issue with the QA Test Orchestrator
title: '[BUG] '
labels: bug
assignees: ''
---

## Bug Description
A clear and concise description of the bug.

## Agent Involved
Which agent were you using when the bug occurred?
- [ ] FunctionalTestAutomationAgent
- [ ] IntegrationTestAgent
- [ ] APITestAgent
- [ ] LocatorHealingAgent
- [ ] EndToEndTestAgent
- [ ] ProjectSetupAgent
- [ ] Other/Multiple agents

## Checkpoint
At which checkpoint did the issue occur?
- [ ] Analysis Phase
- [ ] Design Phase
- [ ] Generation Phase
- [ ] Validation Phase
- [ ] Before any checkpoint
- [ ] After completion

## Steps to Reproduce
1.
2.
3.

## Expected Behavior
What should have happened?

## Actual Behavior
What actually happened?

## Error Messages
```
Paste any error messages here
```

## Configuration
<details>
<summary>orchestrator-config.json (relevant sections)</summary>

```json
Paste relevant sections of your config here
```
</details>

## Environment
- **OS:** [e.g., Windows 11, macOS 13, Ubuntu 22.04]
- **Node.js Version:** [e.g., 18.17.0]
- **QA Orchestrator Version:** [e.g., 3.0.0]
- **Claude Code Version:** [if applicable]

## Additional Context
Add any other context, screenshots, or logs that might help.

## Possible Solution
(Optional) If you have ideas on how to fix this.
