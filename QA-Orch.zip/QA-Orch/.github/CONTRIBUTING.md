# Contributing to QA Test Orchestrator

Thank you for your interest in contributing to the QA Test Orchestrator! This document provides guidelines and instructions for contributing to the project.

## Table of Contents
- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Setup](#development-setup)
- [How to Contribute](#how-to-contribute)
- [Coding Standards](#coding-standards)
- [Testing Guidelines](#testing-guidelines)
- [Commit Message Guidelines](#commit-message-guidelines)
- [Pull Request Process](#pull-request-process)

## Code of Conduct

This project adheres to the Contributor Covenant [Code of Conduct](CODE_OF_CONDUCT.md). By participating, you are expected to uphold this code.

## Getting Started

### Prerequisites
- Node.js 18.x or higher
- Git
- Basic understanding of agent-based systems
- Familiarity with Playwright (for test generation features)

### Development Setup

1. **Fork and clone the repository**
   ```bash
   git clone https://github.com/YOUR_USERNAME/qa-test-orchestrator.git
   cd qa-test-orchestrator
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Verify installation**
   ```bash
   npm run verify
   ```

4. **Run example**
   ```bash
   node src/agents/example-usage.js
   ```

## How to Contribute

### Reporting Bugs
Use the [bug report template](.github/ISSUE_TEMPLATE/bug_report.md) to report bugs. Please include:
- Clear description of the bug
- Agent involved
- Checkpoint where it occurred
- Steps to reproduce
- Expected vs actual behavior
- Environment details

### Suggesting Features
Use the [feature request template](.github/ISSUE_TEMPLATE/feature_request.md) to suggest features. Please include:
- Clear description of the feature
- Problem it solves
- Proposed solution
- Use case examples

### Improving Documentation
Use the [documentation issue template](.github/ISSUE_TEMPLATE/documentation.md) to suggest documentation improvements.

## Development Workflow

### 1. Create a Branch
```bash
git checkout -b feature/your-feature-name
# or
git checkout -b fix/your-bug-fix
```

Use prefixes:
- `feature/` - New features
- `fix/` - Bug fixes
- `docs/` - Documentation changes
- `refactor/` - Code refactoring
- `test/` - Test improvements
- `perf/` - Performance improvements

### 2. Make Changes
- Write clean, readable code
- Follow the coding standards below
- Add tests for new features
- Update documentation as needed

### 3. Test Changes
```bash
# Run verification
npm run verify

# Test specific agent (if applicable)
node src/execute-agent.js [AgentName]

# Run any additional tests
npm test
```

### 4. Commit Changes
Follow the [commit message guidelines](#commit-message-guidelines).

```bash
git add .
git commit -m "feat: add new approval checkpoint validation"
```

### 5. Push and Create PR
```bash
git push origin feature/your-feature-name
```

Then create a pull request following the [PR template](.github/PULL_REQUEST_TEMPLATE.md).

## Coding Standards

### JavaScript Style
- Use **ES6+ syntax** (const/let, arrow functions, destructuring, async/await)
- Use **2 spaces** for indentation
- Use **single quotes** for strings
- Add **semicolons**
- Use **camelCase** for variables and functions
- Use **PascalCase** for classes

### File Organization
```javascript
// 1. Imports
import { something } from './module.js';

// 2. Constants
const MAX_RETRIES = 3;

// 3. Class definition
class MyAgent extends Agent {
  constructor() {
    super();
  }

  // Public methods
  async execute() {}

  // Private methods
  _privateMethod() {}
}

// 4. Export
export default MyAgent;
```

### Comments
- Add JSDoc comments for public methods
- Explain **why**, not **what** (code should be self-documenting)
- Use inline comments sparingly

```javascript
/**
 * Executes the agent with approval checkpoints
 * @param {Object} config - Agent configuration
 * @param {string} config.module - Module name
 * @returns {Promise<Object>} Execution result with artifacts
 */
async execute(config) {
  // Implementation
}
```

### Error Handling
```javascript
// Use descriptive error messages
throw new Error(`Failed to load agent '${agentName}': agent not registered`);

// Handle async errors
try {
  await agent.execute(config);
} catch (error) {
  console.error(`Agent execution failed: ${error.message}`);
  throw error;
}
```

## Testing Guidelines

### Test Structure
- Test each agent's four checkpoint phases
- Test parallel execution scenarios
- Test state management and inter-agent communication
- Test error conditions and edge cases

### Manual Testing Checklist
For agent changes:
- [ ] Agent starts successfully
- [ ] All 4 approval checkpoints work
- [ ] Artifacts are generated correctly
- [ ] State is saved and retrievable
- [ ] Errors are handled gracefully
- [ ] Parallel execution works (if parallelizable)

### Verification Script
Always run before submitting:
```bash
npm run verify
```

This checks:
- File structure
- Configuration validity
- Agent registration
- State management
- Documentation links

## Commit Message Guidelines

Follow the [Conventional Commits](https://www.conventionalcommits.org/) specification:

### Format
```
<type>(<scope>): <subject>

<body>

<footer>
```

### Types
- **feat**: New feature
- **fix**: Bug fix
- **docs**: Documentation changes
- **style**: Code style changes (formatting, no logic change)
- **refactor**: Code refactoring
- **perf**: Performance improvements
- **test**: Test additions or fixes
- **chore**: Build process or auxiliary tool changes

### Examples
```
feat(FunctionalAgent): add requirement validation in analysis phase

- Add REQ-XXX format validation
- Add acceptance criteria parsing
- Add traceability matrix generation

Fixes #123
```

```
fix(StateManager): resolve concurrent write race condition

Previously, parallel agents could overwrite each other's state.
Now using file locking to prevent corruption.

Fixes #456
```

```
docs(getting-started): add MCP server setup instructions

Added step-by-step guide for configuring MDS and Platform UI
MCP servers, which are required for agent operation.
```

## Pull Request Process

### Before Submitting
1. ✅ Run `npm run verify` successfully
2. ✅ Test affected agents manually
3. ✅ Update documentation
4. ✅ Add/update tests
5. ✅ Follow commit message guidelines
6. ✅ Rebase on latest main branch

### PR Description
Use the [PR template](.github/PULL_REQUEST_TEMPLATE.md) and include:
- Clear description of changes
- Related issues
- Testing performed
- Breaking changes (if any)
- Documentation updates

### Review Process
1. Automated checks must pass (CI)
2. At least one maintainer review required
3. All comments must be addressed
4. Branch must be up-to-date with main

### After Approval
- Maintainer will merge using "Squash and merge"
- Your commits will be squashed into one
- Commit message will follow conventional commits format

## Architecture Guidelines

### Adding a New Agent

1. **Create agent class** in `src/agents/specialized/YourAgent.js`:
```javascript
import Agent from '../base/Agent.js';

class YourAgent extends Agent {
  constructor() {
    super('YourAgent');
  }

  async executePhase(phase, context) {
    // Implement phase logic
  }
}

export default YourAgent;
```

2. **Register in orchestrator** (`src/agents/AgentOrchestrator.js`)

3. **Add to config** (`orchestrator-config.json`)

4. **Add documentation** (`docs/agents/your-agent.md`)

5. **Add example** (`examples/your-agent-example.md`)

### Modifying Core Components

**Base Agent** (`src/agents/base/Agent.js`):
- Affects all agents
- Requires thorough testing
- Must maintain backward compatibility

**AgentOrchestrator** (`src/agents/AgentOrchestrator.js`):
- Changes affect agent coordination
- Test parallel execution scenarios
- Document behavior changes

**StateManager** (`src/agents/StateManager.js`):
- Critical for inter-agent communication
- Test concurrent access
- Ensure data integrity

## Questions?

- 📖 Check the [documentation](docs/)
- 💬 Open a [discussion](https://github.com/your-org/qa-test-orchestrator/discussions)
- 🐛 Report an [issue](https://github.com/your-org/qa-test-orchestrator/issues)

## License

By contributing, you agree that your contributions will be licensed under the same [MIT License](../LICENSE) that covers the project.

---

Thank you for contributing to QA Test Orchestrator! 🎉
