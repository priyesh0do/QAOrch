# Pull Request

## Description
<!-- Provide a clear and concise description of what this PR does -->

## Type of Change
- [ ] Bug fix (non-breaking change that fixes an issue)
- [ ] New feature (non-breaking change that adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Documentation update
- [ ] Refactoring (no functional changes)
- [ ] Performance improvement
- [ ] Test coverage improvement

## Related Issues
<!-- Link to related issues using #issue-number -->
Fixes #
Relates to #

## Changes Made
<!-- List the specific changes made in this PR -->
-
-
-

## Agents Affected
<!-- Check all agents affected by this change -->
- [ ] FunctionalTestAutomationAgent
- [ ] IntegrationTestAgent
- [ ] APITestAgent
- [ ] LocatorHealingAgent
- [ ] EndToEndTestAgent
- [ ] ProjectSetupAgent
- [ ] AgentOrchestrator
- [ ] StateManager
- [ ] Configuration
- [ ] Documentation only
- [ ] Infrastructure/Build

## Testing
<!-- Describe the testing you've done -->

### Test Checklist
- [ ] Ran `npm run verify` successfully
- [ ] Tested affected agent(s) manually
- [ ] Verified all approval checkpoints work correctly
- [ ] Tested parallel execution (if applicable)
- [ ] Verified state management (if applicable)
- [ ] Tested on target Node.js versions (18.x, 20.x)
- [ ] Checked for breaking changes

### Test Results
```
Paste test output here
```

## Configuration Changes
<!-- If you modified orchestrator-config.json or added new config options -->
- [ ] No configuration changes
- [ ] Added new configuration options (documented below)
- [ ] Modified existing configuration (breaking change documented)

<details>
<summary>Configuration changes</summary>

```json
// New or modified configuration
```
</details>

## Breaking Changes
<!-- List any breaking changes and migration steps -->
- [ ] No breaking changes
- [ ] Breaking changes (described below)

<details>
<summary>Breaking changes and migration</summary>

<!-- Describe what breaks and how users should migrate -->

</details>

## Documentation
- [ ] Updated relevant documentation in `docs/`
- [ ] Updated README.md (if needed)
- [ ] Added/updated code comments
- [ ] Added examples (if adding a feature)
- [ ] No documentation needed

## Checklist
- [ ] My code follows the project's style guidelines
- [ ] I have performed a self-review of my own code
- [ ] I have commented my code, particularly in hard-to-understand areas
- [ ] My changes generate no new warnings
- [ ] I have added tests that prove my fix is effective or that my feature works
- [ ] New and existing tests pass locally with my changes
- [ ] Any dependent changes have been merged and published

## Screenshots/Logs
<!-- If applicable, add screenshots or logs showing the changes -->

## Additional Notes
<!-- Any additional information that reviewers should know -->
