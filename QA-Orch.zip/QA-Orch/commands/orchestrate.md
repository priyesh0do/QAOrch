---
name: orchestrate
description: Start the QA Test Orchestrator master agent with preflight checks and agent selection
aliases: ["start-orchestrator", "qa-orchestrator", "preflight"]
usage: /orchestrate [module-name]
---

# Orchestrate Command

Starts the QA Test Orchestrator master agent which handles:
- Preflight checks (configuration, MCP servers, paths)
- State management
- Agent selection
- Coordinated execution

## Usage

```
/orchestrate [module-name]
```

## Examples

```bash
# Start orchestrator (interactive mode - will ask for module)
/orchestrate

# Start with specific module
/orchestrate AbsenceCode

# Alternative commands (aliases)
/start-orchestrator AbsenceCode
/qa-orchestrator
/preflight
```

## What It Does

1. **Runs Preflight Checks**:
   - Validates orchestrator-config.json
   - Checks MCP server connections
   - Verifies directory structure
   - Shows previous session state

2. **Shows Agent Selection Menu**:
   - Lists all 6 available agents
   - Shows dependencies and status
   - Lets you choose execution mode

3. **Coordinates Execution**:
   - Runs agents sequentially or in parallel
   - Respects dependencies
   - Tracks progress
   - Provides summaries

## Execution

When you run this command, it invokes the **QATestOrchestrator** agent which is the master coordinator for all test automation.

The orchestrator will guide you through:
1. Configuration validation
2. Agent selection
3. Execution planning
4. Progress tracking
5. Final summaries

## Important

This should be your **starting point** for all QA test automation. It ensures everything is configured correctly before starting any agents.
