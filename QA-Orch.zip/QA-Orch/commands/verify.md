---
name: verify
description: Verify orchestrator configuration and setup
usage: /verify
aliases:
  - check
  - validate-setup
---

# Verify Configuration

This command verifies that the QA Test Orchestrator is properly configured and ready to use.

## Usage

```
/verify
```

Or tell Claude:
```
Verify the orchestrator configuration
```

## What This Command Does

Checks:
1. **Configuration File**
   - orchestrator-config.json exists
   - Has required fields (version, projectPath, etc.)
   - Version is 3.0.0
   - Architecture is agent-driven

2. **Directory Structure**
   - Project path exists
   - Requirement path exists
   - Frontend path exists (if specified)

3. **MCP Servers**
   - MDS MCP server status
   - Platform UI MCP server status
   - Chrome DevTools MCP status (optional)

4. **Paths**
   - All configured paths are valid
   - Paths are accessible

## Example Output

```
╔════════════════════════════════════════════════════════════╗
║            Configuration Verification                      ║
╚════════════════════════════════════════════════════════════╝

Configuration File: ✓ PASS
  ✓ orchestrator-config.json exists
  ✓ Version: 3.0.0
  ✓ Architecture: agent-driven

Project Paths: ✓ PASS
  ✓ projectPath: C:\Working\TestProject
  ✓ requirementPath: C:\Working\Requirements
  ✓ frontendProjectPath: C:\Working\Frontend

MCP Servers: ⚠ WARNING
  ✓ mds-mcp: Connected
  ✓ platform-ui: Connected
  ⚠ chrome-devtools: Not connected (optional)

Agents: ✓ PASS
  ✓ 6 agents configured
  ✓ All agents available

╔════════════════════════════════════════════════════════════╗
║  Status: READY                                             ║
║  You can start generating tests!                           ║
╚════════════════════════════════════════════════════════════╝
```

## Common Issues

### Issue: Configuration file not found
```
❌ orchestrator-config.json not found
```
**Solution**: Create orchestrator-config.json in the project root

### Issue: Invalid paths
```
❌ projectPath does not exist: C:\Invalid\Path
```
**Solution**: Update paths in orchestrator-config.json to valid directories

### Issue: MCP servers not connected
```
⚠ MDS MCP server not connected
```
**Solution**:
1. Open Claude Code settings
2. Navigate to MCP Servers
3. Add mds-mcp server
4. Restart Claude Code

## When To Use

Run `/verify`:
- Before starting any agent for the first time
- After updating orchestrator-config.json
- When troubleshooting issues
- After installing/updating MCP servers

## Related Commands

- `/setup-project` - Initialize project structure
- `/start-functional-tests` - Start generating tests
