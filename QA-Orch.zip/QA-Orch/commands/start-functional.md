---
name: start-functional-tests
description: Start functional test generation with the FunctionalTestAutomationAgent
usage: /start-functional-tests [module-name]
aliases:
  - start-functional
  - functional-tests
---

# Start Functional Test Generation

This command starts the FunctionalTestAutomationAgent to generate functional tests with full traceability for a specified module.

## Usage

```
/start-functional-tests AbsenceCode
```

Or simply tell Claude:
```
Start FunctionalTestAutomationAgent for module AbsenceCode
```

## What This Command Does

1. Loads the FunctionalTestAutomationAgent
2. Reads orchestrator-config.json for configuration
3. Starts the 4-phase test generation process:
   - Phase 1: Analysis (parse requirements)
   - Phase 2: Design (create traceability matrix)
   - Phase 3: Generation (create page objects and tests)
   - Phase 4: Validation (verify coverage)

## Prerequisites

- orchestrator-config.json exists with correct paths
- Requirements document exists at {requirementPath}/{moduleName}.md
- Requirements follow REQ-XXX and AC-XXX format
- MDS MCP server is connected

## Generated Artifacts

After completion, you'll have:
- `test-designs/{module}/functional-design.md`
- `test-designs/{module}/traceability-matrix.md`
- `pages/{module}/*.page.js`
- `tests/functional/{module}/*.spec.js`

## Example

```
User: /start-functional-tests AbsenceCode

Claude: I'll start the FunctionalTestAutomationAgent for the AbsenceCode module.
[Loads functional-test-agent.md instructions]
[Follows 4-phase process with approval checkpoints]
```

## Notes

- This agent requires user approval at all 4 phases (low autonomy)
- Can run in parallel with APITestAgent
- Should NOT run in parallel with LocatorHealingAgent
- Typical execution time: 10-20 minutes (including user approval time)

## Related Commands

- `/start-integration-tests` - Start integration tests (requires this agent first)
- `/start-e2e-tests` - Start E2E tests (requires this and integration agent)
- `/heal-locators` - Heal broken locators from failed tests
