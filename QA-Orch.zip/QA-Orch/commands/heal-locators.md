---
name: heal-locators
description: Auto-heal broken locators with the LocatorHealingAgent
usage: /heal-locators [module-name]
aliases:
  - fix-locators
  - locator-healing
---

# Heal Broken Locators

This command starts the LocatorHealingAgent to automatically fix broken locators in page objects by providing up to 5 alternative strategies.

## Usage

```
/heal-locators AbsenceCode
```

Or tell Claude:
```
Start LocatorHealingAgent to fix failed tests in module AbsenceCode
```

## What This Command Does

1. Loads the LocatorHealingAgent
2. Analyzes test failures caused by broken locators
3. Generates 5 alternative locator strategies for each failure
4. Updates page objects with the best alternative
5. Creates backups before any modifications

## Prerequisites

- Failed test results showing locator failures
- Page objects exist at pages/{module}/
- MDS MCP server connected (recommended)

## When To Use

Use this command when you see test failures like:
- "Error: locator.click: Timeout 30000ms exceeded"
- "Error: strict mode violation: locator resolved to 3 elements"
- "Error: Element not found: [data-testid='add-btn']"

## Generated Artifacts

- Updated page objects with healed locators
- Backup files: `*.page.js.bak`
- Healing report: `logs/{module}-healing-report.md`

## Example

```
User: /heal-locators AbsenceCode

Claude: I'll start the LocatorHealingAgent to heal broken locators in AbsenceCode module.

[Phase 1: Analysis]
Found 2 failed locators:
  ✗ addButton: Element not found
  ✗ nameInput: Multiple matches (3 found)

[Phase 2: Design]
Alternative locators generated (5 per failure)

[Phase 3: Generation]
Updated page objects with recommended locators
Created backups

[Phase 4: Validation]
All locators healed successfully
```

## Notes

- **Cannot run in parallel** with other agents
- Always creates backups before modifying files
- Prioritizes MDS-aware locators
- Documents all 5 alternatives in code comments
- Recommended locator is option 1 (most reliable)

## After Healing

1. Re-run the failed tests:
   ```bash
   npx playwright test tests/functional/AbsenceCode/
   ```

2. If tests still fail, try alternative locators from comments

3. Review healing report for patterns in failures

## Related Commands

- `/start-functional-tests` - Generate functional tests
- `/verify` - Verify configuration and setup
