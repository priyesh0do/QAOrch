# Example: Basic Functional Test Generation

This example demonstrates generating functional tests for a single module using the FunctionalTestAutomationAgent.

## Scenario

You have a **Absence Code** module with the following:
- Requirements document at `./requirements/AbsenceCode.md`
- Frontend code at `./frontend/modules/absence-code`
- Want to generate functional tests with traceability

## Prerequisites

- QA Orchestrator installed and verified
- Requirements document with REQ-XXX and AC-XXX format
- MDS MCP server connected (for MDS-aware locators)

## Step 1: Prepare Requirements

Create `requirements/AbsenceCode.md`:

```markdown
# Absence Code Management

## REQ-001: Add New Absence Code
Users shall be able to add new absence codes to the system.

### AC-001: Display Add Button
The system shall display an "Add" button on the absence code list page.

### AC-002: Open Add Form
When the user clicks "Add", the system shall display a form with fields:
- Code Name (required, max 50 characters)
- Description (optional, max 200 characters)
- Is Active (checkbox, default checked)

### AC-003: Validate Code Name
The system shall validate that Code Name is unique before saving.

### AC-004: Save Absence Code
When the user clicks "Save", the system shall save the absence code and display
a success message.

## REQ-002: Edit Existing Absence Code
Users shall be able to edit existing absence codes.

### AC-005: Display Edit Button
Each absence code in the list shall have an "Edit" button.

### AC-006: Load Existing Data
When the user clicks "Edit", the system shall populate the form with existing values.

### AC-007: Update Absence Code
When the user clicks "Save", the system shall update the absence code.
```

## Step 2: Configure Orchestrator

Edit `orchestrator-config.json`:

```json
{
  "version": "3.0.0",
  "architecture": "agent-driven",
  "projectPath": "./test-project",
  "requirementPath": "./requirements",
  "frontendProjectPath": "./frontend/modules/absence-code",
  "baseUrl": "http://localhost:5173/absence-codes",
  "framework": "Playwright",
  "language": "JavaScript",
  "agents": {
    "enabled": true,
    "parallelExecution": false,
    "maxConcurrentAgents": 1
  }
}
```

## Step 3: Start the Agent

### Using Claude Code (Recommended)

```
Start FunctionalTestAutomationAgent for module AbsenceCode
```

### Using CLI

```bash
npx qa-orchestrator start functional --module AbsenceCode
```

### Using Node.js

```bash
node execute-agent.js
```

## Step 4: Approve at Checkpoints

The agent will stop at 4 checkpoints:

### Checkpoint 1: Analysis Phase

**Agent displays**:
```
╔════════════════════════════════════════════════════════════╗
║              APPROVAL CHECKPOINT: Analysis                 ║
╚════════════════════════════════════════════════════════════╝

Extracted Requirements:
  ✓ REQ-001: Add New Absence Code (4 acceptance criteria)
  ✓ REQ-002: Edit Existing Absence Code (3 acceptance criteria)

Extracted Acceptance Criteria:
  ✓ AC-001: Display Add Button
  ✓ AC-002: Open Add Form
  ✓ AC-003: Validate Code Name
  ✓ AC-004: Save Absence Code
  ✓ AC-005: Display Edit Button
  ✓ AC-006: Load Existing Data
  ✓ AC-007: Update Absence Code

Identified Components:
  • MdsButton (Add, Edit, Save buttons)
  • MdsInput (Code Name, Description fields)
  • MdsCheckbox (Is Active field)
  • MdsDialog (Form modal)

Press [A] to approve, [M] to modify, [R] to reject, [V] to view details:
```

**Action**: Press `A` to approve

---

### Checkpoint 2: Design Phase

**Agent displays**:
```
╔════════════════════════════════════════════════════════════╗
║              APPROVAL CHECKPOINT: Design                   ║
╚════════════════════════════════════════════════════════════╝

Test Design Created:
  ✓ test-designs/AbsenceCode/functional-design.md (8 test scenarios)

Traceability Matrix:
  ✓ REQ-001 → AC-001 → TC-001: Verify Add button is displayed
  ✓ REQ-001 → AC-002 → TC-002: Verify Add form opens with fields
  ✓ REQ-001 → AC-003 → TC-003: Verify code name uniqueness validation
  ✓ REQ-001 → AC-004 → TC-004: Verify successful save with message
  ✓ REQ-002 → AC-005 → TC-005: Verify Edit button on each row
  ✓ REQ-002 → AC-006 → TC-006: Verify form loads existing data
  ✓ REQ-002 → AC-007 → TC-007: Verify successful update

Press [A] to approve, [M] to modify, [R] to reject, [V] to view details:
```

**Action**: Press `A` to approve

---

### Checkpoint 3: Generation Phase

**Agent displays**:
```
╔════════════════════════════════════════════════════════════╗
║              APPROVAL CHECKPOINT: Generation               ║
╚════════════════════════════════════════════════════════════╝

Generated Artifacts:

Page Objects:
  ✓ pages/AbsenceCode/AbsenceCodeList.page.js (7 locators, 3 methods)
  ✓ pages/AbsenceCode/AbsenceCodeForm.page.js (5 locators, 4 methods)

Test Files:
  ✓ tests/functional/AbsenceCode/add-absence-code.spec.js (4 tests)
  ✓ tests/functional/AbsenceCode/edit-absence-code.spec.js (3 tests)

Press [A] to approve, [M] to modify, [R] to reject, [V] to view details:
```

**Action**: Press `A` to approve

---

### Checkpoint 4: Validation Phase

**Agent displays**:
```
╔════════════════════════════════════════════════════════════╗
║              APPROVAL CHECKPOINT: Validation               ║
╚════════════════════════════════════════════════════════════╝

Validation Results:

Traceability Coverage: 100%
  ✓ All 7 acceptance criteria have test cases

Page Object Coverage: 100%
  ✓ All identified components have locators
  ✓ All locators use MDS-aware strategies

Test File Quality:
  ✓ All tests follow Page Object Model
  ✓ All tests have descriptive names
  ✓ All tests have proper assertions

Press [A] to approve, [M] to modify, [R] to reject, [V] to view details:
```

**Action**: Press `A` to approve

## Step 5: Review Generated Artifacts

### 1. Test Design Document

**Location**: `test-designs/AbsenceCode/functional-design.md`

Contains complete test design with scenarios, expected behaviors, and data requirements.

### 2. Traceability Matrix

**Location**: `test-designs/AbsenceCode/traceability-matrix.md`

Shows full REQ → AC → TC mapping for audit purposes.

### 3. Page Objects

**Location**: `pages/AbsenceCode/AbsenceCodeList.page.js`

```javascript
class AbsenceCodeListPage {
  constructor(page) {
    this.page = page;

    // MDS-aware locators
    this.addButton = page.locator('mds-button[data-testid="add-absence-code"]');
    this.absenceCodeRows = page.locator('mds-table tbody tr');
    this.editButtons = page.locator('mds-button[aria-label="Edit"]');
  }

  async clickAdd() {
    await this.addButton.click();
  }

  async getRowCount() {
    return await this.absenceCodeRows.count();
  }

  async clickEditForCode(codeName) {
    const row = this.absenceCodeRows.filter({ hasText: codeName });
    await row.locator('mds-button[aria-label="Edit"]').click();
  }
}

module.exports = AbsenceCodeListPage;
```

### 4. Test Files

**Location**: `tests/functional/AbsenceCode/add-absence-code.spec.js`

```javascript
const { test, expect } = require('@playwright/test');
const AbsenceCodeListPage = require('../../pages/AbsenceCode/AbsenceCodeList.page');
const AbsenceCodeFormPage = require('../../pages/AbsenceCode/AbsenceCodeForm.page');

test.describe('Absence Code - Add New Code', () => {
  let listPage;
  let formPage;

  test.beforeEach(async ({ page }) => {
    listPage = new AbsenceCodeListPage(page);
    formPage = new AbsenceCodeFormPage(page);
    await page.goto('/absence-codes');
  });

  test('TC-001: Verify Add button is displayed', async ({ page }) => {
    // REQ-001, AC-001
    await expect(listPage.addButton).toBeVisible();
  });

  test('TC-002: Verify Add form opens with required fields', async ({ page }) => {
    // REQ-001, AC-002
    await listPage.clickAdd();

    await expect(formPage.codeNameInput).toBeVisible();
    await expect(formPage.descriptionTextarea).toBeVisible();
    await expect(formPage.isActiveCheckbox).toBeChecked();
  });

  test('TC-003: Verify code name uniqueness validation', async ({ page }) => {
    // REQ-001, AC-003
    await listPage.clickAdd();
    await formPage.fillCodeName('EXISTING_CODE');
    await formPage.clickSave();

    await expect(formPage.errorMessage).toHaveText('Code name already exists');
  });

  test('TC-004: Verify successful save shows success message', async ({ page }) => {
    // REQ-001, AC-004
    await listPage.clickAdd();
    await formPage.fillCodeName('NEW_CODE');
    await formPage.fillDescription('New absence code');
    await formPage.clickSave();

    await expect(page.locator('.success-message')).toHaveText('Absence code saved successfully');
  });
});
```

## Step 6: Run the Tests

```bash
npx playwright test tests/functional/AbsenceCode/
```

Expected output:
```
Running 7 tests using 4 workers

  ✓ tests/functional/AbsenceCode/add-absence-code.spec.js:12:3 › TC-001: Verify Add button is displayed (542ms)
  ✓ tests/functional/AbsenceCode/add-absence-code.spec.js:17:3 › TC-002: Verify Add form opens with required fields (634ms)
  ✓ tests/functional/AbsenceCode/add-absence-code.spec.js:26:3 › TC-003: Verify code name uniqueness validation (723ms)
  ✓ tests/functional/AbsenceCode/add-absence-code.spec.js:34:3 › TC-004: Verify successful save shows success message (612ms)
  ✓ tests/functional/AbsenceCode/edit-absence-code.spec.js:12:3 › TC-005: Verify Edit button on each row (487ms)
  ✓ tests/functional/AbsenceCode/edit-absence-code.spec.js:17:3 › TC-006: Verify form loads existing data (598ms)
  ✓ tests/functional/AbsenceCode/edit-absence-code.spec.js:26:3 › TC-007: Verify successful update (645ms)

7 passed (4.2s)
```

## Tips

1. **Clear Requirements**: Use REQ-XXX and AC-XXX format for best results
2. **MDS Components**: Mention MDS component names in requirements for better locators
3. **Review Design**: Carefully review at Checkpoint 2 (Design) before generation
4. **Modify if Needed**: Use [M] at checkpoints to provide corrections
5. **Save State**: Agent state persists in `.agent-state/` directory

## Next Steps

- [Generate integration tests](integration-test-example.md)
- [Heal broken locators](locator-healing-example.md)
- [Run tests in parallel](parallel-execution-example.md)
