# Example: Parallel Execution

This example demonstrates using parallel execution to generate tests for multiple modules simultaneously, achieving 40%+ time savings.

## Scenario

You need to generate functional tests for **3 modules**:
1. Absence Code
2. Time Off Request
3. Calendar Management

Processing sequentially would take ~90 minutes. With parallel execution, it takes ~30 minutes.

## Prerequisites

- QA Orchestrator installed and verified
- Requirements for all 3 modules
- Adequate system resources (recommend 8GB RAM)

## Configuration

Edit `orchestrator-config.json` to enable parallel execution:

```json
{
  "version": "3.0.0",
  "architecture": "agent-driven",
  "projectPath": "./test-project",
  "agents": {
    "enabled": true,
    "parallelExecution": true,
    "maxConcurrentAgents": 3
  }
}
```

**Key Settings**:
- `parallelExecution: true` - Enable parallel agent execution
- `maxConcurrentAgents: 3` - Run up to 3 agents simultaneously

## Example 1: Multiple Modules, Same Agent

Generate functional tests for 3 modules in parallel:

### Command (Claude Code)

```
Start FunctionalTestAutomationAgent for modules: AbsenceCode, TimeOffRequest, CalendarManagement in parallel
```

### Execution Flow

```
Time: 0:00
├─ FunctionalTestAutomationAgent [AbsenceCode] starts
├─ FunctionalTestAutomationAgent [TimeOffRequest] starts
└─ FunctionalTestAutomationAgent [CalendarManagement] starts

Time: 0:05 (Analysis checkpoints)
├─ All 3 agents waiting for approval
└─ Press [A] to approve all

Time: 0:10 (Design checkpoints)
├─ All 3 agents waiting for approval
└─ Press [A] to approve all

Time: 0:20 (Generation checkpoints)
├─ All 3 agents waiting for approval
└─ Press [A] to approve all

Time: 0:25 (Validation checkpoints)
├─ All 3 agents waiting for approval
└─ Press [A] to approve all

Time: 0:30 (Complete)
└─ All 3 modules complete ✓
```

### Time Comparison

| Approach | Time | Improvement |
|----------|------|-------------|
| Sequential (v2.0) | 90 min | Baseline |
| Parallel (v3.0) | 30 min | **67% faster** |

### Generated Artifacts

```
test-designs/
  ├── AbsenceCode/
  │   ├── functional-design.md
  │   └── traceability-matrix.md
  ├── TimeOffRequest/
  │   ├── functional-design.md
  │   └── traceability-matrix.md
  └── CalendarManagement/
      ├── functional-design.md
      └── traceability-matrix.md

pages/
  ├── AbsenceCode/*.page.js
  ├── TimeOffRequest/*.page.js
  └── CalendarManagement/*.page.js

tests/functional/
  ├── AbsenceCode/*.spec.js
  ├── TimeOffRequest/*.spec.js
  └── CalendarManagement/*.spec.js
```

## Example 2: Multiple Agent Types, Same Module

Generate functional, integration, and API tests for one module in parallel:

### Command (Claude Code)

```
Start FunctionalTestAutomationAgent, IntegrationTestAgent, and APITestAgent in parallel for module AbsenceCode
```

### Execution Flow

```
Time: 0:00
├─ FunctionalTestAutomationAgent [AbsenceCode] starts
├─ IntegrationTestAgent [AbsenceCode] starts (waits for Functional*)
└─ APITestAgent [AbsenceCode] starts

Time: 0:10
├─ FunctionalTestAutomationAgent: Complete ✓
├─ IntegrationTestAgent: Now starts (dependency satisfied)
└─ APITestAgent: In progress

Time: 0:20
├─ IntegrationTestAgent: Complete ✓
└─ APITestAgent: Complete ✓

Total: ~20 minutes
```

*Note: IntegrationTestAgent depends on FunctionalTestAutomationAgent

### Time Comparison

| Approach | Time | Improvement |
|----------|------|-------------|
| Sequential | 65 min | Baseline |
| Parallel | 20 min | **69% faster** |

### Generated Artifacts

```
test-designs/AbsenceCode/
  ├── functional-design.md
  ├── integration-design.md
  └── api-design.md

tests/
  ├── functional/AbsenceCode/*.spec.js
  ├── integration/AbsenceCode/*.spec.js
  └── api/AbsenceCode/*.spec.js
```

## Example 3: Full Test Suite (All Agents, Multiple Modules)

Generate complete test coverage for 2 modules:

### Command (Claude Code)

```
Start FunctionalTestAutomationAgent, IntegrationTestAgent, APITestAgent, and EndToEndTestAgent for modules: AbsenceCode, TimeOffRequest in parallel
```

### Execution Flow (with Dependencies)

```
Level 0 (Parallel):
├─ FunctionalTestAutomationAgent [AbsenceCode]
├─ FunctionalTestAutomationAgent [TimeOffRequest]
├─ APITestAgent [AbsenceCode]
└─ APITestAgent [TimeOffRequest]

Level 1 (Parallel, after Level 0):
├─ IntegrationTestAgent [AbsenceCode]
└─ IntegrationTestAgent [TimeOffRequest]

Level 2 (Parallel, after Level 1):
├─ EndToEndTestAgent [AbsenceCode]
└─ EndToEndTestAgent [TimeOffRequest]
```

### Dependency Graph

```
FunctionalTestAutomationAgent ──┐
                                ├──> IntegrationTestAgent ──┐
                                │                           ├──> EndToEndTestAgent
APITestAgent ───────────────────┘                           │
                                                            │
                                                            ↓
                                                        (All complete)
```

### Time Comparison

| Approach | Time | Improvement |
|----------|------|-------------|
| Sequential (all modules) | 240 min | Baseline |
| Parallel (3 levels) | 75 min | **69% faster** |

## Programmatic Usage

### Node.js Script

```javascript
const {
  AgentOrchestrator,
  FunctionalTestAutomationAgent,
  IntegrationTestAgent,
  APITestAgent
} = require('./agents');

const config = require('./orchestrator-config.json');

async function parallelExecution() {
  const orchestrator = new AgentOrchestrator({
    maxConcurrent: 3
  });

  // Register multiple agents for different modules
  const modules = ['AbsenceCode', 'TimeOffRequest', 'CalendarManagement'];

  modules.forEach(module => {
    orchestrator.registerAgent(FunctionalTestAutomationAgent, {
      moduleName: module,
      requirementPath: `${config.requirementPath}/${module}.md`,
      frontendPath: `${config.frontendProjectPath}/${module.toLowerCase()}`,
      projectPath: config.projectPath
    });
  });

  // Execute all in parallel
  console.log('Starting parallel execution for 3 modules...');

  const results = await orchestrator.executeParallel(
    modules.map(m => `FunctionalTestAutomationAgent-${m}`)
  );

  // Report results
  results.forEach(result => {
    console.log(`${result.agent}: ${result.success ? '✅' : '❌'}`);
  });
}

parallelExecution();
```

## Resource Management

### CPU and Memory Usage

Monitor resource usage during parallel execution:

```bash
# Linux/Mac
htop

# Windows
Task Manager → Performance tab
```

**Typical Usage per Agent**:
- CPU: 25-50% of one core
- RAM: 400-600 MB
- Disk I/O: Moderate

**Recommended Settings by System**:

| RAM | maxConcurrentAgents | Modules/Batch |
|-----|---------------------|---------------|
| 4GB | 2 | 2 modules |
| 8GB | 3-4 | 3-4 modules |
| 16GB | 6-8 | 6-8 modules |
| 32GB | 10-12 | 10-12 modules |

## Monitoring Parallel Execution

### Check Status

```javascript
const orchestrator = new AgentOrchestrator({ maxConcurrent: 3 });

// Get overall status
const status = orchestrator.getStatus();
console.log(`Running: ${status.running}`);
console.log(`Queued: ${status.queued}`);
console.log(`Completed: ${status.completed}`);

// Get agent-specific status
const agentStatus = orchestrator.getAgentStatus('FunctionalTestAutomationAgent-AbsenceCode');
console.log(`State: ${agentStatus.state}`);
console.log(`Phase: ${agentStatus.phase}`);
```

### Log Output

```
[Orchestrator] Starting parallel execution with max 3 concurrent agents
[Orchestrator] Level 0: Starting 3 agents
[Orchestrator]   ├─ FunctionalTestAutomationAgent [AbsenceCode]
[Orchestrator]   ├─ FunctionalTestAutomationAgent [TimeOffRequest]
[Orchestrator]   └─ APITestAgent [AbsenceCode]
[Agent] FunctionalTestAutomationAgent [AbsenceCode] → Analysis phase
[Agent] FunctionalTestAutomationAgent [TimeOffRequest] → Analysis phase
[Agent] APITestAgent [AbsenceCode] → Analysis phase
[Orchestrator] Level 0: All agents complete (30 min)
[Orchestrator] Level 1: Starting 1 agent
[Orchestrator]   └─ IntegrationTestAgent [AbsenceCode]
...
[Orchestrator] All agents complete ✓
```

## Troubleshooting

### Issue: Agents Running Sequentially

**Symptom**: Only 1 agent runs at a time

**Solution**:
```json
{
  "agents": {
    "parallelExecution": true,
    "maxConcurrentAgents": 3
  }
}
```

### Issue: Out of Memory

**Symptom**: System slowdown, agents crashing

**Solutions**:
1. Reduce `maxConcurrentAgents` to 2
2. Process fewer modules per batch
3. Close other applications
4. Increase system RAM

### Issue: File Conflicts

**Symptom**: Corrupted page objects

**Solution**: Don't run LocatorHealingAgent in parallel:
```json
{
  "name": "LocatorHealingAgent",
  "parallelizable": false
}
```

## Best Practices

1. **Start Small**: Begin with 2 concurrent agents, scale up gradually
2. **Monitor Resources**: Watch CPU/RAM usage
3. **Batch Modules**: Process 3-4 modules at a time
4. **Respect Dependencies**: Don't try to parallelize dependent agents
5. **Use Levels**: Let orchestrator group agents by dependency level

## Related Examples

- [Basic functional test generation](basic-functional-test.md)
- [Integration test generation](integration-test-example.md)
- [Custom agent creation](custom-agent.md)
